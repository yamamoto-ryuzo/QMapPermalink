"""
Minimal QMapWebMapGenerator

This module provides a very small QMapWebMapGenerator class with a single
purpose: return a fullscreen OpenLayers HTML page that points to a local
WMS using parameters passed in navigation_data. The implementation is
kept deliberately tiny to ensure the file imports cleanly inside QGIS
and avoids f-string/JavaScript brace collisions by using string
concatenation.
"""

class QMapWebMapGenerator:
    """Minimal web map generator used by the plugin."""

    def __init__(self, iface):
        # keep a reference to iface if needed later; do not import QGIS modules here
        self.iface = iface

    def generate_wms_based_html_page(self, navigation_data, image_width=800, image_height=600, server_port=8089):
        """Return a minimal fullscreen OpenLayers HTML page.

        navigation_data: dict, optional keys: 'x', 'y', 'crs'
        """
        # safe parameter extraction
        try:
            x = navigation_data.get('x', 0)
            y = navigation_data.get('y', 0)
            crs = navigation_data.get('crs', 'EPSG:3857')
            rotation_deg = navigation_data.get('rotation', 0)  # degrees
        except Exception:
            x, y, crs, rotation_deg = 0, 0, 'EPSG:3857', 0

        port = int(server_port)

        html = (
            '<!doctype html>'
            '<html lang="ja">'
            '<head>'
            '  <meta charset="utf-8">'
            '  <meta name="viewport" content="width=device-width,initial-scale=1">'
            '  <title>QMap Permalink - simple map</title>'
            '  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@8.2.0/ol.css" type="text/css">'
            '  <script src="https://cdn.jsdelivr.net/npm/ol@8.2.0/dist/ol.js"></script>'
            '  <style>html,body{height:100%;margin:0;padding:0}#map{width:100vw;height:100vh}</style>'
            '</head>'
            '<body>'
            '  <div id="map"></div>'
            '  <script>'
            '    const serverPort = ' + str(port) + ';'
            '    const inputX = ' + str(x) + ';'
            '    const inputY = ' + str(y) + ';'
            '    const inputCRS = "' + str(crs) + '";'
            '    const viewCenter = (function() {'
            '      try {'
            '        if (inputCRS === "EPSG:4326") {'
            '          return ol.proj.fromLonLat([inputX, inputY]);'
            '        } else if (inputCRS === "EPSG:3857") {'
            '          return [inputX, inputY];'
            '        } else {'
            '          return ol.proj.transform([inputX, inputY], inputCRS, "EPSG:3857");'
            '        }'
            '      } catch (e) {'
            '        console.warn("proj transform failed", e);'
            '        return ol.proj.fromLonLat([inputX, inputY]);'
            '      }'
            '    })();'
            '    const rotationRad = (' + str(rotation_deg) + ' || 0) * Math.PI / 180;'
            '    const map = new ol.Map({'
            '      target: "map",'
            '      layers: ['
            '        new ol.layer.Image({'
            '          source: new ol.source.ImageWMS({'
            '            url: "http://localhost:" + serverPort + "/wms",'
            '            params: {LAYERS: "project", FORMAT: "image/png", TRANSPARENT: true, VERSION: "1.3.0"}'
            '          }),'
            '          opacity: 1.0'
            '        })'
            '      ],'
            '      view: new ol.View({center: viewCenter, projection: "EPSG:3857", zoom: 12, rotation: rotationRad})'
            '    });'
            '  </script>'
            '</body>'
            '</html>'
        )

        return html

    # lightweight stubs to avoid AttributeErrors elsewhere in the plugin
    def get_qgis_layers_info(self):
        return {'layer_count': 0, 'visible_layers': []}

    def get_current_extent_info(self):
        return {}

    def _resolve_coordinates(self, navigation_data):
        try:
            lat = navigation_data.get('lat')
            lon = navigation_data.get('lon')
            if lat is not None and lon is not None:
                return float(lat), float(lon)
            x = navigation_data.get('x')
            y = navigation_data.get('y')
            if x is None or y is None:
                return None, None
            return float(y), float(x)
        except Exception:
            return None, None