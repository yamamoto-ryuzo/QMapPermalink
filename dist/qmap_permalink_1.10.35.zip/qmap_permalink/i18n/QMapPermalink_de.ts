<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>QMapPermalink</name>
    <message>
        <location filename="../qmap_permalink.py" line="74"/>
        <source>&amp;QMap Permalink</source>
        <translation>&amp;QMap Permalink</translation>
    </message>
    <message>
        <location filename="../qmap_permalink.py" line="142"/>
        <source>QMap Permalink</source>
        <translation>QMap Permalink</translation>
    </message>
</context>
<context>
    <name>QMapPermalinkDialogBase</name>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="14"/>
        <source>QMap Permalink</source>
        <translation>QMap Permalink</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="24"/>
        <source>Generate Permalink</source>
        <translation>Permalink Generieren</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="31"/>
        <source>Generate a permalink for the current map view (position, zoom level, CRS)</source>
        <translation>Erstellen Sie einen Permalink für die aktuelle Kartenansicht (Position, Zoomstufe, KBS)</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="56"/>
        <source>Generate Permalink</source>
        <translation>Permalink Generieren</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="85"/>
        <source>Permalink URL</source>
        <translation>Permalink URL</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="92"/>
        <source>Copy this URL to embed in external documents (Excel, PDF, etc.) or use it to navigate</source>
        <translation>Kopieren Sie diese URL zum Einbetten in externe Dokumente (Excel, PDF, etc.) oder zur Navigation</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="102"/>
        <source>Generated permalink will appear here...</source>
        <translation>Der generierte Permalink wird hier angezeigt...</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="127"/>
        <source>Copy to Clipboard</source>
        <translation>In Zwischenablage Kopieren</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="154"/>
        <source>Navigate to Permalink</source>
        <translation>Zu Permalink Navigieren</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="161"/>
        <source>Paste a permalink URL below and click Navigate to jump to that map view</source>
        <translation>Fügen Sie unten eine Permalink-URL ein und klicken Sie auf Navigieren, um zu dieser Kartenansicht zu springen</translation>
    </message>
    <message>
        <location filename="../qmap_permalink_dialog_base.ui" line="186"/>
        <source>Navigate</source>
        <translation>Navigieren</translation>
    </message>
</context>
</TS>