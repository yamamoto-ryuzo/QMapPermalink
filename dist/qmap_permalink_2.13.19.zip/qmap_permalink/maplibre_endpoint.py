"""Simple MapLibre HTML generator used by the standalone server.

This module provides a small helper to create an HTML string that
initializes MapLibre centered on coordinates parsed from a permalink
style string or explicit lat/lon/zoom query parameters.

It intentionally keeps dependencies minimal so it can be used outside
of QGIS.
"""
from urllib.parse import urlparse, parse_qs
import re
import math

def _parse_permalink(permalink_text):
    """Reuse the same parsing heuristics as the plugin's generator.

    This duplicates a subset of the original implementation so the
    standalone server does not need the full QGIS stack.
    Returns (lat, lon, zoom) or None.
    """
    if not permalink_text:
        return None
    try:
        p = urlparse(permalink_text)
        qs = parse_qs(p.query)
        # Support QGIS permalink style with x/y/scale/crs (e.g. /qgis-map?x=...&y=...&scale=...&crs=EPSG:3857)
        try:
            if 'x' in qs and 'y' in qs:
                x = float(qs['x'][0])
                y = float(qs['y'][0])
                # default assume degrees unless crs indicates WebMercator
                crs = qs.get('crs', [None])[0]
                lat2 = None; lon2 = None
                if crs and ('3857' in crs or '900913' in crs or 'WebMercator' in (crs or '')):
                    # convert WebMercator (EPSG:3857) meters to lon/lat
                    try:
                        lon2 = (x / 6378137.0) * 180.0 / math.pi
                        lat2 = (2.0 * math.atan(math.exp(y / 6378137.0)) - math.pi / 2.0) * 180.0 / math.pi
                    except Exception:
                        lon2 = None; lat2 = None
                else:
                    # If values look like degrees, treat as lon/lat
                    if abs(x) <= 180 and abs(y) <= 90:
                        lon2 = x; lat2 = y
                    else:
                        # Unknown CRS and large coordinates -> attempt WebMercator conversion
                        try:
                            lon2 = (x / 6378137.0) * 180.0 / math.pi
                            lat2 = (2.0 * math.atan(math.exp(y / 6378137.0)) - math.pi / 2.0) * 180.0 / math.pi
                        except Exception:
                            lon2 = None; lat2 = None

                # compute zoom from scale if present
                zoom2 = None
                if 'scale' in qs:
                    try:
                        scale = float(qs['scale'][0])
                        # scale denominator to meters per pixel: resolution = scale * 0.00028
                        resolution = scale * 0.00028
                        # initialResolution at equator
                        initialResolution = 156543.03392804097
                        if lat2 is None:
                            # approximate at equator
                            coslat = 1.0
                        else:
                            coslat = math.cos(math.radians(lat2))
                        zoom2 = math.log2((initialResolution * coslat) / resolution)
                        zoom2 = max(0.0, zoom2)
                    except Exception:
                        zoom2 = None

                if lat2 is not None and lon2 is not None:
                    return (lat2, lon2, zoom2)
        except Exception:
            pass
        lat = None; lon = None; zoom = None
        for key in ('lat','latitude'):
            if key in qs:
                lat = float(qs[key][0]); break
        for key in ('lon','lng','longitude'):
            if key in qs:
                lon = float(qs[key][0]); break
        for key in ('zoom','z'):
            if key in qs:
                try:
                    zoom = float(qs[key][0]);
                except Exception:
                    zoom = None
                break
        # center param like "lon,lat,zoom" or "lat,lon,zoom"
        if ('center' in qs or 'c' in qs) and (lat is None or lon is None):
            center = qs.get('center', qs.get('c'))[0]
            parts = re.split('[,; ]+', center)
            if len(parts) >= 2:
                a = float(parts[0]); b = float(parts[1])
                if abs(a) > 90:
                    lon, lat = a, b
                else:
                    lat, lon = a, b
            if len(parts) >= 3 and zoom is None:
                zoom = float(parts[2])
        if lat is not None and lon is not None:
            return (lat, lon, zoom)
    except Exception:
        pass

    m = re.search(r'@\s*([0-9.+-]+),\s*([0-9.+-]+),\s*([0-9.+-]+)z', permalink_text)
    if m:
        try:
            lat = float(m.group(1)); lon = float(m.group(2)); zoom = float(m.group(3))
            return (lat, lon, zoom)
        except Exception:
            pass

    # try any three floats in the text
    floats = re.findall(r'[-+]?[0-9]*\.?[0-9]+', permalink_text)
    if len(floats) >= 3:
        try:
            a,b,c = map(float, floats[:3])
            if abs(a) <= 90:
                return (a,b,c)
            else:
                return (b,a,c)
        except Exception:
            pass
    return None


def generate_maplibre_html(permalink_text=None, lat=None, lon=None, zoom=None, tile_url=None):
    """Return a full HTML string initializing MapLibre.

    Parameters can be supplied as a permalink string (permalink_text)
    or explicit lat/lon/zoom. Explicit args override the permalink.
    """
    if permalink_text and (lat is None or lon is None):
        # Prefer the plugin's parsing logic when available to keep behavior
        # unified with the rest of the codebase.
        parsed = None
        try:
            from .qmap_maplibre import _parse_permalink as _qm_parse
            parsed = _qm_parse(permalink_text)
        except Exception:
            try:
                parsed = _parse_permalink(permalink_text)
            except Exception:
                parsed = None

        if parsed:
            _plat, _plon, _pzoom = parsed
            if lat is None: lat = _plat
            if lon is None: lon = _plon
            if zoom is None: zoom = _pzoom

        # If permalink contains x/y/crs style params, try to convert them
        # to WGS84 similarly to the plugin implementation.
        from urllib.parse import urlparse as _up, parse_qs as _pqs
        _p = _up(permalink_text)
        _qs = _pqs(_p.query)
        # If x/y are present we always convert them when a CRS is provided.
        # PyQGIS is required for non-EPSG:4326 CRSs.
        if 'x' in _qs and 'y' in _qs:
            x_val = float(_qs['x'][0])
            y_val = float(_qs['y'][0])
            crs_param = _qs.get('crs', [None])[0]
            # override zoom from query if present
            if 'zoom' in _qs:
                try:
                    zoom = float(_qs['zoom'][0])
                except Exception:
                    pass

            if crs_param and '4326' in str(crs_param):
                try:
                    lat = float(y_val)
                    lon = float(x_val)
                except Exception:
                    raise RuntimeError(f"Invalid numeric x/y for EPSG:4326: x={x_val}, y={y_val}")
            else:
                # Normalize CRS value (accept numeric like '6677')
                src_crs = None
                if crs_param:
                    s = str(crs_param).strip()
                    if re.fullmatch(r"\d+", s):
                        src_crs = f"EPSG:{s}"
                    else:
                        src_crs = s
                if not src_crs:
                    raise RuntimeError('CRS is required for x/y conversion when PyQGIS is assumed')
                try:
                    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsPointXY
                except Exception as ex:
                    raise RuntimeError('PyQGIS is required for CRS conversions but is not available') from ex
                src = QgsCoordinateReferenceSystem(str(src_crs))
                if not src.isValid():
                    raise RuntimeError(f'Invalid source CRS: {src_crs}')
                dest = QgsCoordinateReferenceSystem('EPSG:4326')
                transform = QgsCoordinateTransform(src, dest, QgsProject.instance())
                pt = transform.transform(QgsPointXY(float(x_val), float(y_val)))
                lat = float(pt.y()); lon = float(pt.x())

        # If a scale param exists prefer its zoom estimate (use shared estimator)
        try:
            from urllib.parse import urlparse as _up2, parse_qs as _pqs2
            _p2 = _up2(permalink_text)
            _qs2 = _pqs2(_p2.query)
            if 'scale' in _qs2:
                try:
                    scale_val = float(_qs2['scale'][0])
                    try:
                        from .scale_zoom import estimate_zoom_from_scale_maplibre
                        zoom_est = estimate_zoom_from_scale_maplibre(scale_val)
                        if zoom_est is not None:
                            zoom = float(zoom_est)
                    except Exception:
                        pass
                except Exception:
                    pass
        except Exception:
            pass

    # defaults
    # Validate and sanitize center coordinates. If values are missing use
    # sensible defaults. If lat appears out of the valid [-90,90] range but
    # lon looks like a latitude (and vice versa), attempt to swap them.
    def _sanitize_center(lat_in, lon_in):
        # defaults
        default_lat = 35.681236
        default_lon = 139.767125
        try:
            lat_f = float(lat_in) if lat_in is not None else None
        except Exception:
            lat_f = None
        try:
            lon_f = float(lon_in) if lon_in is not None else None
        except Exception:
            lon_f = None

        if lat_f is None and lon_f is None:
            return default_lat, default_lon
        if lat_f is None:
            lat_f = default_lat
        if lon_f is None:
            lon_f = default_lon

        def _is_lat(x):
            return -90.0 <= x <= 90.0
        def _is_lon(x):
            return -180.0 <= x <= 180.0

        # If lat is invalid but lon looks like a latitude and lat looks like a
        # longitude, swap them (common user error/order mismatch).
        if not _is_lat(lat_f) and _is_lat(lon_f) and _is_lon(lat_f):
            return float(lon_f), float(lat_f)

        # If still invalid, raise so server returns a clear error instead of
        # producing HTML that will make MapLibre fail with 'Invalid LngLat'.
        if not _is_lat(lat_f) or not _is_lon(lon_f):
            raise RuntimeError(f"Invalid center coordinates after parsing: lat={lat_f}, lon={lon_f}")

        return float(lat_f), float(lon_f)

    lat, lon = _sanitize_center(lat, lon)
    try:
        zoom = float(zoom) if zoom is not None else 10
    except Exception:
        zoom = 10

    # ensure zoom is not negative; do not impose an artificial upper bound
    try:
        zoom = max(0.0, float(zoom))
    except Exception:
        zoom = 10

    # Decide tile URL template: if tile_url param is provided use it. Otherwise
    # use the local WMTS endpoint. The server/plugin environment is expected
    # to provide /wmts/{z}/{x}/{y}.png.
    if not tile_url:
        tile_url = "/wmts/{z}/{x}/{y}.png"
    # Build HTML regardless of which tile_url was chosen
    html = f'''<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no" />
    <title>MapLibre Viewer</title>
    <link href="https://unpkg.com/maplibre-gl@latest/dist/maplibre-gl.css" rel="stylesheet" />
    <style>html,body,#map{{height:100%;margin:0;padding:0}}#map{{position:fixed;inset:0}}#controls{{position:fixed;top:10px;left:10px;z-index:2147483647;padding:8px;background:rgba(255,255,255,0.95);border:1px solid #666;border-radius:4px;box-shadow:0 2px 6px rgba(0,0,0,0.2)}}</style>
</head>
<body>
    <div id="controls">
        <div>
            <label><input type="checkbox" id="chkRaster" checked> ラスター (WMTS)</label>
            <label style="margin-left:8px"><input type="checkbox" id="chkVector"> ベクタ (VectorTile)</label>
        </div>
        <div id="vectorNote" style="font-size:12px;color:#666;margin-top:6px;display:none">Vector tiles enabled</div>
    </div>
    <div id="map"></div>
    <button id="pitchToggle" style="position:fixed;top:10px;right:10px;z-index:2147483647;padding:6px 8px;background:#fff;border:1px solid #666;border-radius:4px;cursor:pointer">斜め禁止</button>
<script src="https://unpkg.com/maplibre-gl@latest/dist/maplibre-gl.js"></script>
<script>
    try {{
        const rasterTileUrl = "{tile_url}";
        const vectorTileTemplate = "/vectortile/{{z}}/{{x}}/{{y}}.pbf";

        // initial style uses raster source
        const style = {{
            "version": 8,
            "sources": {{
                "qmap": {{
                    "type": "raster",
                    "tiles": [rasterTileUrl],
                    "tileSize": 256,
                    "attribution": "QMapPermalink WMTS"
                }}
            }},
            "layers": [ {{ "id": "qmap", "type": "raster", "source": "qmap" }} ]
        }};

        const map = new maplibregl.Map({{
            container: 'map',
            style: style,
            center: [{lon}, {lat}],
            zoom: {zoom}
        }});

        // UI helpers
        const chkRaster = document.getElementById('chkRaster');
        const chkVector = document.getElementById('chkVector');
        const vectorNote = document.getElementById('vectorNote');

        let availableVector = false;
        let vectorSourceLayer = null;

        function enableVectorUI(enabled, note) {{
            chkVector.disabled = !enabled;
            if (enabled) {{
                vectorNote.style.display = 'block';
                vectorNote.textContent = note || 'Vector tiles available';
            }} else {{
                vectorNote.style.display = 'none';
                chkVector.checked = false;
            }}
        }}

        // Probe server for vectortile.json to discover availability and layers
        fetch('/vectortile.json').then(function(resp) {{
            if (!resp.ok) throw new Error('no tilejson');
            return resp.json();
        }}).then(function(tj) {{
            if (tj && tj.tiles && tj.tiles.length) {{
                availableVector = true;
                // prefer vector_layers if present
                if (tj.vector_layers && typeof tj.vector_layers === 'object') {{
                    const keys = Object.keys(tj.vector_layers);
                    if (keys.length) vectorSourceLayer = keys[0];
                }}
                enableVectorUI(true, vectorSourceLayer ? ('layer: ' + vectorSourceLayer) : 'Vector tiles available (no layer info)');
            }} else {{
                enableVectorUI(false);
            }}
        }}).catch(function() {{ enableVectorUI(false); }});

        function removeIfExists(id) {{ try {{ if (map.getLayer(id)) map.removeLayer(id); }} catch(e) {{}} try {{ if (map.getSource(id)) map.removeSource(id); }} catch(e) {{}} }}

        function ensureRasterPresent() {{
            try {{
                if (!map.getSource('qmap')) {{
                    map.addSource('qmap', {{ type: 'raster', tiles: [rasterTileUrl], tileSize: 256 }});
                    map.addLayer({{ id: 'qmap', type: 'raster', source: 'qmap' }});
                }} else {{
                    // update tiles if changed
                    const src = map.getSource('qmap');
                    if (src && src.tiles && src.tiles.length && src.tiles[0] !== rasterTileUrl) {{
                        removeIfExists('qmap');
                        map.addSource('qmap', {{ type: 'raster', tiles: [rasterTileUrl], tileSize: 256 }});
                        map.addLayer({{ id: 'qmap', type: 'raster', source: 'qmap' }});
                    }}
                }}
            }} catch(e) {{ console.warn('ensureRasterPresent failed', e); }}
        }}

        function removeRaster() {{
            try {{ removeIfExists('qmap'); }} catch(e) {{ console.warn('removeRaster failed', e); }}
        }}

        function ensureVectorPresent() {{
            if (!availableVector) return; // safety
            try {{
                if (!map.getSource('qmap-vt')) {{
                    map.addSource('qmap-vt', {{ type: 'vector', tiles: [vectorTileTemplate] }});
                }}
                if (vectorSourceLayer) {{
                    if (!map.getLayer('qmap-vt-fill')) {{
                        map.addLayer({{ id: 'qmap-vt-fill', type: 'fill', source: 'qmap-vt', 'source-layer': vectorSourceLayer, paint: {{ 'fill-color': '#666', 'fill-opacity': 0.5 }} }});
                    }}
                    if (!map.getLayer('qmap-vt-line')) {{
                        map.addLayer({{ id: 'qmap-vt-line', type: 'line', source: 'qmap-vt', 'source-layer': vectorSourceLayer, paint: {{ 'line-color': '#222', 'line-width': 1 }} }});
                    }}
                }} else {{
                    // no source-layer info; still ensure source exists so advanced users can inspect
                    console.warn('Vector tiles available but no source-layer info in tilejson');
                }}
            }} catch(e) {{ console.warn('ensureVectorPresent failed', e); alert('Failed to enable vector layers: ' + e); }}
        }}

        function removeVector() {{
            try {{
                removeIfExists('qmap-vt-fill');
                removeIfExists('qmap-vt-line');
                removeIfExists('qmap-vt');
            }} catch(e) {{ console.warn('removeVector failed', e); }}
        }}

        // Wire UI events
        chkRaster.addEventListener('change', function() {{ if (chkRaster.checked) ensureRasterPresent(); else removeRaster(); }});
        chkVector.addEventListener('change', function() {{ if (chkVector.checked) ensureVectorPresent(); else removeVector(); }});

        // Ensure initial raster is present
        ensureRasterPresent();

        // Setup pitch toggle button to disable oblique tilt
        try {{
            const pitchBtn = document.getElementById('pitchToggle');
            // Keep rotation enabled but prevent pitch by forcing pitch=0 while locked
            let pitchLocked = true;
            const _enforcePitch = function() {{
                try {{ if (map.getPitch && Math.abs(map.getPitch()) > 0.0001) map.setPitch(0); }} catch(e) {{}}
            }};
            function lockPitch() {{
                try {{ map.setPitch(0); }} catch(e) {{}}
                try {{ if (map.on) map.on('move', _enforcePitch); }} catch(e) {{}}
                pitchLocked = true; pitchBtn.textContent = '斜め許可';
            }}
            function unlockPitch() {{
                try {{ if (map.off) map.off('move', _enforcePitch); }} catch(e) {{}}
                pitchLocked = false; pitchBtn.textContent = '斜め禁止';
            }}
            pitchBtn.addEventListener('click', function() {{ if (!pitchLocked) lockPitch(); else unlockPitch(); }});
            try {{ lockPitch(); }} catch(e) {{}}
        }} catch(e) {{ console.warn('pitch toggle setup failed', e); }}

        map.on('load', function() {{ map.resize(); }});
    }} catch (e) {{
        document.body.innerHTML = '<pre>Map init failed: ' + e.toString() + '</pre>';
    }}
</script>
</body>
</html>'''
    return html
