# -*- coding: utf-8 -*-
"""QMapPermalink WFS Service

WFS (Web Feature Service) 機能を提供する専用クラス。
QGISベクターレイヤーから地物をGeoJSON/GML形式で提供。
"""

import json
import re
from typing import Optional, Dict, Any, List, Tuple
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeatureRequest, 
    QgsJsonExporter, QgsMessageLog, Qgis, QgsRectangle,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform
)
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QColor


class QMapPermalinkWFSService:
    """QMapPermalink用WFSサービスクラス

    WFS GetCapabilitiesおよびGetFeatureリクエストを処理し、
    QGISベクターレイヤーから地物をGeoJSON/GML形式で提供します。
    """

    def __init__(self, iface, server_port: int = 8089):
        """WFSサービスを初期化

        Args:
            iface: QGISインターフェース
            server_port: サーバーポート番号
        """
        self.iface = iface
        self.server_port = server_port

    def handle_wfs_request(self, conn, params: Dict[str, list], host: Optional[str] = None) -> None:
        """WFSエンドポイントを処理"""
        from qgis.core import QgsMessageLog, Qgis

        QgsMessageLog.logMessage("🌐 Processing WFS endpoint", "QMapPermalink", Qgis.Info)

        # デバッグ情報
        QgsMessageLog.logMessage(f"🔍 WFS Request parameters: {list(params.keys())}", "QMapPermalink", Qgis.Info)

        request = params.get('REQUEST', [''])[0].upper()
        service = params.get('SERVICE', [''])[0].upper()

        if service != 'WFS':
            from . import http_server
            http_server.send_wfs_error_response(conn, "InvalidParameterValue", "SERVICE parameter must be WFS", locator='SERVICE')
            return

        if request == 'GETCAPABILITIES':
            self._handle_wfs_get_capabilities(conn, params, host)
        elif request == 'GETFEATURE':
            self._handle_wfs_get_feature(conn, params)
        elif request == 'DESCRIBEFEATURETYPE':
            self._handle_wfs_describe_feature_type(conn, params)
        elif request == 'GETSTYLES':
            self._handle_wfs_get_styles(conn, params)
        else:
            from . import http_server
            http_server.send_wfs_error_response(conn, "InvalidRequest", f"Request {request} is not supported")

    def _handle_wfs_get_capabilities(self, conn, params: Dict[str, list], host: Optional[str] = None) -> None:
        """WFS GetCapabilitiesリクエストを処理"""
        from qgis.core import QgsMessageLog, Qgis

        # Determine base host for OnlineResource entries
        try:
            base_host = host if host else f"localhost:{self.server_port}"
        except Exception:
            base_host = f"localhost:{self.server_port}"

        # Prefer project-level WFSLayers entry if present (same logic as /wfs-layers)
        project = QgsProject.instance()
        try:
            wfs_ids, ok = project.readListEntry('WFSLayers', '/')
        except Exception:
            wfs_ids, ok = ([], False)

        vector_layers = []
        if ok and wfs_ids:
            for lid in [str(i) for i in wfs_ids]:
                try:
                    layer = QgsProject.instance().mapLayer(lid)
                    if not layer:
                        continue
                    # only include vector layers
                    if isinstance(layer, QgsVectorLayer):
                        vector_layers.append(layer)
                except Exception:
                    continue
        else:
            # No WFSLayers defined -> return empty FeatureTypeList
            from . import http_server
            xml_content = (
                f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                f"<WFS_Capabilities version=\"2.0.0\" xmlns=\"http://www.opengis.net/wfs/2.0\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" xsi:schemaLocation=\"http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd\">\n"
                f"  <ServiceIdentification>\n"
                f"    <Title>QGIS Map Permalink WFS Service</Title>\n"
                f"    <Abstract>Dynamic WFS service for QGIS vector layers</Abstract>\n"
                f"    <ServiceType>WFS</ServiceType>\n"
                f"    <ServiceTypeVersion>2.0.0</ServiceTypeVersion>\n"
                f"  </ServiceIdentification>\n"
                f"  <FeatureTypeList>\n"
                f"  </FeatureTypeList>\n"
                f"</WFS_Capabilities>"
            )
            http_server.send_http_response(conn, 200, "OK", xml_content, content_type="text/xml; charset=utf-8")
            return

        # Build FeatureType entries
        feature_types_xml = ""
        for layer in vector_layers:
            layer_name = layer.name().replace(' ', '_')
            crs = layer.crs().authid() if layer.crs().isValid() else 'EPSG:4326'
            extent = self._get_layer_extent(layer)

            feature_types_xml += (
                f"\n    <FeatureType>"
                f"\n      <Name>{layer_name}</Name>"
                f"\n      <Title>{layer.name()}</Title>"
                f"\n      <Abstract>Vector layer from QGIS project</Abstract>"
                f"\n      <DefaultCRS>{crs}</DefaultCRS>"
                f"\n      <OutputFormats>"
                f"\n        <Format>application/json</Format>"
                f"\n        <Format>application/gml+xml</Format>"
                f"\n      </OutputFormats>"
                f"\n      <WGS84BoundingBox>"
                f"\n        <LowerCorner>{extent['minx']} {extent['miny']}</LowerCorner>"
                f"\n        <UpperCorner>{extent['maxx']} {extent['maxy']}</UpperCorner>"
                f"\n      </WGS84BoundingBox>"
                f"\n    </FeatureType>"
            )

        xml_content = (
            f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
            f"<WFS_Capabilities version=\"2.0.0\" xmlns=\"http://www.opengis.net/wfs/2.0\" "
            f"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
            f"xmlns:xlink=\"http://www.w3.org/1999/xlink\" "
            f"xsi:schemaLocation=\"http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd\">\n"
            f"  <ServiceIdentification>\n"
            f"    <Title>QGIS Map Permalink WFS Service</Title>\n"
            f"    <Abstract>Dynamic WFS service for QGIS vector layers</Abstract>\n"
            f"    <ServiceType>WFS</ServiceType>\n"
            f"    <ServiceTypeVersion>2.0.0</ServiceTypeVersion>\n"
            f"    <Fees>NONE</Fees>\n"
            f"    <AccessConstraints>NONE</AccessConstraints>\n"
            f"  </ServiceIdentification>\n"
            f"  <ServiceProvider>\n"
            f"    <ProviderName>QMapPermalink</ProviderName>\n"
            f"  </ServiceProvider>\n"
            f"  <OperationsMetadata>\n"
            f"    <Operation name=\"GetCapabilities\">\n"
            f"      <DCP><HTTP><Get xlink:href=\"http://{base_host}/wfs\"/></HTTP></DCP>\n"
            f"    </Operation>\n"
            f"    <Operation name=\"DescribeFeatureType\">\n"
            f"      <DCP><HTTP><Get xlink:href=\"http://{base_host}/wfs\"/></HTTP></DCP>\n"
            f"    </Operation>\n"
            f"    <Operation name=\"GetFeature\">\n"
            f"      <DCP><HTTP><Get xlink:href=\"http://{base_host}/wfs\"/></HTTP></DCP>\n"
            f"    </Operation>\n"
            f"    <Operation name=\"GetStyles\">\n"
            f"      <DCP><HTTP><Get xlink:href=\"http://{base_host}/wfs\"/></HTTP></DCP>\n"
            f"    </Operation>\n"
            f"  </OperationsMetadata>\n"
            f"  <FeatureTypeList>{feature_types_xml}\n"
            f"  </FeatureTypeList>\n"
            f"</WFS_Capabilities>"
        )

        from . import http_server
        http_server.send_http_response(conn, 200, "OK", xml_content, content_type="text/xml; charset=utf-8")

    def _handle_wfs_get_feature(self, conn, params: Dict[str, list]) -> None:
        """WFS GetFeatureリクエストを処理"""
        from qgis.core import QgsMessageLog, Qgis

        try:
            # パラメータの解析
            type_name = params.get('TYPENAME', params.get('TYPENAMES', ['']))[0]
            if not type_name:
                from . import http_server
                http_server.send_wfs_error_response(conn, "MissingParameterValue", "TYPENAME parameter is required", locator='TYPENAME')
                return

            output_format = params.get('OUTPUTFORMAT', ['application/json'])[0]
            max_features = params.get('MAXFEATURES', [None])[0]
            if max_features:
                try:
                    max_features = int(max_features)
                except:
                    max_features = None

            bbox = params.get('BBOX', [None])[0]
            srs_name = params.get('SRSNAME', [None])[0]

            # レイヤーの検索
            layer = self._find_layer_by_name(type_name)
            if not layer:
                from . import http_server
                http_server.send_wfs_error_response(conn, "InvalidParameterValue", f"Layer '{type_name}' not found", locator='TYPENAME')
                return

            # 地物のクエリ
            features = self._query_features(layer, bbox, srs_name, max_features)

            # 出力フォーマットに応じたレスポンス生成（柔軟な判定）
            of = (output_format or '').lower()
            if 'gml' in of or of in ('gml', 'application/gml+xml'):
                response_content = self._features_to_gml(features, layer)
                content_type = "application/gml+xml; charset=utf-8"
            else:
                # default/fallback to GeoJSON
                response_content = self._features_to_geojson(features, layer)
                content_type = "application/json; charset=utf-8"

            from . import http_server
            http_server.send_http_response(conn, 200, "OK", response_content, content_type=content_type)

        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            import traceback
            QgsMessageLog.logMessage(f"❌ WFS GetFeature error: {e}", "QMapPermalink", Qgis.Critical)
            QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            from . import http_server
            # Return an OWS-style ExceptionReport for better WFS compatibility
            try:
                http_server.send_wfs_error_response(conn, "InternalError", f"WFS GetFeature failed: {str(e)}")
            except Exception:
                http_server.send_http_response(conn, 500, "Internal Server Error", f"WFS GetFeature failed: {str(e)}")

    def _handle_wfs_describe_feature_type(self, conn, params: Dict[str, list]) -> None:
        """WFS DescribeFeatureTypeリクエストを処理"""
        from qgis.core import QgsMessageLog, Qgis

        try:
            type_name = params.get('TYPENAME', params.get('TYPENAMES', ['']))[0]
            if not type_name:
                from . import http_server
                http_server.send_wfs_error_response(conn, "MissingParameterValue", "TYPENAME parameter is required", locator='TYPENAME')
                return

            # レイヤーの検索
            layer = self._find_layer_by_name(type_name)
            if not layer:
                from . import http_server
                http_server.send_wfs_error_response(conn, "InvalidParameterValue", f"Layer '{type_name}' not found", locator='TYPENAME')
                return

            # スキーマの生成
            schema_xml = self._generate_feature_type_schema(layer)

            from . import http_server
            http_server.send_http_response(conn, 200, "OK", schema_xml, content_type="text/xml; charset=utf-8")

        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            import traceback
            QgsMessageLog.logMessage(f"❌ WFS DescribeFeatureType error: {e}", "QMapPermalink", Qgis.Critical)
            from . import http_server
            http_server.send_http_response(conn, 500, "Internal Server Error", f"WFS DescribeFeatureType failed: {str(e)}")

    def _handle_wfs_get_styles(self, conn, params: Dict[str, list]) -> None:
        """WFS GetStylesリクエストを処理"""
        from qgis.core import QgsMessageLog, Qgis

        try:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage("🌐 Processing GetStyles request", "QMapPermalink", Qgis.Info)
            
            type_name = params.get('TYPENAME', params.get('TYPENAMES', ['']))[0]
            if not type_name:
                from . import http_server
                http_server.send_wfs_error_response(conn, "MissingParameterValue", "TYPENAME parameter is required", locator='TYPENAME')
                return

            # レイヤーの検索
            layer = self._find_layer_by_name(type_name)
            if not layer:
                from . import http_server
                http_server.send_wfs_error_response(conn, "InvalidParameterValue", f"Layer '{type_name}' not found", locator='TYPENAME')
                return

            # SLDの生成
            sld_xml = self._generate_sld(layer)

            from . import http_server
            http_server.send_http_response(conn, 200, "OK", sld_xml, content_type="application/vnd.ogc.sld+xml; charset=utf-8")

        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            import traceback
            QgsMessageLog.logMessage(f"❌ WFS GetStyles error: {e}", "QMapPermalink", Qgis.Critical)
            from . import http_server
            http_server.send_http_response(conn, 500, "Internal Server Error", f"WFS GetStyles failed: {str(e)}")

    def _get_vector_layers(self) -> List[QgsVectorLayer]:
        """プロジェクトからベクターレイヤーを取得"""
        project = QgsProject.instance()

        # Prefer project-level WFSLayers entry if present (QGIS project OWS/WFS export list)
        try:
            wfs_ids, ok = project.readListEntry('WFSLayers', '/')
        except Exception:
            wfs_ids, ok = ([], False)

        vector_layers: List[QgsVectorLayer] = []

        if ok and wfs_ids:
            # Iterate only the IDs listed in the project WFSLayers entry
            for lid in [str(i) for i in wfs_ids]:
                try:
                    layer = QgsProject.instance().mapLayer(lid)
                    if not layer:
                        continue
                    if isinstance(layer, QgsVectorLayer):
                        vector_layers.append(layer)
                except Exception:
                    continue

        # If no WFSLayers defined in the project, return empty list (do not
        # fall back to publishing all vector layers).
        return vector_layers

    def _find_layer_by_name(self, type_name: str) -> Optional[QgsVectorLayer]:
        """レイヤー名でレイヤーを検索"""
        vector_layers = self._get_vector_layers()

        # スペースをアンダースコアに変換して比較
        normalized_type_name = type_name.replace('_', ' ')

        for layer in vector_layers:
            if layer.name() == normalized_type_name or layer.name().replace(' ', '_') == type_name:
                return layer

        return None

    def _get_layer_extent(self, layer: QgsVectorLayer) -> Dict[str, float]:
        """レイヤーの範囲を取得（WGS84に変換）"""
        try:
            extent = layer.extent()
            crs = layer.crs()

            if crs.authid() != 'EPSG:4326':
                transform = QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem('EPSG:4326'), QgsProject.instance())
                extent = transform.transformBoundingBox(extent)

            return {
                'minx': extent.xMinimum(),
                'miny': extent.yMinimum(),
                'maxx': extent.xMaximum(),
                'maxy': extent.yMaximum()
            }
        except:
            return {'minx': -180, 'miny': -90, 'maxx': 180, 'maxy': 90}

    def _query_features(self, layer: QgsVectorLayer, bbox: Optional[str] = None,
                       srs_name: Optional[str] = None, max_features: Optional[int] = None) -> List:
        """レイヤーから地物をクエリ"""
        request = QgsFeatureRequest()

        # BBOXフィルタ
        if bbox:
            try:
                coords = [float(x) for x in bbox.split(',')]
                if len(coords) == 4:
                    minx, miny, maxx, maxy = coords
                    rect = QgsRectangle(minx, miny, maxx, maxy)

                    # SRS変換
                    if srs_name and srs_name != layer.crs().authid():
                        src_crs = QgsCoordinateReferenceSystem(srs_name)
                        tgt_crs = layer.crs()
                        if src_crs.isValid():
                            transform = QgsCoordinateTransform(src_crs, tgt_crs, QgsProject.instance())
                            rect = transform.transformBoundingBox(rect)

                    request.setFilterRect(rect)
            except:
                pass

        # 最大地物数
        if max_features:
            request.setLimit(max_features)

        # 地物取得
        features = []
        for feature in layer.getFeatures(request):
            features.append(feature)

        return features

    def _features_to_geojson(self, features: List, layer: QgsVectorLayer) -> str:
        """地物をGeoJSONに変換"""
        exporter = QgsJsonExporter(layer)

        # GeoJSON FeatureCollectionの作成
        geojson = {
            "type": "FeatureCollection",
            "features": []
        }

        for feature in features:
            feature_json = json.loads(exporter.exportFeature(feature))

            # try to attach simple style hints extracted from the QGIS symbol
            try:
                style_hint = self._extract_style_hint(layer, feature)
                if 'properties' not in feature_json or feature_json['properties'] is None:
                    feature_json['properties'] = {}
                # only attach if we obtained something useful
                if style_hint:
                    # attach the raw style hint under _qgis_style for compatibility
                    feature_json['properties']['_qgis_style'] = style_hint
                    # and also flatten useful keys to top-level properties so
                    # client templates can access them directly without nested
                    # ['get', <prop>, ['get', '_qgis_style']] expressions which
                    # are error-prone in some MapLibre builds.
                    for sk, sv in style_hint.items():
                        try:
                            # don't overwrite an existing explicit property
                            if sk not in feature_json['properties']:
                                feature_json['properties'][sk] = sv
                        except Exception:
                            # ignore individual property failures
                            pass
            except Exception:
                # non-fatal; leave feature as-is
                pass

            # Try to attach a human-readable label for the feature if available.
            # This uses the layer's displayExpression (if set) or the layer's
            # display field as a fallback.
            try:
                label_text = self._extract_feature_label(layer, feature)
                if label_text is not None:
                    try:
                        s = str(label_text).strip()
                    except Exception:
                        s = ''

                    # Treat empty strings, whitespace-only, and common null-like tokens as no label
                    if s and s.lower() not in ('null', 'none', 'nan'):
                        if 'properties' not in feature_json or feature_json['properties'] is None:
                            feature_json['properties'] = {}
                        feature_json['properties']['label'] = s
                        try:
                            # Log label extraction for debugging in QGIS message log
                            from qgis.core import QgsMessageLog, Qgis
                            QgsMessageLog.logMessage(f"WFS: feature {feature.id()} label='{s}'", "QMapPermalink", Qgis.Info)
                        except Exception:
                            pass
            except Exception:
                # non-fatal
                pass

            geojson["features"].append(feature_json)

        return json.dumps(geojson, ensure_ascii=False, indent=2)

    def _extract_style_hint(self, layer: QgsVectorLayer, feature) -> Dict[str, Any]:
        """Extract a minimal style hint for a feature from the layer's renderer.

        Returns a dict suitable for client-side MapLibre usage, e.g.
        { 'geomType':'LineString', 'stroke':'#rrggbb', 'stroke-width':2 }

        This is best-effort: we handle simple single-symbol renderers and
        fall back to empty dict for complex cases.
        """
        try:
            from qgis.core import (QgsMarkerSymbol, QgsLineSymbol, QgsFillSymbol,
                                   QgsRuleBasedRenderer, QgsCategorizedSymbolRenderer,
                                   QgsRenderContext, QgsExpressionContext,
                                   QgsExpressionContextUtils)
            renderer = layer.renderer()
            if renderer is None:
                return {}

            # Create render context for symbolForFeature
            context = QgsRenderContext()
            context.setExpressionContext(QgsExpressionContext())
            context.expressionContext().appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
            context.expressionContext().setFeature(feature)

            # Get the actual symbol for this feature
            symbol = renderer.symbolForFeature(feature, context)
            if symbol is None:
                return {}

            style = {}

            # Extract geometry type
            if isinstance(symbol, QgsMarkerSymbol):
                style['geomType'] = 'Point'
            elif isinstance(symbol, QgsLineSymbol):
                style['geomType'] = 'LineString'
            elif isinstance(symbol, QgsFillSymbol):
                style['geomType'] = 'Polygon'

            # Extract color information
            try:
                color = symbol.color()
                if hasattr(color, 'name') and color.isValid():
                    if isinstance(symbol, (QgsLineSymbol, QgsMarkerSymbol)):
                        style['stroke'] = color.name()
                    elif isinstance(symbol, QgsFillSymbol):
                        style['fill'] = color.name()
            except Exception:
                pass

            # Extract stroke width for lines
            if isinstance(symbol, QgsLineSymbol):
                try:
                    width = symbol.width()
                    if width > 0:
                        style['stroke-width'] = width
                except Exception:
                    pass

            # Extract fill opacity for polygons
            if isinstance(symbol, QgsFillSymbol):
                try:
                    opacity = symbol.opacity()
                    if opacity < 1.0:
                        style['fill-opacity'] = opacity
                except Exception:
                    pass

            return style
        except Exception:
            return {}

    def _extract_feature_label(self, layer: QgsVectorLayer, feature) -> str:
        """Extract a display label for a feature.

        Tries the layer's displayExpression first, then falls back to the
        display field. Returns an empty string if no label can be determined.
        """
        try:
            # First, prefer explicit labeling settings if present. Many users
            # configure labels via the layer's labeling (QgsPalLayerSettings) —
            # prefer that over the displayExpression/displayField heuristics.
            try:
                lab = None
                try:
                    lab = layer.labeling()
                except Exception:
                    lab = None
                if lab is not None:
                    try:
                        settings = lab.settings()
                    except Exception:
                        settings = None
                    if settings is not None:
                        # settings may expose methods or attributes depending on QGIS
                        # version. Try to obtain an expression first, then a field name.
                        expr_candidate = None
                        field_candidate = None
                        try:
                            if hasattr(settings, 'expression'):
                                expr_candidate = settings.expression() if callable(getattr(settings, 'expression')) else settings.expression
                        except Exception:
                            expr_candidate = None
                        try:
                            if hasattr(settings, 'fieldName'):
                                field_candidate = settings.fieldName() if callable(getattr(settings, 'fieldName')) else settings.fieldName
                        except Exception:
                            field_candidate = None

                        # If an expression is configured in the labeling settings, evaluate it
                        if expr_candidate:
                            try:
                                from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils
                                expr = QgsExpression(str(expr_candidate))
                                ctx = QgsExpressionContext()
                                ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                                ctx.setFeature(feature)
                                val = expr.evaluate(ctx)
                                if not expr.hasEvalError() and val is not None:
                                    return str(val)
                            except Exception:
                                # fall through to fieldCandidate/displayExpression
                                pass

                        # If a field name is configured for labeling, use the attribute
                        if field_candidate:
                            try:
                                val = feature.attribute(field_candidate)
                                if val is not None:
                                    return str(val)
                            except Exception:
                                pass
            except Exception:
                # ignore labeling inspection errors and continue to other fallbacks
                pass

            # Next, prefer displayExpression (can be an expression like "concat(name, ' (', id, ')')")
            expr_str = ''
            try:
                # method exists on QgsVectorLayer in modern QGIS
                expr_str = layer.displayExpression()
            except Exception:
                expr_str = ''

            if expr_str:
                try:
                    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils
                    expr = QgsExpression(expr_str)
                    ctx = QgsExpressionContext()
                    # include project and layer scopes so functions like @project can work
                    ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                    ctx.setFeature(feature)
                    val = expr.evaluate(ctx)
                    if expr.hasEvalError():
                        # fall through to field fallback
                        raise Exception('expression eval error')
                    return '' if val is None else str(val)
                except Exception:
                    pass

            # Fallback: layer.displayField() or form display field
            try:
                df = None
                try:
                    df = layer.displayField()
                except Exception:
                    df = None
                if df:
                    val = feature.attribute(df)
                    return '' if val is None else str(val)
            except Exception:
                pass

        except Exception:
            pass

        return ''

    def _features_to_gml(self, features: List, layer: QgsVectorLayer) -> str:
        """地物をGMLに変換（簡易版）"""
        layer_name = layer.name().replace(' ', '_')
        crs = layer.crs().authid() if layer.crs().isValid() else 'EPSG:4326'

        gml = f"""<?xml version="1.0" encoding="UTF-8"?>
<wfs:FeatureCollection xmlns:wfs="http://www.opengis.net/wfs"
                       xmlns:gml="http://www.opengis.net/gml"
                       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                       xsi:schemaLocation="http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.1.0/wfs.xsd">
"""

        for feature in features:
            geom = feature.geometry()
            if geom:
                gml_geom = self._geometry_to_gml(geom, crs)
                properties = self._feature_properties_to_gml(feature)

                gml += f"""  <gml:featureMember>
    <{layer_name} gml:id="{feature.id()}">
      <gml:boundedBy>
        <gml:Envelope srsName="{crs}">
          <gml:lowerCorner>{geom.boundingBox().xMinimum()} {geom.boundingBox().yMinimum()}</gml:lowerCorner>
          <gml:upperCorner>{geom.boundingBox().xMaximum()} {geom.boundingBox().yMaximum()}</gml:upperCorner>
        </gml:Envelope>
      </gml:boundedBy>
      {gml_geom}
      {properties}
    </{layer_name}>
  </gml:featureMember>
"""

        gml += "</wfs:FeatureCollection>"
        return gml

    def _geometry_to_gml(self, geometry, crs: str) -> str:
        """ジオメトリをGMLに変換（簡易版）"""
        if geometry.isEmpty():
            return ""

        wkt = geometry.asWkt()
        wkt_u = wkt.upper()

        # helper: extract list of (x,y) tuples from a coordinate string
        def _coords_from_str(s: str):
            parts = [p.strip() for p in s.split(',') if p.strip()]
            coords = []
            for p in parts:
                nums = re.findall(r"[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?", p)
                if len(nums) >= 2:
                    coords.append((nums[0], nums[1]))
            return coords

        # Point
        if wkt_u.startswith('POINT'):
            inner = wkt[wkt.find('(') + 1:wkt.rfind(')')]
            nums = re.findall(r"[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?", inner)
            if len(nums) >= 2:
                return f'<gml:Point srsName="{crs}"><gml:coordinates>{nums[0]},{nums[1]}</gml:coordinates></gml:Point>'
            return ''

        # MultiPoint
        if wkt_u.startswith('MULTIPOINT'):
            inner = wkt[wkt.find('(') + 1:wkt.rfind(')')]
            # normalize cases like ((x y),(x y)) and (x y, x y)
            inner = inner.replace('),(', ');(').replace(') , (', ');(')
            # split on ');(' or commas
            parts = []
            if ');(' in inner:
                parts = [p.replace('(', '').replace(')', '').strip() for p in inner.split(');(')]
            else:
                parts = [p.strip() for p in inner.split(',') if p.strip()]
            pts = []
            for p in parts:
                nums = re.findall(r"[-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?", p)
                if len(nums) >= 2:
                    pts.append((nums[0], nums[1]))
            if not pts:
                return ''
            out = [f'<gml:Point srsName="{crs}"><gml:coordinates>{x},{y}</gml:coordinates></gml:Point>' for x, y in pts]
            members = '\n'.join([f'    <gml:pointMember>{p}</gml:pointMember>' for p in out])
            return f'<gml:MultiPoint srsName="{crs}">\n{members}\n</gml:MultiPoint>'

        # LineString / MultiLineString
        if wkt_u.startswith('LINESTRING') or wkt_u.startswith('MULTILINESTRING'):
            if wkt_u.startswith('LINESTRING'):
                inner = wkt[wkt.find('(') + 1:wkt.rfind(')')]
                coords = _coords_from_str(inner)
                coord_str = ' '.join([f"{x},{y}" for x, y in coords])
                return f'<gml:LineString srsName="{crs}"><gml:coordinates>{coord_str}</gml:coordinates></gml:LineString>'

            # MULTILINESTRING
            inner = wkt[wkt.find('(') + 1:wkt.rfind(')')]
            # extract each linestring by finding parenthesis groups
            groups = re.findall(r"\([^()]*\)", inner)
            members = []
            for g in groups:
                txt = g.replace('(', '').replace(')', '')
                coords = _coords_from_str(txt)
                if coords:
                    coord_str = ' '.join([f"{x},{y}" for x, y in coords])
                    members.append(f'<gml:lineStringMember><gml:LineString srsName="{crs}"><gml:coordinates>{coord_str}</gml:coordinates></gml:LineString></gml:lineStringMember>')
            if members:
                return f'<gml:MultiLineString srsName="{crs}">\n' + '\n'.join(members) + '\n</gml:MultiLineString>'
            return ''

        # Polygon / MultiPolygon (outer rings only)
        if wkt_u.startswith('POLYGON') or wkt_u.startswith('MULTIPOLYGON'):
            if wkt_u.startswith('POLYGON'):
                # extract first linear ring
                inner = wkt[wkt.find('((') + 2:wkt.rfind('))')]
                coords = _coords_from_str(inner)
                coord_str = ' '.join([f"{x},{y}" for x, y in coords])
                return f'<gml:Polygon srsName="{crs}"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>{coord_str}</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon>'

            # MULTIPOLYGON
            inner = wkt[wkt.find('(') + 1:wkt.rfind(')')]
            # find polygon groups like ((...))
            poly_groups = re.findall(r"\(\([^()]*\)\)", wkt)
            members = []
            for pg in poly_groups:
                ring = pg.replace('(', '').replace(')', '')
                coords = _coords_from_str(ring)
                if coords:
                    coord_str = ' '.join([f"{x},{y}" for x, y in coords])
                    members.append(f'<gml:polygonMember><gml:Polygon srsName="{crs}"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>{coord_str}</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember>')
            if members:
                return f'<gml:MultiPolygon srsName="{crs}">\n' + '\n'.join(members) + '\n</gml:MultiPolygon>'
            return ''

        # Fallback: return empty string for unsupported/complex types
        return ""

    def _feature_properties_to_gml(self, feature) -> str:
        """地物の属性をGMLに変換"""
        properties = ""
        fields = feature.fields()

        for i in range(fields.count()):
            field = fields.field(i)
            value = feature.attribute(i)
            if value is not None:
                properties += f"      <{field.name()}>{str(value)}</{field.name()}>\n"

        return properties

    def _generate_feature_type_schema(self, layer: QgsVectorLayer) -> str:
        """レイヤーのスキーマをXMLで生成"""
        layer_name = layer.name().replace(' ', '_')
        # XML名前空間プレフィックスとして有効なASCIIのみの名前を作成
        safe_prefix = ''.join(c for c in layer_name if ord(c) < 128 and c.isalnum() or c == '_')
        if not safe_prefix:
            safe_prefix = 'layer'
        # ユニークな名前空間URIを作成（ASCIIのみ）
        namespace_uri = f"http://www.opengis.net/{safe_prefix}"
        
        fields = layer.fields()

        schema = f"""<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            xmlns:gml="http://www.opengis.net/gml"
            xmlns:{safe_prefix}="{namespace_uri}"
            targetNamespace="{namespace_uri}"
            elementFormDefault="qualified">
  <xsd:import namespace="http://www.opengis.net/gml" schemaLocation="http://schemas.opengis.net/gml/3.1.1/base/gml.xsd"/>
  <xsd:element name="{layer_name}" type="{safe_prefix}:{layer_name}Type" substitutionGroup="gml:_Feature"/>
  <xsd:complexType name="{layer_name}Type">
    <xsd:complexContent>
      <xsd:extension base="gml:AbstractFeatureType">
        <xsd:sequence>
"""

        for field in fields:
            field_type = self._qgis_field_type_to_xsd(field.typeName())
            schema += f"""          <xsd:element name="{field.name()}" type="{field_type}" nillable="true" minOccurs="0"/>
"""

        schema += f"""        </xsd:sequence>
      </xsd:extension>
    </xsd:complexContent>
  </xsd:complexType>
</xsd:schema>"""

        return schema

    def _qgis_field_type_to_xsd(self, qgis_type: str) -> str:
        """QGISフィールドタイプをXSDタイプに変換"""
        type_mapping = {
            'integer': 'xsd:int',
            'int4': 'xsd:int',
            'int8': 'xsd:long',
            'real': 'xsd:double',
            'double': 'xsd:double',
            'string': 'xsd:string',
            'text': 'xsd:string',
            'varchar': 'xsd:string',
            'date': 'xsd:date',
            'datetime': 'xsd:dateTime'
        }

        return type_mapping.get(qgis_type.lower(), 'xsd:string')

    def _generate_sld(self, layer: QgsVectorLayer) -> str:
        """レイヤーのSLDを生成"""
        layer_name = layer.name().replace(' ', '_')
        
        # デフォルトシンボルを取得
        renderer = layer.renderer()
        if renderer is None:
            return self._generate_default_sld(layer_name)
        
        # ルールベースレンダラーの場合、デフォルトを使用（symbolForFeatureが失敗する）
        from qgis.core import QgsRuleBasedRenderer
        if isinstance(renderer, QgsRuleBasedRenderer):
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"⚠️ Rule-based renderer detected for layer {layer_name}, using default SLD", "QMapPermalink", Qgis.Warning)
            return self._generate_default_sld(layer_name)
        
        # symbolForFeatureを使ってデフォルトシンボルを取得
        symbol = None
        try:
            from qgis.core import (QgsRenderContext, QgsExpressionContext,
                                   QgsExpressionContextUtils, QgsFeature)
            dummy_feature = QgsFeature()
            context = QgsRenderContext()
            context.setExpressionContext(QgsExpressionContext())
            context.expressionContext().appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
            context.expressionContext().setFeature(dummy_feature)
            symbol = renderer.symbolForFeature(dummy_feature, context)
        except Exception as e:
            # symbolForFeatureが失敗したら、デフォルトを使用
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"⚠️ symbolForFeature failed for layer {layer_name}: {e}, using default SLD", "QMapPermalink", Qgis.Warning)
            return self._generate_default_sld(layer_name)
        
        if symbol is None:
            return self._generate_default_sld(layer_name)
        
        # シンボルタイプに応じたSLD生成
        from qgis.core import QgsMarkerSymbol, QgsLineSymbol, QgsFillSymbol
        
        if isinstance(symbol, QgsMarkerSymbol):
            return self._generate_point_sld(layer_name, symbol)
        elif isinstance(symbol, QgsLineSymbol):
            return self._generate_line_sld(layer_name, symbol)
        elif isinstance(symbol, QgsFillSymbol):
            return self._generate_polygon_sld(layer_name, symbol)
        else:
            return self._generate_default_sld(layer_name)

    def _generate_default_sld(self, layer_name: str) -> str:
        """デフォルトSLDを生成"""
        sld = f"""<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.1.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.1.0/StyledLayerDescriptor.xsd">
  <NamedLayer>
    <Name>{layer_name}</Name>
    <UserStyle>
      <Title>Default Style</Title>
      <FeatureTypeStyle>
        <Rule>
          <Name>default</Name>
          <PolygonSymbolizer>
            <Fill>
              <CssParameter name="fill">#808080</CssParameter>
              <CssParameter name="fill-opacity">0.5</CssParameter>
            </Fill>
            <Stroke>
              <CssParameter name="stroke">#000000</CssParameter>
              <CssParameter name="stroke-width">1</CssParameter>
            </Stroke>
          </PolygonSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>"""
        return sld

    def _generate_point_sld(self, layer_name: str, symbol) -> str:
        """ポイントシンボルのSLDを生成"""
        try:
            color = symbol.color()
            size = symbol.size()
            stroke_color = color.name() if color.isValid() else "#000000"
            fill_color = stroke_color
            point_size = size if size > 0 else 6
            
            sld = f"""<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.1.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.1.0/StyledLayerDescriptor.xsd">
  <NamedLayer>
    <Name>{layer_name}</Name>
    <UserStyle>
      <Title>Point Style</Title>
      <FeatureTypeStyle>
        <Rule>
          <Name>point</Name>
          <PointSymbolizer>
            <Graphic>
              <Mark>
                <WellKnownName>circle</WellKnownName>
                <Fill>
                  <CssParameter name="fill">{fill_color}</CssParameter>
                </Fill>
                <Stroke>
                  <CssParameter name="stroke">{stroke_color}</CssParameter>
                  <CssParameter name="stroke-width">1</CssParameter>
                </Stroke>
              </Mark>
              <Size>{point_size}</Size>
            </Graphic>
          </PointSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>"""
            return sld
        except Exception:
            return self._generate_default_sld(layer_name)

    def _generate_line_sld(self, layer_name: str, symbol) -> str:
        """ラインシンボルのSLDを生成"""
        try:
            color = symbol.color()
            width = symbol.width()
            stroke_color = color.name() if color.isValid() else "#000000"
            stroke_width = width if width > 0 else 2
            
            sld = f"""<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.1.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.1.0/StyledLayerDescriptor.xsd">
  <NamedLayer>
    <Name>{layer_name}</Name>
    <UserStyle>
      <Title>Line Style</Title>
      <FeatureTypeStyle>
        <Rule>
          <Name>line</Name>
          <LineSymbolizer>
            <Stroke>
              <CssParameter name="stroke">{stroke_color}</CssParameter>
              <CssParameter name="stroke-width">{stroke_width}</CssParameter>
            </Stroke>
          </LineSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>"""
            return sld
        except Exception:
            return self._generate_default_sld(layer_name)

    def _generate_polygon_sld(self, layer_name: str, symbol) -> str:
        """ポリゴンシンボルのSLDを生成"""
        try:
            fill_color_obj = symbol.color()
            stroke_color_obj = symbol.strokeColor()
            stroke_width = symbol.strokeWidth()
            
            fill_color = fill_color_obj.name() if fill_color_obj.isValid() else "#808080"
            stroke_color = stroke_color_obj.name() if stroke_color_obj.isValid() else "#000000"
            stroke_width = stroke_width if stroke_width > 0 else 1
            
            opacity = symbol.opacity()
            fill_opacity = opacity if opacity >= 0 else 0.5
            
            sld = f"""<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor version="1.1.0" xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.1.0/StyledLayerDescriptor.xsd">
  <NamedLayer>
    <Name>{layer_name}</Name>
    <UserStyle>
      <Title>Polygon Style</Title>
      <FeatureTypeStyle>
        <Rule>
          <Name>polygon</Name>
          <PolygonSymbolizer>
            <Fill>
              <CssParameter name="fill">{fill_color}</CssParameter>
              <CssParameter name="fill-opacity">{fill_opacity}</CssParameter>
            </Fill>
            <Stroke>
              <CssParameter name="stroke">{stroke_color}</CssParameter>
              <CssParameter name="stroke-width">{stroke_width}</CssParameter>
            </Stroke>
          </PolygonSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>"""
            return sld
        except Exception:
            return self._generate_default_sld(layer_name)