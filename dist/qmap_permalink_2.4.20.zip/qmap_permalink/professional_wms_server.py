# -*- coding: utf-8 -*-
"""
QMap Permalink Server Manager - 本格的WMS実装
QGISレイヤ状態を踏襲し、任意位置を自由にレンダリングする本格的なWMSサーバー

Version: 1.10.11
Target: QGISデスクトップのレイヤ表示状態は踏襲してもよいが、表示位置等を自由に変えれる本格的なWMS
"""

import socket
import threading
import urllib.parse
import os
import tempfile
import time
from PyQt5.QtCore import QObject, pyqtSignal
from . import http_server


class ProfessionalWMSServer(QObject):
    """本格的なWMSサーバー - レイヤ状態踏襲＋自由位置レンダリング"""
    
    server_started = pyqtSignal()
    server_stopped = pyqtSignal()
    server_error = pyqtSignal(str)
    
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.server_port = 8089
        self.is_running = False
        self.server_socket = None
        self.server_thread = None
        self.plugin_version = "1.10.11"
        
        # WMSレンダリング設定
        self.professional_mode = True  # 本格的WMSモード
        self.preserve_layer_states = True  # レイヤ状態踏襲
        self.independent_positioning = True  # 独立した位置レンダリング
        # 任意のCRSを強制的にEPSG:3857として扱うオプション（デフォルト: False）
        self.force_epsg3857 = False
        
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(f"🚀 Professional WMS Server initialized v{self.plugin_version}", "QMapPermalink", Qgis.Info)
    
    def stop_server(self):
        """本格的WMSサーバーを停止"""
        if not self.is_running:
            return
            
        self.is_running = False
        
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
                
        if self.server_thread:
            self.server_thread.join(timeout=2.0)
            
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage("🛑 Professional WMS Server stopped", "QMapPermalink", Qgis.Info)
        self.server_stopped.emit()