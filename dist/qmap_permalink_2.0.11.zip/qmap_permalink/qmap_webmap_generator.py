"""
Minimal QMapWebMapGenerator

This module provides a very small QMapWebMapGenerator class with a single
purpose: return a fullscreen OpenLayers HTML page that points to a local
WMS using parameters passed in navigation_data. The implementation is
kept deliberately tiny to ensure the file imports cleanly inside QGIS
and avoids f-string/JavaScript brace collisions by using string
concatenation.
"""

class QMapWebMapGenerator:
    """Minimal web map generator used by the plugin.

    This class accepts either the plugin instance (preferred) or the QGIS
    iface object. If a plugin instance is provided and it implements
    `_estimate_zoom_from_scale`, the generator will call that method to
    produce a more accurate zoom level. Otherwise it falls back to the
    internal approximation.
    """

    def __init__(self, owner):
        # owner is either the plugin instance (QMapPermalink) or iface
        # keep a reference for optional use
        self.owner = owner
        # if the owner exposes the precise method, keep a direct reference
        self._plugin_estimate_zoom = None
        try:
            if hasattr(owner, '_estimate_zoom_from_scale') and callable(getattr(owner, '_estimate_zoom_from_scale')):
                self._plugin_estimate_zoom = owner._estimate_zoom_from_scale
        except Exception:
            self._plugin_estimate_zoom = None

    def generate_wms_based_html_page(self, navigation_data, image_width=800, image_height=600, server_port=8089):
        """Return a minimal fullscreen OpenLayers HTML page.

        navigation_data: dict, optional keys: 'x', 'y', 'crs'
        """
        # safe parameter extraction
        try:
            x = navigation_data.get('x', 0)
            y = navigation_data.get('y', 0)
            crs = navigation_data.get('crs', 'EPSG:3857')
            rotation_deg = navigation_data.get('rotation', 0)  # degrees
        except Exception:
            x, y, crs, rotation_deg = 0, 0, 'EPSG:3857', 0

        port = int(server_port)
        # compute zoom from scale: prefer plugin's precise estimator if available
        try:
            import math
            scale_value = navigation_data.get('scale')
            # try plugin-provided estimator first
            zoom = None
            if self._plugin_estimate_zoom is not None:
                try:
                    zoom = float(self._plugin_estimate_zoom(scale_value)) if scale_value is not None else float(self._plugin_estimate_zoom(None))
                except Exception:
                    zoom = None

            # fallback to local approximation if plugin estimator unavailable or failed
            if zoom is None:
                if scale_value is None:
                    zoom = 12
                else:
                    scale_f = float(scale_value)
                    if scale_f > 0:
                        baseScale = 591657527.591555
                        zoom = math.log2(baseScale / scale_f)
                    else:
                        zoom = 12
        except Exception:
            zoom = 12

        # Try to obtain a proj4 definition for the requested CRS from QGIS so
        # the generated OpenLayers page can register non-standard EPSG codes.
        proj4_def = ''
        try:
            from qgis.core import QgsCoordinateReferenceSystem
            crs_obj = QgsCoordinateReferenceSystem(str(crs))
            if crs_obj.isValid():
                try:
                    proj4_def = crs_obj.toProj4() or ''
                except Exception:
                    proj4_def = ''
        except Exception:
            proj4_def = ''

        # Escape proj4 string for embedding in JS
        proj4_def_escaped = proj4_def.replace('"', '\\"').replace('\n', ' ') if proj4_def else ''

        # When we have a proj4 definition, load proj4.js before OpenLayers and
        # register the projection. Otherwise fall back to standard ol behavior.
        if proj4_def_escaped:
            head_scripts = (
                '  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@8.2.0/ol.css" type="text/css">'
                '  <script src="https://cdnjs.cloudflare.com/ajax/libs/proj4js/2.8.0/proj4.js"></script>'
                '  <script src="https://cdn.jsdelivr.net/npm/ol@8.2.0/dist/ol.js"></script>'
                f'  <script>try{{proj4.defs("{crs}", "{proj4_def_escaped}"); if (ol && ol.proj && ol.proj.proj4) {{ ol.proj.proj4.register(proj4); }} else {{ console.warn("ol.proj.proj4 not available - projection registration skipped"); }} }}catch(e){{console.warn("proj4 registration failed", e);}}</script>'
            )
        else:
            head_scripts = (
                '  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@8.2.0/ol.css" type="text/css">'
                '  <script src="https://cdn.jsdelivr.net/npm/ol@8.2.0/dist/ol.js"></script>'
            )

        # Build the HTML using safe concatenation to avoid JS/Python brace collisions
        js_function = (
            '    // Helper: attempt to register projection and compute view center, retrying if ol.proj.proj4 not ready.'
            "\n    function tryRegisterAndInit(retries, delayMs, initCallback) {"
            "\n      retries = retries || 5; delayMs = delayMs || 200;"
            "\n      try {"
            "\n        if (typeof proj4 !== 'undefined' && ol && ol.proj && ol.proj.proj4) {"
            "\n          try { proj4.defs(inputCRS); } catch(e) { }"
            "\n          try { ol.proj.proj4.register(proj4); } catch(e) { }"
            "\n        }"
            "\n      } catch(e) { }"
            "\n\n      var viewCenter;"
            "\n      try {"
            "\n        if (inputCRS === 'EPSG:4326') {"
            "\n          viewCenter = ol.proj.fromLonLat([inputX, inputY]);"
            "\n        } else if (inputCRS === 'EPSG:3857') {"
            "\n          viewCenter = [inputX, inputY];"
            "\n        } else {"
            "\n          try { viewCenter = ol.proj.transform([inputX, inputY], inputCRS, 'EPSG:3857'); } catch(e) { console.warn('initial transform failed, will retry after registration', e); viewCenter = null; }"
            "\n        }"
            "\n      } catch(e) { viewCenter = null; }"
            "\n      if (viewCenter !== null || retries <= 0) {"
            "\n        const rotationRad = (" + str(rotation_deg) + " || 0) * Math.PI / 180;"
            "\n        // determine WMS base URL based on page origin so external clients use the same host/port"
            "\n        const wmsBase = (typeof window !== 'undefined' && window.location && window.location.origin) ? window.location.origin : ('http://' + window.location.hostname + (window.location.port ? ':' + window.location.port : ''));"
        "\n        const map = new ol.Map({"
            "\n          target: 'map',"
            "\n          layers: [ new ol.layer.Image({ source: new ol.source.ImageWMS({ url: wmsBase + '/wms', params: {LAYERS: 'project', FORMAT: 'image/png', TRANSPARENT: true, VERSION: '1.3.0'} }), opacity: 1.0 }) ],"
            "\n          view: new ol.View({center: viewCenter || ol.proj.fromLonLat([inputX, inputY]), projection: 'EPSG:3857', zoom: " + str(round(zoom, 2)) + ", rotation: rotationRad})"
            "\n        });"
            "\n        // expose map globally so external UI can access it (e.g. Home button)"
            "\n        try{ window.map = map; } catch(e){}"
            "\n        if (initCallback && typeof initCallback === 'function') { try { initCallback(map); } catch(e){} }"
            "\n        return;"
            "\n      }"
            "\n\n      setTimeout(function(){ tryRegisterAndInit(retries-1, delayMs, initCallback); }, delayMs);"
            "\n    }\n\n    // start attempts to register and init the map\n    tryRegisterAndInit(8, 150);"
        )

        html = (
            '<!doctype html>'
            '<html lang="ja">'
            '<head>'
            + head_scripts +
            '  <style>html,body{height:100%;margin:0;padding:0}#map{width:100vw;height:100vh} .qmp-home{position:absolute;left:52px;top:10px;z-index:999;background:#fff;border-radius:4px;padding:6px 8px;box-shadow:0 2px 6px rgba(0,0,0,0.15);cursor:pointer;font-size:13px}</style>'
            '</head>'
            '<body>'
            '  <div id="map"></div>'
            '  <div class="qmp-home" id="qmp-home" title="Home">⤒ Home</div>'
            '  <script>'
            '    const serverPort = ' + str(port) + ';' 
            '    const inputX = ' + str(x) + ';' 
            '    const inputY = ' + str(y) + ';' 
            '    const inputCRS = "' + str(crs) + '";' 
            + js_function +
            "    // bind home button to recenter map once map is available\n    (function bindHome(){\n      var attempts=0;\n      function tryBind(){\n        try{\n          var home = document.getElementById('qmp-home');\n          if(window.ol && window.ol.Map && typeof map !== 'undefined' && home){\n            home.addEventListener('click', function(){\n              try{ map.getView().animate({ center: (inputCRS==='EPSG:4326' ? ol.proj.fromLonLat([parseFloat(inputX), parseFloat(inputY)]) : (inputCRS==='EPSG:3857' ? [parseFloat(inputX), parseFloat(inputY)] : ol.proj.transform([parseFloat(inputX), parseFloat(inputY)], inputCRS, 'EPSG:3857')) ), duration: 600 }); }catch(e){console.warn('Home center failed', e);} \n            });\n            return;\n          }\n        }catch(e){}\n        attempts++; if(attempts<20) setTimeout(tryBind,150);\n      }\n      tryBind();\n    })();"
            '  </script>'
            '</body>'
            '</html>'
        )

        return html

    # lightweight stubs to avoid AttributeErrors elsewhere in the plugin
    def get_qgis_layers_info(self):
        return {'layer_count': 0, 'visible_layers': []}

    def get_current_extent_info(self):
        return {}

    def _resolve_coordinates(self, navigation_data):
        try:
            lat = navigation_data.get('lat')
            lon = navigation_data.get('lon')
            if lat is not None and lon is not None:
                return float(lat), float(lon)
            x = navigation_data.get('x')
            y = navigation_data.get('y')
            if x is None or y is None:
                return None, None
            return float(y), float(x)
        except Exception:
            return None, None