# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QMapPermalinkPanel
                                 A QGIS plugin
 Navigate QGIS map views through external permalink system - Panel Version
                             -------------------
        begin                : 2025-10-05
        git sha              : $Format:%H$
        copyright            : (C) 2025 by yamamoto-ryuzo
        email                : 
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os

from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDockWidget, QWidget
from qgis.PyQt.QtCore import Qt

# UIファイルのパスを指定
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'qmap_permalink_panel_base.ui'))


class QMapPermalinkPanel(QDockWidget):
    """QMapPermalinkのパネルクラス
    
    Qt Designerで作成されたUIファイルを読み込んでドッキング可能なパネルとして表示
    """
    
    def __init__(self, parent=None):
        """コンストラクタ
        
        Args:
            parent: 親ウィジェット
        """
        super(QMapPermalinkPanel, self).__init__(parent)
        
        # パネルのタイトルを設定
        self.setWindowTitle("QMap Permalink")
        
        # UIファイルが正しく読み込まれているかチェック
        if not hasattr(FORM_CLASS, '__name__'):
            raise ImportError("UIファイルの読み込みに失敗しました")
        
        # ドッキングエリアを設定（左側を優先、右側も可能）
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        
        # 内部ウィジェットを作成
        self.widget = QWidget()
        self.ui = FORM_CLASS()
        self.ui.setupUi(self.widget)
        
        # 直接アクセス用のプロパティを追加
        self.pushButton_generate = self.ui.pushButton_generate
        self.pushButton_navigate = self.ui.pushButton_navigate  
        self.pushButton_copy = self.ui.pushButton_copy
        self.pushButton_open = self.ui.pushButton_open
        self.lineEdit_permalink = self.ui.lineEdit_permalink
        self.lineEdit_navigate = self.ui.lineEdit_navigate
        self.label_server_status = self.ui.label_server_status
        self.checkBox_include_theme = self.ui.checkBox_include_theme
        
        # ウィジェットを設定
        self.setWidget(self.widget)
        
        # パネルのサイズを設定（左側パネルに適したサイズ）
        self.setMinimumWidth(250)
        self.setMaximumWidth(400)
        
        # パネルの特徴を設定
        self.setFeatures(QDockWidget.DockWidgetMovable | 
                        QDockWidget.DockWidgetFloatable | 
                        QDockWidget.DockWidgetClosable)
        
    def update_server_status(self, port, running):
        """サーバーステータスを更新
        
        Args:
            port: サーバーポート番号
            running: サーバーが実行中かどうか
        """
        if running:
            status_text = f"HTTP Server: Running on http://localhost:{port}"
            style = "color: green; font-weight: bold;"
        else:
            status_text = "HTTP Server: Stopped"
            style = "color: red; font-weight: bold;"
            
        self.label_server_status.setText(status_text)
        self.label_server_status.setStyleSheet(style)