# -*- coding: utf-8 -*-
"""QMapPermalink WFS Service

WFS (Web Feature Service) 機能を提供する専用クラス。
QGISベクターレイヤーから地物をGeoJSON/GML形式で提供。
"""

import json
import re
from typing import Optional, Dict, Any, List, Tuple
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeatureRequest, 
    QgsJsonExporter, QgsMessageLog, Qgis, QgsRectangle,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform
)
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QColor


class QMapPermalinkWFSService:
    """QMapPermalink用WFSサービスクラス

    WFS GetCapabilitiesおよびGetFeatureリクエストを処理し、
    QGISベクターレイヤーから地物をGeoJSON/GML形式で提供します。
    """

    def __init__(self, iface, server_port: int = 8089):
        """WFSサービスを初期化

        Args:
            iface: QGISインターフェース
            server_port: サーバーポート番号
        """
        self.iface = iface
        self.server_port = server_port

    def handle_wfs_request(self, conn, params: Dict[str, list], host: Optional[str] = None) -> None:
        """WFSエンドポイントを処理"""
        from qgis.core import QgsMessageLog, Qgis

        QgsMessageLog.logMessage("🌐 Processing WFS endpoint", "QMapPermalink", Qgis.Info)

        # デバッグ情報
        QgsMessageLog.logMessage(f"🔍 WFS Request parameters: {list(params.keys())}", "QMapPermalink", Qgis.Info)

        request = params.get('REQUEST', [''])[0].upper()
        service = params.get('SERVICE', [''])[0].upper()

        if service != 'WFS':
            from . import http_server
            http_server.send_wms_error_response(conn, "InvalidParameterValue", "SERVICE parameter must be WFS")
            return

        if request == 'GETCAPABILITIES':
            self._handle_wfs_get_capabilities(conn, params, host)
        elif request == 'GETFEATURE':
            self._handle_wfs_get_feature(conn, params)
        elif request == 'DESCRIBEFEATURETYPE':
            self._handle_wfs_describe_feature_type(conn, params)
        else:
            from . import http_server
            http_server.send_wms_error_response(conn, "InvalidRequest", f"Request {request} is not supported")

    def _handle_wfs_get_capabilities(self, conn, params: Dict[str, list], host: Optional[str] = None) -> None:
        """WFS GetCapabilitiesリクエストを処理"""
        from qgis.core import QgsMessageLog, Qgis

        # ベースホストの決定
        try:
            if host:
                base_host = host
            else:
                base_host = f"localhost:{self.server_port}"
        except Exception:
            base_host = f"localhost:{self.server_port}"

        # 利用可能なベクターレイヤーを取得
        vector_layers = self._get_vector_layers()

        # FeatureTypeリストの生成
        feature_types_xml = ""
        for layer in vector_layers:
            layer_name = layer.name().replace(' ', '_')
            crs = layer.crs().authid() if layer.crs().isValid() else 'EPSG:4326'
            extent = self._get_layer_extent(layer)

            feature_types_xml += f"""
    <FeatureType>
      <Name>{layer_name}</Name>
      <Title>{layer.name()}</Title>
      <Abstract>Vector layer from QGIS project</Abstract>
      <DefaultCRS>{crs}</DefaultCRS>
      <OutputFormats>
        <Format>application/json</Format>
        <Format>application/gml+xml</Format>
      </OutputFormats>
      <WGS84BoundingBox>
        <LowerCorner>{extent['minx']} {extent['miny']}</LowerCorner>
        <UpperCorner>{extent['maxx']} {extent['maxy']}</UpperCorner>
      </WGS84BoundingBox>
    </FeatureType>"""

        xml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<WFS_Capabilities version="2.0.0" xmlns="http://www.opengis.net/wfs/2.0"
                  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                  xsi:schemaLocation="http://www.opengis.net/wfs/2.0 http://schemas.opengis.net/wfs/2.0/wfs.xsd">
  <ServiceIdentification>
    <Title>QGIS Map Permalink WFS Service</Title>
    <Abstract>Dynamic WFS service for QGIS vector layers</Abstract>
    <ServiceType>WFS</ServiceType>
    <ServiceTypeVersion>2.0.0</ServiceTypeVersion>
    <Fees>NONE</Fees>
    <AccessConstraints>NONE</AccessConstraints>
  </ServiceIdentification>
  <ServiceProvider>
    <ProviderName>QMapPermalink</ProviderName>
  </ServiceProvider>
  <OperationsMetadata>
    <Operation name="GetCapabilities">
      <DCP><HTTP><Get xlink:href="http://{base_host}/wfs"/></HTTP></DCP>
    </Operation>
    <Operation name="DescribeFeatureType">
      <DCP><HTTP><Get xlink:href="http://{base_host}/wfs"/></HTTP></DCP>
    </Operation>
    <Operation name="GetFeature">
      <DCP><HTTP><Get xlink:href="http://{base_host}/wfs"/></HTTP></DCP>
    </Operation>
  </OperationsMetadata>
  <FeatureTypeList>{feature_types_xml}
  </FeatureTypeList>
</WFS_Capabilities>"""

        from . import http_server
        http_server.send_http_response(conn, 200, "OK", xml_content, content_type="text/xml; charset=utf-8")

    def _handle_wfs_get_feature(self, conn, params: Dict[str, list]) -> None:
        """WFS GetFeatureリクエストを処理"""
        from qgis.core import QgsMessageLog, Qgis

        try:
            # パラメータの解析
            type_name = params.get('TYPENAME', params.get('TYPENAMES', ['']))[0]
            if not type_name:
                from . import http_server
                http_server.send_wms_error_response(conn, "MissingParameterValue", "TYPENAME parameter is required")
                return

            output_format = params.get('OUTPUTFORMAT', ['application/json'])[0]
            max_features = params.get('MAXFEATURES', [None])[0]
            if max_features:
                try:
                    max_features = int(max_features)
                except:
                    max_features = None

            bbox = params.get('BBOX', [None])[0]
            srs_name = params.get('SRSNAME', [None])[0]

            # レイヤーの検索
            layer = self._find_layer_by_name(type_name)
            if not layer:
                from . import http_server
                http_server.send_wms_error_response(conn, "InvalidParameterValue", f"Layer '{type_name}' not found")
                return

            # 地物のクエリ
            features = self._query_features(layer, bbox, srs_name, max_features)

            # 出力フォーマットに応じたレスポンス生成
            if output_format.lower() == 'application/gml+xml':
                response_content = self._features_to_gml(features, layer)
                content_type = "application/gml+xml; charset=utf-8"
            else:  # application/json
                response_content = self._features_to_geojson(features, layer)
                content_type = "application/json; charset=utf-8"

            from . import http_server
            http_server.send_http_response(conn, 200, "OK", response_content, content_type=content_type)

        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            import traceback
            QgsMessageLog.logMessage(f"❌ WFS GetFeature error: {e}", "QMapPermalink", Qgis.Critical)
            QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            from . import http_server
            http_server.send_http_response(conn, 500, "Internal Server Error", f"WFS GetFeature failed: {str(e)}")

    def _handle_wfs_describe_feature_type(self, conn, params: Dict[str, list]) -> None:
        """WFS DescribeFeatureTypeリクエストを処理"""
        from qgis.core import QgsMessageLog, Qgis

        try:
            type_name = params.get('TYPENAME', params.get('TYPENAMES', ['']))[0]
            if not type_name:
                from . import http_server
                http_server.send_wms_error_response(conn, "MissingParameterValue", "TYPENAME parameter is required")
                return

            # レイヤーの検索
            layer = self._find_layer_by_name(type_name)
            if not layer:
                from . import http_server
                http_server.send_wms_error_response(conn, "InvalidParameterValue", f"Layer '{type_name}' not found")
                return

            # スキーマの生成
            schema_xml = self._generate_feature_type_schema(layer)

            from . import http_server
            http_server.send_http_response(conn, 200, "OK", schema_xml, content_type="text/xml; charset=utf-8")

        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            import traceback
            QgsMessageLog.logMessage(f"❌ WFS DescribeFeatureType error: {e}", "QMapPermalink", Qgis.Critical)
            from . import http_server
            http_server.send_http_response(conn, 500, "Internal Server Error", f"WFS DescribeFeatureType failed: {str(e)}")

    def _get_vector_layers(self) -> List[QgsVectorLayer]:
        """プロジェクトからベクターレイヤーを取得"""
        project = QgsProject.instance()
        vector_layers = []

        for layer_id, layer in project.mapLayers().items():
            if isinstance(layer, QgsVectorLayer):
                vector_layers.append(layer)

        return vector_layers

    def _find_layer_by_name(self, type_name: str) -> Optional[QgsVectorLayer]:
        """レイヤー名でレイヤーを検索"""
        vector_layers = self._get_vector_layers()

        # スペースをアンダースコアに変換して比較
        normalized_type_name = type_name.replace('_', ' ')

        for layer in vector_layers:
            if layer.name() == normalized_type_name or layer.name().replace(' ', '_') == type_name:
                return layer

        return None

    def _get_layer_extent(self, layer: QgsVectorLayer) -> Dict[str, float]:
        """レイヤーの範囲を取得（WGS84に変換）"""
        try:
            extent = layer.extent()
            crs = layer.crs()

            if crs.authid() != 'EPSG:4326':
                transform = QgsCoordinateTransform(crs, QgsCoordinateReferenceSystem('EPSG:4326'), QgsProject.instance())
                extent = transform.transformBoundingBox(extent)

            return {
                'minx': extent.xMinimum(),
                'miny': extent.yMinimum(),
                'maxx': extent.xMaximum(),
                'maxy': extent.yMaximum()
            }
        except:
            return {'minx': -180, 'miny': -90, 'maxx': 180, 'maxy': 90}

    def _query_features(self, layer: QgsVectorLayer, bbox: Optional[str] = None,
                       srs_name: Optional[str] = None, max_features: Optional[int] = None) -> List:
        """レイヤーから地物をクエリ"""
        request = QgsFeatureRequest()

        # BBOXフィルタ
        if bbox:
            try:
                coords = [float(x) for x in bbox.split(',')]
                if len(coords) == 4:
                    minx, miny, maxx, maxy = coords
                    rect = QgsRectangle(minx, miny, maxx, maxy)

                    # SRS変換
                    if srs_name and srs_name != layer.crs().authid():
                        src_crs = QgsCoordinateReferenceSystem(srs_name)
                        tgt_crs = layer.crs()
                        if src_crs.isValid():
                            transform = QgsCoordinateTransform(src_crs, tgt_crs, QgsProject.instance())
                            rect = transform.transformBoundingBox(rect)

                    request.setFilterRect(rect)
            except:
                pass

        # 最大地物数
        if max_features:
            request.setLimit(max_features)

        # 地物取得
        features = []
        for feature in layer.getFeatures(request):
            features.append(feature)

        return features

    def _features_to_geojson(self, features: List, layer: QgsVectorLayer) -> str:
        """地物をGeoJSONに変換"""
        exporter = QgsJsonExporter(layer)

        # GeoJSON FeatureCollectionの作成
        geojson = {
            "type": "FeatureCollection",
            "features": []
        }

        for feature in features:
            feature_json = json.loads(exporter.exportFeature(feature))

            # try to attach simple style hints extracted from the QGIS symbol
            try:
                style_hint = self._extract_style_hint(layer, feature)
                if 'properties' not in feature_json or feature_json['properties'] is None:
                    feature_json['properties'] = {}
                # only attach if we obtained something useful
                if style_hint:
                    # attach the raw style hint under _qgis_style for compatibility
                    feature_json['properties']['_qgis_style'] = style_hint
                    # and also flatten useful keys to top-level properties so
                    # client templates can access them directly without nested
                    # ['get', <prop>, ['get', '_qgis_style']] expressions which
                    # are error-prone in some MapLibre builds.
                    for sk, sv in style_hint.items():
                        try:
                            # don't overwrite an existing explicit property
                            if sk not in feature_json['properties']:
                                feature_json['properties'][sk] = sv
                        except Exception:
                            # ignore individual property failures
                            pass
            except Exception:
                # non-fatal; leave feature as-is
                pass

            # Try to attach a human-readable label for the feature if available.
            # This uses the layer's displayExpression (if set) or the layer's
            # display field as a fallback.
            try:
                label_text = self._extract_feature_label(layer, feature)
                if label_text is not None:
                    try:
                        s = str(label_text).strip()
                    except Exception:
                        s = ''

                    # Treat empty strings, whitespace-only, and common null-like tokens as no label
                    if s and s.lower() not in ('null', 'none', 'nan'):
                        if 'properties' not in feature_json or feature_json['properties'] is None:
                            feature_json['properties'] = {}
                        feature_json['properties']['label'] = s
                        try:
                            # Log label extraction for debugging in QGIS message log
                            from qgis.core import QgsMessageLog, Qgis
                            QgsMessageLog.logMessage(f"WFS: feature {feature.id()} label='{s}'", "QMapPermalink", Qgis.Info)
                        except Exception:
                            pass
            except Exception:
                # non-fatal
                pass

            geojson["features"].append(feature_json)

        return json.dumps(geojson, ensure_ascii=False, indent=2)

    def _extract_style_hint(self, layer: QgsVectorLayer, feature) -> Dict[str, Any]:
        """Extract a minimal style hint for a feature from the layer's renderer.

        Returns a dict suitable for client-side MapLibre usage, e.g.
        { 'geomType':'LineString', 'stroke':'#rrggbb', 'stroke-width':2 }

        This is best-effort: we handle simple single-symbol renderers and
        fall back to empty dict for complex cases.
        """
        try:
            from qgis.core import QgsMarkerSymbol, QgsLineSymbol, QgsFillSymbol
            renderer = layer.renderer()
            try:
                symbol = renderer.symbol()
            except Exception:
                return {}

            # Get first symbol layer properties if available
            props = {}
            try:
                sl = symbol.symbolLayer(0)
                try:
                    props = sl.properties()
                except Exception:
                    props = {}
            except Exception:
                props = {}

            style = {}
            try:
                if isinstance(symbol, QgsMarkerSymbol):
                    style['geomType'] = 'Point'
                elif isinstance(symbol, QgsLineSymbol):
                    style['geomType'] = 'LineString'
                elif isinstance(symbol, QgsFillSymbol):
                    style['geomType'] = 'Polygon'
            except Exception:
                pass

            # helper: normalize various color representations to #rrggbb and
            # extract opacity (0.0-1.0) when available
            def _normalize_color_value(val: Any) -> Tuple[Optional[str], Optional[float]]:
                if val is None:
                    return None, None
                try:
                    # Prefer using Qt QColor to parse many formats (names, #hex, rgba(...))
                    qc = QColor(str(val))
                    if qc.isValid():
                        r = qc.red(); g = qc.green(); b = qc.blue(); a = qc.alpha()
                        hexcol = f"#{r:02x}{g:02x}{b:02x}"
                        opacity = float(a) / 255.0 if a is not None else None
                        return hexcol, opacity
                except Exception:
                    pass

                # Fallback: try to extract numeric RGB(A) tokens from the string
                try:
                    nums = re.findall(r"[0-9]*\.?[0-9]+", str(val))
                    if len(nums) >= 3:
                        r = int(float(nums[0])); g = int(float(nums[1])); b = int(float(nums[2]))
                        a = None
                        if len(nums) >= 4:
                            a_raw = float(nums[3])
                            # alpha might be 0-1 or 0-255
                            a = a_raw if a_raw <= 1.0 else (a_raw / 255.0)
                        hexcol = f"#{r:02x}{g:02x}{b:02x}"
                        return hexcol, float(a) if a is not None else None
                except Exception:
                    pass

                return None, None

            color = props.get('color') or props.get('stroke') or props.get('stroke_color') or props.get('fill') or props.get('fill_color') or None
            if color:
                hexcol, alpha = _normalize_color_value(color)
                if hexcol:
                    style['stroke'] = hexcol
                    style['fill'] = hexcol
                    # if color string included alpha and no explicit opacity found,
                    # set fill-opacity (and possibly stroke-opacity) to that value
                    if alpha is not None and 'fill-opacity' not in style:
                        try:
                            style['fill-opacity'] = float(alpha)
                        except Exception:
                            pass

            width = props.get('width') or props.get('stroke-width') or props.get('size') or None
            if width:
                try:
                    style['stroke-width'] = float(width)
                except Exception:
                    style['stroke-width'] = width

            opacity = props.get('fill-opacity') or props.get('opacity') or None
            if opacity is not None:
                try:
                    style['fill-opacity'] = float(opacity)
                except Exception:
                    # if it's a string like '0.5' that failed, leave as-is
                    style['fill-opacity'] = opacity

            msize = props.get('size') or props.get('marker-size') or None
            if msize:
                try:
                    style['marker-size'] = float(msize)
                except Exception:
                    style['marker-size'] = msize

            return style
        except Exception:
            return {}

    def _extract_feature_label(self, layer: QgsVectorLayer, feature) -> str:
        """Extract a display label for a feature.

        Tries the layer's displayExpression first, then falls back to the
        display field. Returns an empty string if no label can be determined.
        """
        try:
            # First, prefer explicit labeling settings if present. Many users
            # configure labels via the layer's labeling (QgsPalLayerSettings) —
            # prefer that over the displayExpression/displayField heuristics.
            try:
                lab = None
                try:
                    lab = layer.labeling()
                except Exception:
                    lab = None
                if lab is not None:
                    try:
                        settings = lab.settings()
                    except Exception:
                        settings = None
                    if settings is not None:
                        # settings may expose methods or attributes depending on QGIS
                        # version. Try to obtain an expression first, then a field name.
                        expr_candidate = None
                        field_candidate = None
                        try:
                            if hasattr(settings, 'expression'):
                                expr_candidate = settings.expression() if callable(getattr(settings, 'expression')) else settings.expression
                        except Exception:
                            expr_candidate = None
                        try:
                            if hasattr(settings, 'fieldName'):
                                field_candidate = settings.fieldName() if callable(getattr(settings, 'fieldName')) else settings.fieldName
                        except Exception:
                            field_candidate = None

                        # If an expression is configured in the labeling settings, evaluate it
                        if expr_candidate:
                            try:
                                from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils
                                expr = QgsExpression(str(expr_candidate))
                                ctx = QgsExpressionContext()
                                ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                                ctx.setFeature(feature)
                                val = expr.evaluate(ctx)
                                if not expr.hasEvalError() and val is not None:
                                    return str(val)
                            except Exception:
                                # fall through to fieldCandidate/displayExpression
                                pass

                        # If a field name is configured for labeling, use the attribute
                        if field_candidate:
                            try:
                                val = feature.attribute(field_candidate)
                                if val is not None:
                                    return str(val)
                            except Exception:
                                pass
            except Exception:
                # ignore labeling inspection errors and continue to other fallbacks
                pass

            # Next, prefer displayExpression (can be an expression like "concat(name, ' (', id, ')')")
            expr_str = ''
            try:
                # method exists on QgsVectorLayer in modern QGIS
                expr_str = layer.displayExpression()
            except Exception:
                expr_str = ''

            if expr_str:
                try:
                    from qgis.core import QgsExpression, QgsExpressionContext, QgsExpressionContextUtils
                    expr = QgsExpression(expr_str)
                    ctx = QgsExpressionContext()
                    # include project and layer scopes so functions like @project can work
                    ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                    ctx.setFeature(feature)
                    val = expr.evaluate(ctx)
                    if expr.hasEvalError():
                        # fall through to field fallback
                        raise Exception('expression eval error')
                    return '' if val is None else str(val)
                except Exception:
                    pass

            # Fallback: layer.displayField() or form display field
            try:
                df = None
                try:
                    df = layer.displayField()
                except Exception:
                    df = None
                if df:
                    val = feature.attribute(df)
                    return '' if val is None else str(val)
            except Exception:
                pass

        except Exception:
            pass

        return ''

    def _features_to_gml(self, features: List, layer: QgsVectorLayer) -> str:
        """地物をGMLに変換（簡易版）"""
        layer_name = layer.name().replace(' ', '_')
        crs = layer.crs().authid() if layer.crs().isValid() else 'EPSG:4326'

        gml = f"""<?xml version="1.0" encoding="UTF-8"?>
<wfs:FeatureCollection xmlns:wfs="http://www.opengis.net/wfs"
                       xmlns:gml="http://www.opengis.net/gml"
                       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                       xsi:schemaLocation="http://www.opengis.net/wfs http://schemas.opengis.net/wfs/1.1.0/wfs.xsd">
"""

        for feature in features:
            geom = feature.geometry()
            if geom:
                gml_geom = self._geometry_to_gml(geom, crs)
                properties = self._feature_properties_to_gml(feature)

                gml += f"""  <gml:featureMember>
    <{layer_name} gml:id="{feature.id()}">
      <gml:boundedBy>
        <gml:Envelope srsName="{crs}">
          <gml:lowerCorner>{geom.boundingBox().xMinimum()} {geom.boundingBox().yMinimum()}</gml:lowerCorner>
          <gml:upperCorner>{geom.boundingBox().xMaximum()} {geom.boundingBox().yMaximum()}</gml:upperCorner>
        </gml:Envelope>
      </gml:boundedBy>
      {gml_geom}
      {properties}
    </{layer_name}>
  </gml:featureMember>
"""

        gml += "</wfs:FeatureCollection>"
        return gml

    def _geometry_to_gml(self, geometry, crs: str) -> str:
        """ジオメトリをGMLに変換（簡易版）"""
        if geometry.isEmpty():
            return ""

        geom_type = geometry.type()
        wkt = geometry.asWkt()

        # 簡易的なWKTからGML変換
        if geom_type == 0:  # Point
            coords = wkt.replace('Point (', '').replace(')', '').split()
            return f'<gml:Point srsName="{crs}"><gml:coordinates>{coords[0]},{coords[1]}</gml:coordinates></gml:Point>'
        elif geom_type == 1:  # LineString
            coords = wkt.replace('LineString (', '').replace(')', '').replace('(', '').replace(')', '')
            return f'<gml:LineString srsName="{crs}"><gml:coordinates>{coords}</gml:coordinates></gml:LineString>'
        elif geom_type == 2:  # Polygon
            # 多角形は複雑なので簡易的に外環のみ
            coords = wkt.replace('Polygon ((', '').replace('))', '').split(', ')
            coord_str = ' '.join(coords)
            return f'<gml:Polygon srsName="{crs}"><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>{coord_str}</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon>'

        return ""

    def _feature_properties_to_gml(self, feature) -> str:
        """地物の属性をGMLに変換"""
        properties = ""
        fields = feature.fields()

        for i in range(fields.count()):
            field = fields.field(i)
            value = feature.attribute(i)
            if value is not None:
                properties += f"      <{field.name()}>{str(value)}</{field.name()}>\n"

        return properties

    def _generate_feature_type_schema(self, layer: QgsVectorLayer) -> str:
        """レイヤーのスキーマをXMLで生成"""
        layer_name = layer.name().replace(' ', '_')
        fields = layer.fields()

        schema = f"""<?xml version="1.0" encoding="UTF-8"?>
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            xmlns:gml="http://www.opengis.net/gml"
            xmlns:{layer_name}="http://www.opengis.net/{layer_name}"
            targetNamespace="http://www.opengis.net/{layer_name}"
            elementFormDefault="qualified">
  <xsd:import namespace="http://www.opengis.net/gml" schemaLocation="http://schemas.opengis.net/gml/3.1.1/base/gml.xsd"/>
  <xsd:element name="{layer_name}" type="{layer_name}:{layer_name}Type" substitutionGroup="gml:_Feature"/>
  <xsd:complexType name="{layer_name}Type">
    <xsd:complexContent>
      <xsd:extension base="gml:AbstractFeatureType">
        <xsd:sequence>
"""

        for field in fields:
            field_type = self._qgis_field_type_to_xsd(field.typeName())
            schema += f"""          <xsd:element name="{field.name()}" type="{field_type}" nillable="true" minOccurs="0"/>
"""

        schema += f"""        </xsd:sequence>
      </xsd:extension>
    </xsd:complexContent>
  </xsd:complexType>
</xsd:schema>"""

        return schema

    def _qgis_field_type_to_xsd(self, qgis_type: str) -> str:
        """QGISフィールドタイプをXSDタイプに変換"""
        type_mapping = {
            'integer': 'xsd:int',
            'int4': 'xsd:int',
            'int8': 'xsd:long',
            'real': 'xsd:double',
            'double': 'xsd:double',
            'string': 'xsd:string',
            'text': 'xsd:string',
            'varchar': 'xsd:string',
            'date': 'xsd:date',
            'datetime': 'xsd:dateTime'
        }

        return type_mapping.get(qgis_type.lower(), 'xsd:string')