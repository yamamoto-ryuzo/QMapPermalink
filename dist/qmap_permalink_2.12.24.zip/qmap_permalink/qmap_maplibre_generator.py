"""MapLibre HTML generator for QMapPermalink

This module provides a small helper to create a temporary HTML file that
loads MapLibre GL JS and centers the map based on a permalink string when
possible. If the permalink cannot be parsed, it will attempt to open the
permalink directly in the browser.
"""
import os
import re
import tempfile
import webbrowser
from urllib.parse import urlparse, parse_qs


def _parse_permalink(permalink_text):
	"""Try to extract lat, lon, zoom from a permalink URL or a simple
	formatted string. Returns (lat, lon, zoom) or None on failure.
	"""
	if not permalink_text:
		return None
	# Try common query parameters: lat, lon, zoom or center, z
	try:
		parsed = urlparse(permalink_text)
		qs = parse_qs(parsed.query)
		lat = None
		lon = None
		zoom = None
		for key in ('lat', 'latitude'):
			if key in qs:
				lat = float(qs[key][0])
				break
		for key in ('lon', 'lng', 'longitude'):
			if key in qs:
				lon = float(qs[key][0])
				break
		for key in ('zoom', 'z'):
			if key in qs:
				zoom = float(qs[key][0])
				break
		# Some permalinks embed center as "lon,lat,zoom" or "lat,lon,zoom"
		if ('center' in qs or 'c' in qs) and (lat is None or lon is None):
			center = qs.get('center', qs.get('c'))[0]
			parts = re.split('[,; ]+', center)
			if len(parts) >= 2:
				# try both orders
				a = float(parts[0])
				b = float(parts[1])
				# heuristics: if abs(a)>90 then assume lon,lat
				if abs(a) > 90:
					lon, lat = a, b
				else:
					lat, lon = a, b
			if len(parts) >= 3 and zoom is None:
				zoom = float(parts[2])
		if lat is not None and lon is not None:
			return (lat, lon, zoom if zoom is not None else 10)
	except Exception:
		pass

	# Try to find patterns like @lat,lon,zoomz (e.g., some mapping services)
	m = re.search(r'@\s*([0-9.+-]+),\s*([0-9.+-]+),\s*([0-9.+-]+)z', permalink_text)
	if m:
		try:
			lat = float(m.group(1))
			lon = float(m.group(2))
			zoom = float(m.group(3))
			return (lat, lon, zoom)
		except Exception:
			pass

	# fallback: try any three floats in the string
	floats = re.findall(r'[-+]?[0-9]*\.?[0-9]+', permalink_text)
	if len(floats) >= 3:
		try:
			a, b, c = map(float, floats[:3])
			# guess order
			if abs(a) <= 90:
				return (a, b, c)
			else:
				return (b, a, c)
		except Exception:
			pass

	return None


def open_maplibre_from_permalink(permalink_text):
	"""Generate a temporary HTML file with MapLibre and open it.

	If parsing of permalink_text fails, open the permalink_text directly in
	the default browser (it may be a full web page URL).
	"""
	parsed = _parse_permalink(permalink_text)
	if parsed is None:
		# If it's a URL, open it directly. Otherwise open google maps with query.
		if permalink_text and (permalink_text.startswith('http://') or permalink_text.startswith('https://')):
			webbrowser.open(permalink_text)
			return
		# fallback: raise an error instead of silently opening search
		raise ValueError(f"Cannot parse permalink: {permalink_text!r}")

	lat, lon, zoom = parsed

	# If permalink contains x/y/crs style parameters (e.g. from QMapPermalink generate
	# output), try to detect and convert them to WGS84 (lat/lon) for MapLibre.
	# Prefer QGIS transformation APIs if available (when running inside QGIS),
	# otherwise fall back to pyproj if installed.
	try:
		# Quick parse for x, y, crs parameters in the original permalink_text
		# examples: '.../qgis-map?x=123456&y=456789&crs=EPSG:3857'
		from urllib.parse import urlparse, parse_qs
		parsed_url = urlparse(permalink_text)
		qs = parse_qs(parsed_url.query)
		if 'x' in qs and 'y' in qs:
			x_val = float(qs['x'][0])
			y_val = float(qs['y'][0])
			crs_param = qs.get('crs', [None])[0]
			# override zoom from query if present
			if 'zoom' in qs:
				try:
					zoom = float(qs['zoom'][0])
				except Exception:
					pass
			if crs_param:
				# normalize crs string (accept 'EPSG:3857' or numeric)
				src_crs = str(crs_param)
				converted = None
				# Try QGIS API first (when running inside QGIS)
				try:
					from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsPointXY
					src = QgsCoordinateReferenceSystem(src_crs)
					if src.isValid():
						dest = QgsCoordinateReferenceSystem('EPSG:4326')
						transform = QgsCoordinateTransform(src, dest, QgsProject.instance())
						pt = transform.transform(QgsPointXY(float(x_val), float(y_val)))
						# transform returns point in dest CRS (x = lon, y = lat)
						converted = (float(pt.y()), float(pt.x()))
				except Exception:
					converted = None

				# If QGIS conversion failed, try pyproj
				if converted is None:
					try:
						from pyproj import Transformer
						# pyproj expects crs identifiers like 'EPSG:3857'
						t = Transformer.from_crs(src_crs, 'EPSG:4326', always_xy=True)
						lon_out, lat_out = t.transform(float(x_val), float(y_val))
						converted = (float(lat_out), float(lon_out))
					except Exception:
						converted = None

				# If pyproj/QGIS not available, try a built-in EPSG:3857 inverse Mercator
				if converted is None:
					try:
						sc = src_crs.upper()
						if '3857' in sc or '900913' in sc:
							# Web Mercator inverse
							import math
							R = 6378137.0
							lon_deg = (float(x_val) / R) * (180.0 / math.pi)
							lat_rad = 2 * math.atan(math.exp(float(y_val) / R)) - math.pi / 2.0
							lat_deg = lat_rad * (180.0 / math.pi)
							converted = (float(lat_deg), float(lon_deg))
					except Exception:
						converted = None

				if converted is not None:
					lat, lon = converted
	except Exception:
		# any failure in conversion should not break map generation
		pass

	html = f'''<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no" />
  <title>MapLibre Viewer</title>
	<link href="https://unpkg.com/maplibre-gl@latest/dist/maplibre-gl.css" rel="stylesheet" />
  <style>html,body,#map{{height:100%;margin:0;padding:0}}#map{{position:fixed;inset:0}}</style>
</head>
<body>
<div id="map"></div>
<script src="https://unpkg.com/maplibre-gl@latest/dist/maplibre-gl.js"></script>
<script>
  console.log('MapLibre script loaded');
  try {{
    // Use a minimal inline raster style (OpenStreetMap tiles)
    const style = {{
      "version": 8,
      "sources": {{
        "osm": {{
          "type": "raster",
          "tiles": ["https://tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png"],
          "tileSize": 256,
          "attribution": "© OpenStreetMap contributors"
        }}
      }},
      "layers": [
        {{ "id": "osm", "type": "raster", "source": "osm", "minzoom": 0, "maxzoom": 22 }}
      ]
    }};
    
    console.log('Initializing map at lat={lat}, lon={lon}, zoom={zoom}');
    const map = new maplibregl.Map({{
      container: 'map',
      style: style,
      center: [{lon}, {lat}],
      zoom: {zoom}
    }});
    
    map.on('load', function() {{
      console.log('Map loaded successfully');
    }});
    
    map.on('error', function(e) {{
      console.error('Map error:', e);
    }});
  }} catch (e) {{
    console.error('Failed to initialize map:', e);
    document.body.innerHTML = '<div style="padding:20px;font-family:sans-serif;"><h2>Map initialization failed</h2><pre>' + e.toString() + '</pre><p>Check browser console (F12) for details.</p></div>';
  }}
</script>
</body>
</html>'''

	# write to temp file
	try:
		fd, path = tempfile.mkstemp(suffix='.html', prefix='qmap_maplibre_')
		with os.fdopen(fd, 'w', encoding='utf-8') as f:
			f.write(html)
		# Print the path so callers (or QGIS Python console) can see where the file
		# was written. Return the path so callers can open it manually if needed.
		print(f"MapLibre HTML written to: {path}")
		webbrowser.open('file://' + path)
		return path
	except Exception as e:
		# Do not silently fallback; raise an error so caller can handle it
		raise RuntimeError(f"Failed to create or open MapLibre HTML file: {e}") from e
