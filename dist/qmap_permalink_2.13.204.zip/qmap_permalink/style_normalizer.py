# -*- coding: utf-8 -*-
"""Unified style normalization for QMapPermalink.

このモジュールは QGIS シンボル (QgsSymbol / QgsSymbolLayer) から可視表現に必要な
最小限かつ一貫したスタイル情報を抽出し、後段の SLD 生成や MapLibre 変換を
単一ソース化することを目的とする。

【目的】
- 既存の重複ロジック (_extract_symbol_properties など) を排除
- ポリゴン/ライン/ポイントで同じ判断規約を使う
- ブラシなし (NoBrush) / 透明 (alpha=0) を統一的に has_fill=False と判定
- 複数シンボルレイヤは「最初に可視な値を採用」規約でシンプル化

【NormalizedStyle スキーマ】
Dict[str, Any] で以下のキーを返す:
- geometry: 'Point' | 'LineString' | 'Polygon'
- fill_color: Optional[str]  (#RRGGBB)
- fill_opacity: Optional[float] (0..1)
- stroke_color: Optional[str] (#RRGGBB)
- stroke_opacity: Optional[float] (0..1)
- stroke_width: Optional[float]
- line_join: Optional[str] ('miter'|'round'|'bevel')
- line_cap: Optional[str] ('butt'|'round'|'square')
- line_dash: Optional[List[float]]
- point_shape: Optional[str] ('circle','square','triangle','star','cross','x')
- size: Optional[float] (points 半径等)
- has_fill: bool
- has_stroke: bool

【エッジケース規約】
- fill_color が取得できても alpha==0 → has_fill=False
- stroke_color alpha==0 → has_stroke=False
- stroke_width 未取得時は 1 (ライン/ポリゴン枠), ポイントは None
- line_dash は Qt ペンスタイル単純マッピング (5 2 等) 固定値
- 複数レイヤ: 先頭レイヤから順に走査し最初に条件を満たした値を採用
- 取得失敗時は安全なデフォルト (stroke_color '#000000', stroke_width 1) を後段が補う

この層を通すことで SLD / MapLibre 生成の複雑な条件分岐を大幅に削減する。
"""
from typing import Any, Dict, List, Optional

try:
    from PyQt5.QtCore import Qt  # type: ignore
except Exception:  # pragma: no cover - QGIS/Qt 未ロード環境
    Qt = None  # type: ignore

# Qt enum 値 (int) の簡易マッピング: 既存コードと互換
_JOIN_MAP = {
    0: 'miter',    # Qt.MiterJoin
    64: 'bevel',   # Qt.BevelJoin
    128: 'round',  # Qt.RoundJoin
}
_CAP_MAP = {
    0: 'butt',     # Qt.FlatCap
    16: 'square',  # Qt.SquareCap
    32: 'round',   # Qt.RoundCap
}
_DASH_MAP = {
    1: None,            # SolidLine
    2: [5.0, 2.0],      # DashLine
    3: [1.0, 2.0],      # DotLine
    4: [5.0, 2.0, 1.0, 2.0],          # DashDotLine
    5: [5.0, 2.0, 1.0, 2.0, 1.0, 2.0] # DashDotDotLine
}

# ポイント shape マッピング (QgsSimpleMarkerSymbolLayerBase.* → 名前)
_POINT_SHAPE_MAP = {}
try:
    from qgis.core import QgsSimpleMarkerSymbolLayerBase  # type: ignore
    _POINT_SHAPE_MAP = {
        QgsSimpleMarkerSymbolLayerBase.Square: 'square',
        QgsSimpleMarkerSymbolLayerBase.Diamond: 'square',  # rotated square 近似
        QgsSimpleMarkerSymbolLayerBase.Pentagon: 'circle', # 近似
        QgsSimpleMarkerSymbolLayerBase.Hexagon: 'circle',  # 近似
        QgsSimpleMarkerSymbolLayerBase.Triangle: 'triangle',
        QgsSimpleMarkerSymbolLayerBase.Star: 'star',
        QgsSimpleMarkerSymbolLayerBase.Cross: 'cross',
        QgsSimpleMarkerSymbolLayerBase.Cross2: 'x',
        QgsSimpleMarkerSymbolLayerBase.Circle: 'circle',
    }
except Exception:  # pragma: no cover
    pass


def _qcolor_to_hex(c) -> Optional[str]:
    if c is None:
        return None
    try:
        if hasattr(c, 'isValid') and c.isValid():
            return c.name()  # e.g. #RRGGBB
    except Exception:
        pass
    # 最低限 str 化
    return str(c) if c else None


def extract_normalized_style(symbol, geom_type: str) -> Dict[str, Any]:
    """シンボルから統一スタイル辞書を生成する。

    symbol: QgsSymbol 派生 (または None)
    geom_type: 'Point' | 'LineString' | 'Polygon'
    """
    ns: Dict[str, Any] = {
        'geometry': geom_type,
        'fill_color': None,
        'fill_opacity': None,
        'stroke_color': None,
        'stroke_opacity': None,
        'stroke_width': None,
        'line_join': None,
        'line_cap': None,
        'line_dash': None,
        'point_shape': None,
        'size': None,
        'has_fill': False,
        'has_stroke': False,
    }
    if symbol is None:
        return ns

    # レイヤ走査
    layer_count = 0
    try:
        if hasattr(symbol, 'symbolLayerCount') and callable(symbol.symbolLayerCount):
            layer_count = int(symbol.symbolLayerCount())
    except Exception:
        layer_count = 0

    def _iter_layers():
        if layer_count <= 0:
            yield None
        else:
            for i in range(layer_count):
                sl = None
                try:
                    sl = symbol.symbolLayer(i)
                except Exception:
                    sl = None
                yield sl

    for sl in _iter_layers():
        if sl is None:
            # Fallback: プロパティをシンボル本体から直接
            if ns['fill_color'] is None and geom_type == 'Polygon':
                try:
                    c = symbol.color()
                    ns['fill_color'] = _qcolor_to_hex(c)
                    if c and hasattr(c, 'alpha') and callable(c.alpha):
                        ns['fill_opacity'] = c.alpha() / 255.0
                except Exception:
                    pass
            if ns['stroke_color'] is None:
                for attr in ('strokeColor', 'color'):
                    try:
                        if hasattr(symbol, attr):
                            sc = getattr(symbol, attr)()
                            ns['stroke_color'] = _qcolor_to_hex(sc)
                            if sc and hasattr(sc, 'alpha') and callable(sc.alpha):
                                ns['stroke_opacity'] = sc.alpha() / 255.0
                            break
                    except Exception:
                        continue
            if ns['stroke_width'] is None:
                for attr in ('strokeWidth', 'width'):
                    try:
                        if hasattr(symbol, attr):
                            ns['stroke_width'] = float(getattr(symbol, attr)())
                            break
                    except Exception:
                        continue
            if geom_type == 'Point' and ns['size'] is None:
                try:
                    ns['size'] = float(symbol.size())
                except Exception:
                    pass
            continue  # next layer

        # Fill 判定 (Polygon のみ)
        if geom_type == 'Polygon' and ns['fill_color'] is None:
            try:
                if Qt and hasattr(sl, 'brushStyle') and callable(sl.brushStyle):
                    bs = sl.brushStyle()
                    if bs != Qt.NoBrush:
                        if hasattr(sl, 'color') and callable(sl.color):
                            fc = sl.color()
                            # alpha > 0 の時だけ採用
                            if fc and hasattr(fc, 'alpha') and callable(fc.alpha) and fc.alpha() > 0:
                                ns['fill_color'] = _qcolor_to_hex(fc)
                                ns['fill_opacity'] = fc.alpha() / 255.0
            except Exception:
                pass

        # Stroke
        if ns['stroke_color'] is None:
            for attr in ('strokeColor', 'color'):
                try:
                    if hasattr(sl, attr) and callable(getattr(sl, attr)):
                        sc = getattr(sl, attr)()
                        if sc and (not hasattr(sc, 'alpha') or sc.alpha() > 0):
                            ns['stroke_color'] = _qcolor_to_hex(sc)
                            if sc and hasattr(sc, 'alpha') and callable(sc.alpha):
                                ns['stroke_opacity'] = sc.alpha() / 255.0
                            break
                except Exception:
                    continue

        # Stroke width
        if ns['stroke_width'] is None:
            for attr in ('strokeWidth', 'width'):
                try:
                    if hasattr(sl, attr) and callable(getattr(sl, attr)):
                        ns['stroke_width'] = float(getattr(sl, attr)())
                        break
                except Exception:
                    continue

        # Pen join/cap/style
        if ns['line_join'] is None and hasattr(sl, 'penJoinStyle') and callable(sl.penJoinStyle):
            try:
                pj = int(sl.penJoinStyle())
                ns['line_join'] = _JOIN_MAP.get(pj)
            except Exception:
                pass
        if ns['line_cap'] is None and hasattr(sl, 'penCapStyle') and callable(sl.penCapStyle):
            try:
                pc = int(sl.penCapStyle())
                ns['line_cap'] = _CAP_MAP.get(pc)
            except Exception:
                pass
        if ns['line_dash'] is None and hasattr(sl, 'penStyle') and callable(sl.penStyle):
            try:
                ps = int(sl.penStyle())
                ns['line_dash'] = _DASH_MAP.get(ps)
            except Exception:
                pass

        # Point shape / size
        if geom_type == 'Point':
            if ns['point_shape'] is None:
                try:
                    if hasattr(sl, 'shape') and callable(sl.shape):
                        shp = sl.shape()
                        ns['point_shape'] = _POINT_SHAPE_MAP.get(shp)
                except Exception:
                    pass
                if ns['point_shape'] is None and hasattr(sl, 'name') and callable(sl.name):
                    try:
                        ns['point_shape'] = str(sl.name()).lower()
                    except Exception:
                        pass
            if ns['size'] is None and hasattr(sl, 'size') and callable(sl.size):
                try:
                    ns['size'] = float(sl.size())
                except Exception:
                    pass

    # デフォルト補正
    if geom_type == 'Point' and ns['size'] is None:
        ns['size'] = 6.0
    if ns['stroke_width'] is None and geom_type in ('LineString', 'Polygon'):
        ns['stroke_width'] = 1.0

    # has_* 判定
    if ns['fill_color'] and ns['fill_opacity'] is not None and ns['fill_opacity'] > 0:
        ns['has_fill'] = True
    if ns['stroke_color'] and (ns['stroke_opacity'] is None or ns['stroke_opacity'] > 0):
        ns['has_stroke'] = True

    return ns

__all__ = ["extract_normalized_style"]
