# -*- coding: utf-8 -*-
"""Convert NormalizedStyle dicts directly to MapLibre layer definitions.

環境変数 `QMAP_USE_NORMALIZED_DIRECT=1` が有効な場合、SLD を介さずに
QGISシンボル→NormalizedStyle→MapLibre layers へ直接変換するためのユーティリティ。

初期バージョンの目的:
- 単一シンボル (singleSymbol) レイヤの高速・一貫変換
- ポリゴン: fill+stroke 両方 / 塗り無し枠線のみ / 塗りのみ の判定
- ライン: 色 / 幅 / 不透明度 / dash / join / cap
- ポイント: circle-color / circle-stroke-color / circle-stroke-width / circle-radius

後続拡張で複雑 (categorized / graduated / rule-based) を正規化ルール単位で複数 layer 化可能。
"""
from typing import Any, Dict, List, Optional
import os

try:
    from .style_normalizer import extract_normalized_style  # type: ignore
except Exception:  # pragma: no cover
    extract_normalized_style = None  # type: ignore

__all__ = ["normalized_style_for_layer", "normalized_style_to_maplibre_layers"]


def normalized_style_for_layer(layer) -> Optional[Dict[str, Any]]:
    """Layer から NormalizedStyle を取得。

    現時点では singleSymbol のみ直接対応し、それ以外は None を返し SLD 経由にフォールバック。
    """
    if extract_normalized_style is None or layer is None:
        return None
    try:
        renderer = layer.renderer()
        if not renderer:
            return None
        rtype = getattr(renderer, 'type', lambda: '')()
        if rtype != 'singleSymbol':  # 将来: categorizedSymbol 等を正規化拡張
            return None
        symbol = renderer.symbol() if hasattr(renderer, 'symbol') else None
        if not symbol:
            return None
        # geometryType(): 0 Point, 1 LineString, 2 Polygon
        gcode = None
        try:
            gcode = layer.geometryType()
        except Exception:
            gcode = None
        if gcode == 0:
            geom = 'Point'
        elif gcode == 1:
            geom = 'LineString'
        else:
            geom = 'Polygon'
        ns = extract_normalized_style(symbol, geom)
        return ns
    except Exception:
        return None


def normalized_style_to_maplibre_layers(ns: Dict[str, Any], source_id: str) -> List[Dict[str, Any]]:
    """NormalizedStyle から MapLibre layer dict のリストを生成。
    戻り値: List[MapboxLayer]
    """
    layers: List[Dict[str, Any]] = []
    if not ns:
        return layers
    geom = ns.get('geometry')

    # 共通データ
    stroke_color = ns.get('stroke_color')
    stroke_width = ns.get('stroke_width') or (2 if geom == 'LineString' else 1)
    stroke_opacity = ns.get('stroke_opacity')
    line_join = ns.get('line_join')
    line_cap = ns.get('line_cap')
    line_dash = ns.get('line_dash')

    def _apply_line_layout_paint(base: Dict[str, Any]):
        paint = base.setdefault('paint', {})
        layout = base.setdefault('layout', {})
        if stroke_color:
            if geom == 'LineString':
                paint['line-color'] = stroke_color
            else:
                # outline case
                paint['line-color'] = stroke_color
        if stroke_width is not None:
            paint['line-width'] = stroke_width
        if stroke_opacity is not None and stroke_opacity < 1.0:
            paint['line-opacity'] = float(stroke_opacity)
        if line_dash:
            paint['line-dasharray'] = [float(x) for x in line_dash]
        if line_join:
            layout['line-join'] = line_join
        if line_cap:
            layout['line-cap'] = line_cap
        return base

    if geom == 'Point':
        layer = {
            'id': f'{source_id}_circle_0',
            'type': 'circle',
            'source': source_id,
            'paint': {},
            'layout': {'visibility': 'visible'}
        }
        fill_color = ns.get('fill_color')
        fill_opacity = ns.get('fill_opacity')
        size = ns.get('size') or 6
        if fill_color:
            layer['paint']['circle-color'] = fill_color
        if fill_opacity is not None and fill_opacity < 1.0:
            layer['paint']['circle-opacity'] = float(fill_opacity)
        if stroke_color:
            layer['paint']['circle-stroke-color'] = stroke_color
            layer['paint']['circle-stroke-width'] = stroke_width if stroke_width is not None else 1
        layer['paint']['circle-radius'] = size
        layers.append(layer)
        return layers

    if geom == 'LineString':
        layer = {
            'id': f'{source_id}_line_0',
            'type': 'line',
            'source': source_id,
            'paint': {},
            'layout': {'visibility': 'visible'}
        }
        _apply_line_layout_paint(layer)
        layers.append(layer)
        return layers

    # Polygon
    if geom == 'Polygon':
        has_fill = ns.get('has_fill')
        has_stroke = ns.get('has_stroke')
        fill_color = ns.get('fill_color')
        fill_opacity = ns.get('fill_opacity')

        if has_fill and fill_color:
            fill_layer = {
                'id': f'{source_id}_fill_0',
                'type': 'fill',
                'source': source_id,
                'paint': {},
                'layout': {'visibility': 'visible'}
            }
            fill_layer['paint']['fill-color'] = fill_color
            if fill_opacity is not None and fill_opacity < 1.0:
                fill_layer['paint']['fill-opacity'] = float(fill_opacity)
            layers.append(fill_layer)

        if has_stroke and stroke_color:
            outline_layer = {
                'id': f'{source_id}_line_{len(layers)}',
                'type': 'line',
                'source': source_id,
                'paint': {},
                'layout': {'visibility': 'visible'}
            }
            _apply_line_layout_paint(outline_layer)
            # もし fill layer が同時に存在し単純線なら統合検討 (将来)
            layers.append(outline_layer)
        return layers

    return layers


def debug_log_normalized_style(ns: Dict[str, Any]):  # pragma: no cover - ログ用途
    if not ns:
        return
    if os.getenv('QMAP_DEBUG_STYLE') == '1':
        try:
            from qgis.core import QgsMessageLog, Qgis
            import json
            QgsMessageLog.logMessage(
                f"🔍 NormalizedStyle: {json.dumps(ns, ensure_ascii=False)}",
                'QMapPermalink', Qgis.Info
            )
        except Exception:
            pass
