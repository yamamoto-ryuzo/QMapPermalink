# -*- coding: utf-8 -*-
"""Simple SLD renderer helpers

This module provides a lightweight conversion of QGIS renderers (categorized,
graduated, rule-based, single-symbol) into a basic SLD 1.1.0 string. It is
intended as a pragmatic, best-effort exporter for use by WFS GetStyles.

The output focuses on simple symbol properties (fill/stroke color, stroke
width, size, opacity). Complex symbol layers, external graphics or vendor
options are intentionally not fully supported here.
"""

from typing import Optional

from qgis.core import (
    QgsCategorizedSymbolRenderer, QgsGraduatedSymbolRenderer, QgsRuleBasedRenderer,
    QgsSingleSymbolRenderer
)

# 統一スタイル正規化ロジック
try:
    from .style_normalizer import extract_normalized_style  # type: ignore
except Exception:  # pragma: no cover - 相対 import 失敗時のフォールバック
    def extract_normalized_style(symbol, geom_type: str):
        return {
            'geometry': geom_type,
            'fill_color': None,
            'fill_opacity': None,
            'stroke_color': None,
            'stroke_opacity': None,
            'stroke_width': 1.0,
            'line_join': None,
            'line_cap': None,
            'line_dash': None,
            'point_shape': None,
            'size': 6.0 if geom_type == 'Point' else None,
            'has_fill': False,
            'has_stroke': True,
        }


def _sld_header(layer_name: str) -> str:
    return (
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<StyledLayerDescriptor version="1.1.0" xmlns="http://www.opengis.net/sld" '
        f'xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" '
        f'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        f'xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.1.0/StyledLayerDescriptor.xsd">\n'
        f'  <NamedLayer>\n'
        f'    <Name>{layer_name}</Name>\n'
        f'    <UserStyle>\n'
        f'      <FeatureTypeStyle>\n'
    )


def _sld_footer() -> str:
    return (
        f'      </FeatureTypeStyle>\n'
        f'    </UserStyle>\n'
        f'  </NamedLayer>\n'
        f'</StyledLayerDescriptor>'
    )


def _escape_xml(s: Optional[str]) -> str:
    if s is None:
        return ''
    return (str(s)
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
            .replace("'", '&apos;'))


#############################
# 旧 _extract_symbol_properties は廃止し style_normalizer に一本化
#############################


def _build_stroke_params(stroke_color, stroke_width, stroke_opacity, pen_join_style, pen_cap_style, pen_style):
    """Build stroke CssParameter elements including advanced styling.
    
    Returns: formatted string with CssParameter elements
    """
    sc = _escape_xml(stroke_color or '#000000')
    sw = stroke_width if stroke_width is not None else 1
    so = stroke_opacity if (stroke_opacity is not None) else 1.0
    
    stroke_params = f'    <CssParameter name="stroke">{sc}</CssParameter>\n'
    stroke_params += f'    <CssParameter name="stroke-width">{sw}</CssParameter>\n'
    if so < 1.0:
        stroke_params += f'    <CssParameter name="stroke-opacity">{so}</CssParameter>\n'
    
    # Add line join style (using integer values for compatibility)
    if pen_join_style is not None:
        try:
            # Qt.MiterJoin=0, Qt.BevelJoin=64, Qt.RoundJoin=128
            join_val = int(pen_join_style)
            if join_val == 64:  # BevelJoin
                stroke_params += f'    <CssParameter name="stroke-linejoin">bevel</CssParameter>\n'
            elif join_val == 128:  # RoundJoin
                stroke_params += f'    <CssParameter name="stroke-linejoin">round</CssParameter>\n'
            elif join_val == 0:  # MiterJoin
                stroke_params += f'    <CssParameter name="stroke-linejoin">mitre</CssParameter>\n'
        except Exception:
            pass
    
    # Add line cap style (using integer values for compatibility)
    if pen_cap_style is not None:
        try:
            # Qt.FlatCap=0, Qt.SquareCap=16, Qt.RoundCap=32
            cap_val = int(pen_cap_style)
            if cap_val == 0:  # FlatCap
                stroke_params += f'    <CssParameter name="stroke-linecap">butt</CssParameter>\n'
            elif cap_val == 16:  # SquareCap
                stroke_params += f'    <CssParameter name="stroke-linecap">square</CssParameter>\n'
            elif cap_val == 32:  # RoundCap
                stroke_params += f'    <CssParameter name="stroke-linecap">round</CssParameter>\n'
        except Exception:
            pass
    
    # Add dash pattern (using integer values for compatibility)
    if pen_style is not None:
        try:
            # Qt.SolidLine=1, Qt.DashLine=2, Qt.DotLine=3, Qt.DashDotLine=4, Qt.DashDotDotLine=5
            style_val = int(pen_style)
            if style_val == 2:  # DashLine
                stroke_params += f'    <CssParameter name="stroke-dasharray">5 2</CssParameter>\n'
            elif style_val == 3:  # DotLine
                stroke_params += f'    <CssParameter name="stroke-dasharray">1 2</CssParameter>\n'
            elif style_val == 4:  # DashDotLine
                stroke_params += f'    <CssParameter name="stroke-dasharray">5 2 1 2</CssParameter>\n'
            elif style_val == 5:  # DashDotDotLine
                stroke_params += f'    <CssParameter name="stroke-dasharray">5 2 1 2 1 2</CssParameter>\n'
        except Exception:
            pass
    
    return stroke_params


def _symbol_to_symbolizer(symbol, geom_type: str) -> str:
    """統一正規化スタイルから SLD Symbolizer を構築

    旧バージョンとの差異:
    - Polygon のブラシなしの場合でも LineSymbolizer へ変換せず PolygonSymbolizer + Stroke のみに統一可能だが、
      既存互換性維持のため (境界のみ描画ケース) は LineSymbolizer を返す。
    - ロジックは style_normalizer.extract_normalized_style に一本化
    """
    try:
        ns = extract_normalized_style(symbol, geom_type)
        geo = ns['geometry']

        # Stroke 共通部品
        stroke_params = _build_stroke_params(
            ns['stroke_color'], ns['stroke_width'] or (2 if geo == 'LineString' else 1),
            ns['stroke_opacity'], ns.get('line_join'), ns.get('line_cap'), _dash_pattern_to_pen_style(ns.get('line_dash'))
        )

        if geo == 'Point':
            fc = _escape_xml(ns['fill_color'] or '#000000')
            sc = _escape_xml(ns['stroke_color'] or '#000000')
            size = ns['size'] or 6
            well_known = ns['point_shape'] or 'circle'
            return (
                f'<PointSymbolizer>\n'
                f'  <Graphic>\n'
                f'    <Mark>\n'
                f'      <WellKnownName>{well_known}</WellKnownName>\n'
                f'      <Fill><CssParameter name="fill">{fc}</CssParameter></Fill>\n'
                f'      <Stroke><CssParameter name="stroke">{sc}</CssParameter>\n'
                f'        <CssParameter name="stroke-width">1</CssParameter></Stroke>\n'
                f'    </Mark>\n'
                f'    <Size>{size}</Size>\n'
                f'  </Graphic>\n'
                f'</PointSymbolizer>\n'
            )

        if geo == 'LineString':
            return (
                f'<LineSymbolizer>\n'
                f'  <Stroke>\n'
                f'{stroke_params}'
                f'  </Stroke>\n'
                f'</LineSymbolizer>\n'
            )

        # Polygon 分岐
        if ns['has_fill']:
            fc = _escape_xml(ns['fill_color'])
            fo = ns['fill_opacity'] if ns['fill_opacity'] is not None else 1.0
            return (
                f'<PolygonSymbolizer>\n'
                f'  <Fill>\n'
                f'    <CssParameter name="fill">{fc}</CssParameter>\n'
                f'    <CssParameter name="fill-opacity">{fo}</CssParameter>\n'
                f'  </Fill>\n'
                f'  <Stroke>\n'
                f'{stroke_params}'
                f'  </Stroke>\n'
                f'</PolygonSymbolizer>\n'
            )
        else:
            # ブラシなしポリゴン → 枠線のみ: 互換性のため LineSymbolizer (既存クライアント側ロジック期待)
            return (
                f'<LineSymbolizer>\n'
                f'  <Stroke>\n'
                f'{stroke_params}'
                f'  </Stroke>\n'
                f'</LineSymbolizer>\n'
            )
    except Exception:
        return ''


def _dash_pattern_to_pen_style(dash) -> Optional[int]:
    """style_normalizer から来た line_dash (List[float]) を旧ペンスタイル整数に逆変換。
    逆変換できない場合は None。 (stroke_params 内で利用)
    """
    if not dash:
        return 1  # SolidLine
    # 簡易判定: 既存マッピングに合わせる
    if dash == [5.0, 2.0]:
        return 2
    if dash == [1.0, 2.0]:
        return 3
    if dash == [5.0, 2.0, 1.0, 2.0]:
        return 4
    if dash == [5.0, 2.0, 1.0, 2.0, 1.0, 2.0]:
        return 5
    return None


def _rule_xml(name: str, filter_xml: Optional[str], symbolizer_xml: str) -> str:
    nm = _escape_xml(name or '')
    filt = f'{filter_xml}\n' if filter_xml else ''
    return (
        f'        <Rule>\n'
        f'          <Name>{nm}</Name>\n'
        f'{filt}'
        f'{symbolizer_xml}'
        f'        </Rule>\n'
    )


def _filter_equal(field: str, value) -> str:
    return (
        f'          <ogc:Filter>\n'
        f'            <ogc:PropertyIsEqualTo>\n'
        f'              <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
        f'              <ogc:Literal>{_escape_xml(value)}</ogc:Literal>\n'
        f'            </ogc:PropertyIsEqualTo>\n'
        f'          </ogc:Filter>'
    )


def _filter_range(field: str, lower, upper) -> str:
    # Use And of >= lower and < upper (upper may be None meaning >= lower)
    if upper is None:
        return (
            f'          <ogc:Filter>\n'
            f'            <ogc:PropertyIsGreaterThanOrEqualTo>\n'
            f'              <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
            f'              <ogc:Literal>{_escape_xml(lower)}</ogc:Literal>\n'
            f'            </ogc:PropertyIsGreaterThanOrEqualTo>\n'
            f'          </ogc:Filter>'
        )
    return (
        f'          <ogc:Filter>\n'
        f'            <ogc:And>\n'
        f'              <ogc:PropertyIsGreaterThanOrEqualTo>\n'
        f'                <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
        f'                <ogc:Literal>{_escape_xml(lower)}</ogc:Literal>\n'
        f'              </ogc:PropertyIsGreaterThanOrEqualTo>\n'
        f'              <ogc:PropertyIsLessThan>\n'
        f'                <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
        f'                <ogc:Literal>{_escape_xml(upper)}</ogc:Literal>\n'
        f'              </ogc:PropertyIsLessThan>\n'
        f'            </ogc:And>\n'
        f'          </ogc:Filter>'
    )


def renderer_to_sld(layer, layer_name: Optional[str] = None) -> str:
    """Convert a layer.renderer() to an SLD string (best-effort).

    Returns a full SLD document string.
    """
    ln = layer_name or str(layer.id())
    renderer = layer.renderer()
    if renderer is None:
        # trivial default
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(f"No renderer for layer {ln}, returning default SLD", "QMapPermalink", Qgis.Warning)
        return _sld_header(ln) + _rule_xml('default', None, _symbol_to_symbolizer(None, 'Polygon')) + _sld_footer()

    rules = []

    try:
        # Single symbol
        if isinstance(renderer, QgsSingleSymbolRenderer):
            sym = renderer.symbol()
            geom = getattr(sym, 'geometryType', None)
            # fallback: try to guess from layer geometry
            gtype = 'Polygon'
            try:
                if layer.geometryType() == 0:
                    gtype = 'Point'
                elif layer.geometryType() == 1:
                    gtype = 'LineString'
                else:
                    gtype = 'Polygon'
            except Exception:
                pass
            rules.append((_escape_xml('default'), None, _symbol_to_symbolizer(sym, gtype)))

        # Categorized
        elif isinstance(renderer, QgsCategorizedSymbolRenderer):
            field = ''
            try:
                field = renderer.classAttribute()
            except Exception:
                try:
                    field = renderer.attribute()
                except Exception:
                    field = ''
            try:
                cats = renderer.categories()
                for c in cats:
                    val = c.value()
                    label = c.label() or str(val)
                    sym = c.symbol()
                    # guess geom type from layer if possible
                    gtype = 'Polygon'
                    try:
                        if layer.geometryType() == 0:
                            gtype = 'Point'
                        elif layer.geometryType() == 1:
                            gtype = 'LineString'
                    except Exception:
                        pass
                    filt = _filter_equal(field, val) if field else None
                    rules.append((label, filt, _symbol_to_symbolizer(sym, gtype)))
            except Exception:
                pass

        # Graduated
        elif isinstance(renderer, QgsGraduatedSymbolRenderer):
            field = ''
            try:
                field = renderer.classAttribute()
            except Exception:
                try:
                    field = renderer.attribute()
                except Exception:
                    field = ''
            try:
                ranges = renderer.ranges()
                for r in ranges:
                    lab = r.label() or f"{r.lowerValue()} - {r.upperValue()}"
                    sym = r.symbol()
                    gtype = 'Polygon'
                    try:
                        if layer.geometryType() == 0:
                            gtype = 'Point'
                        elif layer.geometryType() == 1:
                            gtype = 'LineString'
                    except Exception:
                        pass
                    filt = None
                    if field:
                        # upper may be None
                        lower = r.lowerValue()
                        upper = r.upperValue()
                        filt = _filter_range(field, lower, upper)
                    rules.append((lab, filt, _symbol_to_symbolizer(sym, gtype)))
            except Exception:
                pass

        # Rule based
        elif isinstance(renderer, QgsRuleBasedRenderer):
            try:
                root = renderer.rootRule()
                def walk(rule):
                    res = []
                    # rule may have a symbol
                    try:
                        sym = rule.symbol()
                    except Exception:
                        sym = None
                    try:
                        label = rule.label() or ''
                    except Exception:
                        label = ''
                    try:
                        expr = rule.filterExpression() or ''
                    except Exception:
                        expr = ''
                    # convert expression into a naive ogc filter if simple 'field = value'
                    filt = None
                    if expr:
                        # naive parsing: look for = operator
                        m = expr.split('=')
                        if len(m) == 2:
                            field = m[0].strip().strip('"')
                            val = m[1].strip().strip('\'"')
                            filt = _filter_equal(field, val)
                    # guess geom type
                    gtype = 'Polygon'
                    try:
                        if layer.geometryType() == 0:
                            gtype = 'Point'
                        elif layer.geometryType() == 1:
                            gtype = 'LineString'
                    except Exception:
                        pass
                    if sym is not None:
                        res.append((label, filt, _symbol_to_symbolizer(sym, gtype)))
                    # children
                    try:
                        for child in rule.children():
                            res.extend(walk(child))
                    except Exception:
                        pass
                    return res

                for child in root.children():
                    rules.extend(walk(child))
            except Exception:
                pass

        # Fallback: try symbolForFeature via renderer if nothing produced
        if not rules:
            try:
                from qgis.core import QgsRenderContext, QgsExpressionContext, QgsExpressionContextUtils, QgsFeature
                ctx = QgsRenderContext()
                ctx.setExpressionContext(QgsExpressionContext())
                ctx.expressionContext().appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                dummy = QgsFeature()
                ctx.expressionContext().setFeature(dummy)
                sym = renderer.symbolForFeature(dummy, ctx)
                gtype = 'Polygon'
                try:
                    if layer.geometryType() == 0:
                        gtype = 'Point'
                    elif layer.geometryType() == 1:
                        gtype = 'LineString'
                except Exception:
                    pass
                rules.append(('default', None, _symbol_to_symbolizer(sym, gtype)))
            except Exception:
                pass

    except Exception:
        # any error -> return empty default
        return _sld_header(ln) + _rule_xml('default', None, _symbol_to_symbolizer(None, 'Polygon')) + _sld_footer()

    # assemble SLD
    body = _sld_header(ln)
    for name, filt, symxml in rules:
        body += _rule_xml(name, filt, symxml)
    body += _sld_footer()
    return body
