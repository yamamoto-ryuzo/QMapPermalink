# -*- coding: utf-8 -*-
import socket
import threading
import urllib.parse
import json
import html
import math
import os
import re
from qgis.core import QgsProject, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY, QgsMessageLog, Qgis
# lazy import http_server inside methods to avoid circular import during QGIS plugin init

class QMapPermalinkServerManager:
    """QMapPermalink用HTTPサーバー管理クラス - WMS専用シンプル版
    
    WMSサーバーの起動・停止・リクエスト処理を担当します。
    不要なエンドポイント（画像、マップ、タイル）は全て削除されています。
    """
    
    def __init__(self, iface, navigation_signals, webmap_generator, main_plugin):
        """サーバーマネージャーを初期化
        
        Args:
            iface: QGISインターフェース
            navigation_signals: ナビゲーション用シグナル
            webmap_generator: WebMapGeneratorインスタンス
            main_plugin: メインプラグインクラスのインスタンス（共通メソッド呼び出し用）
        """
        self.iface = iface
        self.navigation_signals = navigation_signals
        self.main_plugin = main_plugin
        self.webmap_generator = webmap_generator
        
        # WMSサービスを初期化
        from .qmap_wms_service import QMapPermalinkWMSService
        self.wms_service = QMapPermalinkWMSService(iface, webmap_generator, 8089, False)
        # WMTSサービスを初期化（サーバマネージャ自身を渡すことで依存を小さくする）
        try:
            from .qmap_wmts_service import QMapPermalinkWMTSService
            self.wmts_service = QMapPermalinkWMTSService(self)
        except Exception:
            # 初期化が失敗してもサーバは動作を続けられるように None を許容
            self.wmts_service = None
        
        # WFSサービスを初期化
        try:
            from .qmap_wfs_service import QMapPermalinkWFSService
            self.wfs_service = QMapPermalinkWFSService(iface, 8089)
        except Exception:
            # 初期化が失敗してもサーバは動作を続けられるように None を許容
            self.wfs_service = None
        
        # HTTPサーバー関連の状態
        self.http_server = None
        self.server_thread = None
        self.server_port = 8089  # デフォルトポート
        self._http_running = False
        self._last_request_text = ""
        
        # プラグインバージョン情報
        self.plugin_version = self._get_plugin_version()
        # 任意のCRSを強制的にEPSG:3857として扱うオプション（デフォルト: False）
        self.force_epsg3857 = False

    def _safe_int(self, value, default):
        """文字列から安全にintに変換する。NaNや不正値は default を返す。"""
        try:
            # floatを経由して 'NaN' をはじく
            v = float(value)
            if v != v:  # NaN check
                return int(default)
            return int(v)
        except Exception:
            return int(default)

    def _get_plugin_version(self):
        """metadata.txtからプラグインバージョンを取得"""
        try:
            plugin_dir = os.path.dirname(__file__)
            metadata_path = os.path.join(plugin_dir, 'metadata.txt')
            
            if os.path.exists(metadata_path):
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    
                    # 各行をチェック（スペースを無視）
                    for line in lines:
                        # スペースを削除して "version=" で始まるかチェック
                        clean_line = line.replace(' ', '').replace('\t', '').lower()
                        if clean_line.startswith('version='):
                            # 元の行から値を抽出
                            if '=' in line:
                                version = line.split('=')[1].strip()
                                return version
                    
        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"❌ バージョン取得エラー: {e}", "QMapPermalink", Qgis.Warning)
        
        # デフォルトバージョン（metadata.txtから読み取れない場合）
        return "UNKNOWN"

    def start_http_server(self):
        """HTTPサーバーを起動"""
        try:
            if self._http_running:
                return

            # 使用可能なポートを探す
            self.server_port = self.find_available_port(8089, 8099)

            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            # bind to all interfaces so non-localhost access is possible
            server_socket.bind(('0.0.0.0', self.server_port))
            server_socket.listen(5)
            server_socket.settimeout(1.0)

            self.http_server = server_socket
            self._http_running = True

            self.server_thread = threading.Thread(
                target=self.run_server,
                name="QMapPermalinkHTTP",
                daemon=True,
            )
            self.server_thread.start()

            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"🚀 QMap Permalink v{self.plugin_version} WMS HTTPサーバーが起動しました: http://localhost:{self.server_port}/wms", "QMapPermalink", Qgis.Info)
            self.iface.messageBar().pushMessage(
                "QMap Permalink",
                f"WMS HTTPサーバーが起動しました (ポート: {self.server_port})",
                duration=3
            )

        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"HTTPサーバーの起動に失敗しました: {e}", "QMapPermalink", Qgis.Critical)
            self.iface.messageBar().pushMessage(
                "QMap Permalink エラー",
                f"HTTPサーバーの起動に失敗しました: {str(e)}",
                duration=5
            )
            self._http_running = False
            if self.http_server:
                try:
                    self.http_server.close()
                except Exception:
                    pass
                self.http_server = None
    
    def run_server(self):
        """サーバーを安全に実行"""
        try:
            while self._http_running and self.http_server:
                try:
                    conn, addr = self.http_server.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break

                try:
                    self._handle_client_connection(conn, addr)
                except Exception as e:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"HTTPリクエスト処理中にエラーが発生しました: {e}", "QMapPermalink", Qgis.Critical)

        finally:
            self._http_running = False
            if self.http_server:
                try:
                    self.http_server.close()
                except Exception:
                    pass
                self.http_server = None
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage("HTTPサーバーが停止しました", "QMapPermalink", Qgis.Info)
    
    def stop_http_server(self):
        """HTTPサーバーを停止"""
        try:
            self._http_running = False

            if self.http_server:
                try:
                    self.http_server.close()
                except Exception:
                    pass
                self.http_server = None

            # スレッドの終了を待つ
            if self.server_thread and self.server_thread.is_alive():
                try:
                    self.server_thread.join(timeout=3.0)
                except Exception:
                    pass
                self.server_thread = None

            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage("QMap Permalink HTTPサーバーが停止しました", "QMapPermalink", Qgis.Info)
            
        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"HTTPサーバーの停止中にエラーが発生しました: {e}", "QMapPermalink", Qgis.Critical)

    def _handle_client_connection(self, conn, addr):
        """HTTPリクエストを解析してWMSリクエストを処理"""
        # 初期タイムアウト設定（リクエスト読み取り用）
        conn.settimeout(10.0)
        
        with conn:
            from . import http_server
            request_bytes = http_server.read_http_request(conn)
            if not request_bytes:
                return

            request_text = request_bytes.decode('iso-8859-1', errors='replace')
            self._last_request_text = request_text

            from qgis.core import QgsMessageLog, Qgis
            try:
                request_line = request_text.splitlines()[0]
            except IndexError:
                from . import http_server
                http_server.send_http_response(conn, 400, "Bad Request", "Invalid HTTP request line.")
                return

            parts = request_line.split()
            if len(parts) < 3:
                from . import http_server
                http_server.send_http_response(conn, 400, "Bad Request", "Malformed HTTP request line.")
                return

            method, target, _ = parts

            if method.upper() != 'GET':
                from . import http_server
                http_server.send_http_response(conn, 405, "Method Not Allowed", "Only GET is supported.")
                return

            parsed_url = urllib.parse.urlparse(target)
            params = urllib.parse.parse_qs(parsed_url.query)
            # Manually unquote parameter values to handle UTF-8 encoding issues
            for key in params:
                params[key] = [urllib.parse.unquote_plus(val) for val in params[key]]
            # Extract Host header for use in generated URLs (used for OnlineResource)
            host = None
            for line in request_text.splitlines():
                if line.lower().startswith('host:'):
                    host = line.split(':', 1)[1].strip()
                    break

            # ブラウザで読み込まれるページURL（/qgis-map）を受け取ったときだけ
            # パネルのナビゲート欄に表示するためにemitする。
            try:
                if parsed_url.path in ('/qgis-map', '/maplibre'):
                    server_port = None
                    try:
                        server_port = self.http_server.getsockname()[1] if self.http_server else self.server_port
                    except Exception:
                        server_port = self.server_port

                    if not host:
                        host = f'localhost:{server_port}'

                    # target が absolute URI の場合はそのまま使う
                    if target.startswith('http://') or target.startswith('https://'):
                        full_url = target
                    else:
                        full_url = f'http://{host}{target}'

                    # Emit the full URL for UI if signal available
                    if hasattr(self, 'navigation_signals') and self.navigation_signals:
                        try:
                            if hasattr(self.navigation_signals, 'request_origin_changed'):
                                self.navigation_signals.request_origin_changed.emit(full_url)
                        except Exception:
                            pass

                    # main_plugin にも保持（パネル未作成時のフォールバック）
                    try:
                        if hasattr(self, 'main_plugin'):
                            setattr(self.main_plugin, '_last_request_origin', full_url)
                    except Exception:
                        pass
            except Exception:
                pass

            # WMSエンドポイントの処理（直接PNG画像返却）
            if parsed_url.path == '/wms':
                try:
                    self.wms_service.handle_wms_request(conn, params, host)
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ WMS handler error: {e}", "QMapPermalink", Qgis.Critical)
                    import traceback
                    QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, "Internal Server Error", f"WMS processing failed: {str(e)}")
                return
            
            # OpenLayersパーマリンクエンドポイントの処理（HTMLページ生成、内部で/wmsを参照）
            if parsed_url.path == '/qgis-map':
                try:
                    self._handle_permalink_html_page(conn, params)
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ OpenLayers HTML page error: {e}", "QMapPermalink", Qgis.Critical)
                    import traceback
                    QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, "Internal Server Error", f"OpenLayers HTML page generation failed: {str(e)}")
                return

            # Dynamic MapLibre style endpoint: return a Mapbox style JSON for a given WFS typename
            if parsed_url.path in ('/maplibre-style', '/maplibre/style'):
                try:
                    # Determine typename (support several param names)
                    wfs_typename = None
                    for k in ('typename', 'typenames', 'TYPENAME', 'TYPENAMES', 'layer', 'layers', 'type', 'typeName'):
                        if k in params and params.get(k):
                            wfs_typename = params.get(k)[0]
                            break
                    
                    # If no typename specified, return a base WMTS-only style (no WFS layers)
                    if not wfs_typename:
                        # MapLibre expects {z}, {y}, {x} placeholders in tile URLs
                        wmts_tile_url = f"http://localhost:{self.server_port}/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=qmap&STYLE=default&TILEMATRIXSET=EPSG:3857&TILEMATRIX={{z}}&TILEROW={{y}}&TILECOL={{x}}&FORMAT=image/png"
                        wmts_base_style = {
                            "version": 8,
                            "sources": {
                                "wmts": {
                                    "type": "raster",
                                    "tiles": [wmts_tile_url],
                                    "tileSize": 256
                                }
                            },
                            "layers": [
                                {
                                    "id": "wmts-layer",
                                    "type": "raster",
                                    "source": "wmts",
                                    "minzoom": 0,
                                    "maxzoom": 22
                                }
                            ]
                        }
                        payload = json.dumps(wmts_base_style, ensure_ascii=False)
                        from . import http_server
                        http_server.send_http_response(conn, 200, 'OK', payload, 'application/json; charset=utf-8')
                        return

                    # Ensure WFS service exists
                    if not hasattr(self, 'wfs_service') or self.wfs_service is None:
                        from . import http_server
                        http_server.send_http_response(conn, 501, 'Not Implemented', 'WFS service not available', 'text/plain; charset=utf-8')
                        return

                    # Find layer and try several matching strategies
                    layer = None
                    try:
                        layer = self.wfs_service._find_layer_by_name(wfs_typename)
                    except Exception:
                        layer = None

                    if layer is None:
                        # Strict policy: typename must be the exact QGIS layer.id()
                        try:
                            cands = self.wfs_service._get_vector_layers()
                        except Exception:
                            cands = []
                        cand_ids = []
                        for c in cands:
                            try:
                                cand_ids.append(c.id())
                            except Exception:
                                continue
                        body = {
                            'error': f"Layer '{wfs_typename}' not found",
                            'available_typenames': cand_ids
                        }
                        payload = json.dumps(body, ensure_ascii=False, indent=2)
                        from . import http_server
                        http_server.send_http_response(conn, 404, 'Not Found', payload, 'application/json; charset=utf-8')
                        return

                    # --- Style conversion path selection (A: direct normalized style vs legacy SLD) ---
                    use_direct = False
                    try:
                        import os as _os_mod
                        use_direct = _os_mod.getenv('QMAP_USE_NORMALIZED_DIRECT') == '1'
                    except Exception:
                        use_direct = False

                    mapbox_layers = []
                    from . import qmap_maplibre as qmap_maplibre
                    try:
                        raw_id = layer.id()
                    except Exception:
                        raw_id = str(wfs_typename)
                    _wfs_source_id = str(raw_id)

                    if use_direct:
                        # Attempt direct NormalizedStyle → MapLibre path
                        try:
                            from .style_from_normalized import normalized_style_for_layer, normalized_style_to_maplibre_layers, debug_log_normalized_style
                            ns = normalized_style_for_layer(layer)
                            debug_log_normalized_style(ns)
                            if ns:
                                mapbox_layers = normalized_style_to_maplibre_layers(ns, _wfs_source_id)
                            else:
                                use_direct = False
                        except Exception:
                            use_direct = False

                    if not mapbox_layers and not use_direct:
                        # Fallback: generate SLD and convert (legacy path)
                        try:
                            sld_xml = self.wfs_service._generate_sld(layer)
                        except Exception as e:
                            from . import http_server
                            http_server.send_http_response(conn, 500, 'Internal Server Error', f'Failed to generate SLD: {e}', 'text/plain; charset=utf-8')
                            return
                        try:
                            mapbox_layers = qmap_maplibre.sld_to_mapbox_style(sld_xml, _wfs_source_id)
                        except Exception as e:
                            from . import http_server
                            http_server.send_http_response(conn, 500, 'Internal Server Error', f'Failed to convert SLD: {e}', 'text/plain; charset=utf-8')
                            return

                        # Ensure any layer produced by the SLD converter that
                        # references another "wfs_*" source is normalized to the
                        # canonical _wfs_source_id. This prevents mismatches where
                        # the converter used a slightly different id (e.g. kept
                        # leading underscores) and the client ends up referencing
                        # a source that doesn't exist in the style's sources map.
                        try:
                            for i, ml in enumerate(mapbox_layers):
                                try:
                                    if not isinstance(ml, dict):
                                        continue
                                    src = ml.get('source')
                                    if not src:
                                        continue
                                    # Normalize only wfs-prefixed sources; leave
                                    # other sources untouched.
                                    if isinstance(src, str) and src.startswith('wfs') and src != _wfs_source_id:
                                        # normalize legacy/alternate wfs_* source ids to the canonical raw id
                                        ml['source'] = _wfs_source_id
                                        mapbox_layers[i] = ml
                                except Exception:
                                    continue
                        except Exception:
                            pass

                        # Ensure each returned Mapbox layer explicitly declares a 'type'.
                        # If conversion emitted layers without 'type', infer from the
                        # QGIS layer geometry when possible (0:Point,1:Line,2:Polygon).
                        try:
                            geom_type_code = None
                            try:
                                geom_type_code = layer.geometryType() if hasattr(layer, 'geometryType') else None
                            except Exception:
                                geom_type_code = None

                            def _infer_type_from_geom(code):
                                if code == 0:
                                    return 'circle'
                                if code == 1:
                                    return 'line'
                                if code == 2:
                                    return 'fill'
                                return None

                            inferred = _infer_type_from_geom(geom_type_code)
                            for i, ml in enumerate(mapbox_layers):
                                try:
                                    if not isinstance(ml, dict):
                                        continue
                                    if 'type' in ml and ml['type']:
                                        continue
                                    # Try to infer from explicit paint keys first
                                    p = ml.get('paint') or {}
                                    ltype = None
                                    if any(k.startswith('circle-') for k in p.keys()):
                                        ltype = 'circle'
                                    elif any(k.startswith('line-') for k in p.keys()):
                                        ltype = 'line'
                                    elif any(k.startswith('fill-') for k in p.keys()):
                                        ltype = 'fill'
                                    else:
                                        # fall back to geometry-based inference
                                        ltype = inferred
                                    # final fallback: symbol (labels) if layout suggests text
                                    if not ltype:
                                        layout = ml.get('layout') or {}
                                        if 'text-field' in layout or layout.get('symbol-placement'):
                                            ltype = 'symbol'
                                    if not ltype:
                                        # Last resort: treat as 'line' for vector outlines
                                        ltype = 'line'
                                    ml['type'] = ltype
                                    mapbox_layers[i] = ml
                                except Exception:
                                    continue
                        except Exception:
                            # non-fatal: continue without enforcing types
                            pass

                        # Safety: if the underlying QGIS layer is a LineString-based
                        # layer, there is no point in returning 'fill' layers which
                        # target polygon geometries. Remove any 'fill' Mapbox layers
                        # when the geometry indicates a line to avoid client-side
                        # rendering errors and mismatches (e.g. MultiLineString
                        # being treated as polygons).
                        try:
                            # Default/fallback based on QGIS layer geometry type or inferred type
                            is_line_based = (geom_type_code == 1) or (inferred == 'line')

                            # Strengthen the decision by sampling up to a few WFS features
                            # from the actual layer. Use majority-of-sample rule to decide
                            # if the source is truly line-based. Any error -> keep fallback.
                            try:
                                from .qmap_wfs_service import QMapPermalinkWFSService

                                wfs_svc = getattr(self, 'wfs_service', None)
                                if wfs_svc is None:
                                    try:
                                        wfs_svc = QMapPermalinkWFSService(self.iface, getattr(self, 'server_port', 8089))
                                    except Exception:
                                        wfs_svc = None

                                if wfs_svc and layer is not None:
                                    try:
                                        sample_feats = wfs_svc._query_features(layer, None, None, 3)
                                    except Exception:
                                        sample_feats = None

                                    if sample_feats:
                                        line_count = poly_count = point_count = 0
                                        for sf in sample_feats:
                                            try:
                                                geom = sf.geometry()
                                                if geom is None or geom.isEmpty():
                                                    continue
                                                # Prefer geometry.type() where available
                                                gtype = None
                                                try:
                                                    gtype = geom.type()
                                                except Exception:
                                                    try:
                                                        gtype = geom.geometryType()
                                                    except Exception:
                                                        gtype = None

                                                if gtype == 1:
                                                    line_count += 1
                                                elif gtype == 2:
                                                    poly_count += 1
                                                elif gtype == 0:
                                                    point_count += 1
                                                else:
                                                    # Fallback to WKT prefix heuristic
                                                    try:
                                                        wkt = geom.asWkt().upper()
                                                        if wkt.startswith('LINE'):
                                                            line_count += 1
                                                        elif wkt.startswith('POLY'):
                                                            poly_count += 1
                                                        elif wkt.startswith('POINT'):
                                                            point_count += 1
                                                    except Exception:
                                                        continue
                                            except Exception:
                                                continue

                                        total = line_count + poly_count + point_count
                                        if total > 0:
                                            # majority rule: lines > 50% -> treat as line-based
                                            is_line_based = (line_count > (total / 2.0))
                            except Exception:
                                # non-fatal: keep original fallback if anything goes wrong
                                pass

                            # Helper: normalize hex color possibly containing alpha (#AARRGGBB)
                            def _normalize_hex_and_opacity(raw_color):
                                """Return (hex_rgb, opacity) where hex_rgb is '#RRGGBB' and opacity is float 0..1.
                                If parsing fails, return (None, None).
                                """
                                try:
                                    if not raw_color:
                                        return (None, None)
                                    s = str(raw_color).strip()
                                    # QColor.name(QColor.HexArgb) tends to return '#AARRGGBB'
                                    if s.startswith('#'):
                                        # #AARRGGBB
                                        if len(s) == 9:
                                            a_hex = s[1:3]
                                            r = s[3:5]; g = s[5:7]; b = s[7:9]
                                            try:
                                                a = int(a_hex, 16)
                                                opacity = round(a / 255.0, 6)
                                            except Exception:
                                                opacity = 1.0
                                            return (f"#{r}{g}{b}", opacity)
                                        # #RRGGBB
                                        if len(s) == 7:
                                            return (s, 1.0)
                                        # short forms like #RGB or others: attempt QColor fallback
                                    # fallback: try to parse rgba(...) strings
                                    if s.startswith('rgba') or s.startswith('rgb'):
                                        # simple parse: rgba(r,g,b,a)
                                        nums = s[s.find('(')+1:s.find(')')].split(',')
                                        if len(nums) >= 3:
                                            try:
                                                r = int(float(nums[0])); g = int(float(nums[1])); b = int(float(nums[2]))
                                                if len(nums) == 4:
                                                    a = float(nums[3]); opacity = float(a)
                                                else:
                                                    opacity = 1.0
                                                return (f"#{r:02x}{g:02x}{b:02x}", opacity)
                                            except Exception:
                                                return (None, None)
                                    return (None, None)
                                except Exception:
                                    return (None, None)

                            # Try to extract simple color info from the QGIS layer's symbol
                            try:
                                from qgis.PyQt.QtGui import QColor
                                renderer = layer.renderer() if layer is not None else None
                                symbol = None
                                layer_color_hex = None
                                layer_color_opacity = None
                                layer_stroke_hex = None
                                layer_stroke_opacity = None
                                if renderer:
                                    # attempt several common renderer access patterns
                                    try:
                                        rtype = renderer.type() if hasattr(renderer, 'type') else ''
                                    except Exception:
                                        rtype = ''
                                    try:
                                        if rtype == 'categorizedSymbol' and hasattr(renderer, 'categories'):
                                            cats = renderer.categories()
                                            if cats and hasattr(cats[0], 'symbol'):
                                                symbol = cats[0].symbol()
                                        elif rtype == 'ruleRenderer' and hasattr(renderer, 'rootRule'):
                                            root = renderer.rootRule()
                                            rules = root.children() if root and hasattr(root, 'children') else []
                                            if rules and hasattr(rules[0], 'symbol'):
                                                symbol = rules[0].symbol()
                                        elif rtype == 'graduatedSymbol' and hasattr(renderer, 'ranges'):
                                            ranges = renderer.ranges()
                                            if ranges and hasattr(ranges[0], 'symbol'):
                                                symbol = ranges[0].symbol()
                                        elif hasattr(renderer, 'symbols') and callable(renderer.symbols):
                                            syms = renderer.symbols()
                                            if syms:
                                                symbol = syms[0]
                                        elif hasattr(renderer, 'symbol') and callable(renderer.symbol):
                                            symbol = renderer.symbol()
                                    except Exception:
                                        symbol = None

                                if symbol:
                                    try:
                                        # prefer explicit fill/stroke where available
                                        if hasattr(symbol, 'symbolLayer') and callable(symbol.symbolLayer):
                                            sl = symbol.symbolLayer(0)
                                            if sl is not None:
                                                if hasattr(sl, 'fillColor') and callable(sl.fillColor):
                                                    fc = sl.fillColor()
                                                    raw = fc.name(QColor.HexArgb) if hasattr(fc, 'name') else str(fc)
                                                    h, o = _normalize_hex_and_opacity(raw)
                                                    layer_color_hex, layer_color_opacity = h, o
                                                if hasattr(sl, 'strokeColor') and callable(sl.strokeColor):
                                                    sc = sl.strokeColor()
                                                    raw2 = sc.name(QColor.HexArgb) if hasattr(sc, 'name') else str(sc)
                                                    h2, o2 = _normalize_hex_and_opacity(raw2)
                                                    layer_stroke_hex, layer_stroke_opacity = h2, o2
                                        if (not layer_color_hex) and hasattr(symbol, 'color') and callable(symbol.color):
                                            c = symbol.color()
                                            raw = c.name(QColor.HexArgb) if hasattr(c, 'name') else str(c)
                                            h, o = _normalize_hex_and_opacity(raw)
                                            layer_color_hex, layer_color_opacity = h, o
                                        if (not layer_stroke_hex) and hasattr(symbol, 'color') and callable(symbol.color):
                                            c2 = symbol.color()
                                            raw2 = c2.name(QColor.HexArgb) if hasattr(c2, 'name') else str(c2)
                                            h2, o2 = _normalize_hex_and_opacity(raw2)
                                            layer_stroke_hex, layer_stroke_opacity = h2, o2
                                    except Exception:
                                        layer_color_hex = None
                                        layer_color_opacity = None
                                        layer_stroke_hex = None
                                        layer_stroke_opacity = None
                            except Exception:
                                layer_color_hex = None
                                layer_color_opacity = None
                                layer_stroke_hex = None
                                layer_stroke_opacity = None

                            # Apply extracted colors to Mapbox layers conservatively
                            try:
                                for ml in mapbox_layers:
                                    try:
                                        if not isinstance(ml, dict):
                                            continue
                                        p = ml.get('paint') or {}
                                        mtype = ml.get('type')
                                        # fill
                                        if mtype == 'fill':
                                            if 'fill-color' not in p and layer_color_hex:
                                                p['fill-color'] = layer_color_hex
                                            # Use fill-opacity if alpha present and not already specified
                                            if layer_color_opacity is not None and layer_color_opacity < 1.0 and 'fill-opacity' not in p:
                                                p['fill-opacity'] = layer_color_opacity
                                            if 'fill-outline-color' not in p and layer_stroke_hex:
                                                p['fill-outline-color'] = layer_stroke_hex
                                        elif mtype == 'line':
                                            if 'line-color' not in p and (layer_stroke_hex or layer_color_hex):
                                                p['line-color'] = layer_stroke_hex or layer_color_hex
                                            if (layer_stroke_opacity is not None and layer_stroke_opacity < 1.0) and 'line-opacity' not in p:
                                                p['line-opacity'] = layer_stroke_opacity if layer_stroke_opacity is not None else (layer_color_opacity or 1.0)
                                        elif mtype in ('circle', 'symbol'):
                                            if 'circle-color' not in p and layer_color_hex:
                                                p['circle-color'] = layer_color_hex
                                            if layer_color_opacity is not None and layer_color_opacity < 1.0 and 'circle-opacity' not in p:
                                                p['circle-opacity'] = layer_color_opacity
                                        # write back paint only if modified
                                        if p:
                                            ml['paint'] = p
                                    except Exception:
                                        continue
                            except Exception:
                                pass
                            if is_line_based:
                                filtered = []
                                from qgis.core import QgsMessageLog, Qgis
                                for ml in mapbox_layers:
                                    try:
                                        if not isinstance(ml, dict):
                                            filtered.append(ml)
                                            continue
                                        if ml.get('type') == 'fill':
                                            # skip this layer
                                            continue
                                        filtered.append(ml)
                                    except Exception:
                                        # keep problematic entries to avoid data loss
                                        filtered.append(ml)
                                mapbox_layers = filtered
                        except Exception:
                            # non-fatal: if filtering fails, leave layers as-is
                            pass

                        # Merge line -> fill for polygonal sources when safe:
                        # If a source has both a fill layer and a simple line layer
                        # (only color/width, no dasharray/pattern/complex expressions),
                        # prefer a single fill layer with 'fill-outline-color' set
                        # and remove the separate line layer to avoid visual duplication.
                        try:
                            if not is_line_based:
                                from qgis.core import QgsMessageLog, Qgis
                                # group layers by source
                                by_source = {}
                                for ml in mapbox_layers:
                                    try:
                                        if not isinstance(ml, dict):
                                            continue
                                        src = ml.get('source')
                                        by_source.setdefault(src, []).append(ml)
                                    except Exception:
                                        continue

                                new_layers = []
                                for src, layers_list in by_source.items():
                                    # collect fills and lines for this source
                                    fills = [l for l in layers_list if l.get('type') == 'fill']
                                    lines = [l for l in layers_list if l.get('type') == 'line']

                                    # If we have fill+line pairs, attempt to merge
                                    if fills and lines:
                                        # For each fill, try to find a matching simple line
                                        for fill in fills:
                                            matched_line = None
                                            for line in lines:
                                                try:
                                                    # require identical filters (both None or equal)
                                                    if (fill.get('filter') or None) != (line.get('filter') or None):
                                                        continue
                                                    # inspect line paint for complexity
                                                    lp = line.get('paint') or {}
                                                    complex_keys = [k for k in lp.keys() if not k in ('line-color', 'line-width', 'line-opacity')]
                                                    if complex_keys:
                                                        # too complex to safely merge
                                                        continue
                                                    # ensure color is a simple string
                                                    lc = lp.get('line-color')
                                                    if isinstance(lc, str) and lc:
                                                        matched_line = line
                                                        break
                                                except Exception:
                                                    continue

                                            if matched_line:
                                                try:
                                                    fp = fill.get('paint') or {}
                                                    # set outline color from line color
                                                    fp['fill-outline-color'] = (matched_line.get('paint') or {}).get('line-color')
                                                    # preserve fill paint
                                                    fill['paint'] = fp
                                                    # mark matched_line for removal
                                                    try:
                                                        layers_list.remove(matched_line)
                                                    except Exception:
                                                        pass
                                                except Exception:
                                                    pass

                                    # append remaining layers for this source in original order
                                    # preserve original ordering by iterating original mapbox_layers
                                    for ml in mapbox_layers:
                                        try:
                                            if ml.get('source') == src and ml in layers_list:
                                                new_layers.append(ml)
                                        except Exception:
                                            continue

                                # replace mapbox_layers while preserving global order of sources
                                mapbox_layers = new_layers
                        except Exception:
                            # non-fatal: leave layers unchanged
                            pass

                        # Build style dict
                        # Use complete URL for tile template (MapLibre requires absolute URLs)
                        tile_template = f'http://localhost:{self.server_port}/wmts/{{z}}/{{x}}/{{y}}.png'
                        
                        # Ensure all mapbox_layers have explicit visibility set to 'visible'
                        # so that client-side controls can toggle them properly
                        try:
                            for ml in mapbox_layers:
                                if isinstance(ml, dict):
                                    if 'layout' not in ml:
                                        ml['layout'] = {}
                                    if 'visibility' not in ml.get('layout', {}):
                                        ml['layout']['visibility'] = 'visible'
                        except Exception:
                            pass
                        
                        style_dict = {
                            'version': 8,
                            # use canonical QGIS layer id for the style name (must match typename)
                            'name': str(raw_id) if layer is not None else str(wfs_typename),
                            'glyphs': 'https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf',
                            'sources': {
                                'qmap': {
                                    'type': 'raster',
                                    'tiles': [tile_template],
                                    'tileSize': 256,
                                    'attribution': 'QMapPermalink WMTS'
                                },
                                _wfs_source_id: {
                                    'type': 'geojson',
                                    'data': f"http://localhost:{self.server_port}/wfs?SERVICE=WFS&REQUEST=GetFeature&TYPENAMES={urllib.parse.quote(str(raw_id))}&OUTPUTFORMAT=application/json&MAXFEATURES=1000"
                                }
                            },
                            'layers': [
                                {'id': 'qmap', 'type': 'raster', 'source': 'qmap', 'minzoom': 0, 'layout': {'visibility': 'visible'}}
                            ] + mapbox_layers
                        }
                        payload = json.dumps(style_dict, ensure_ascii=False, indent=2)
                        from . import http_server
                        http_server.send_http_response(conn, 200, 'OK', payload, 'application/json; charset=utf-8')
                        return
                except Exception as e:
                    from . import http_server
                    http_server.send_http_response(conn, 500, 'Internal Server Error', f'Error in maplibre-style handler: {e}', 'text/plain; charset=utf-8')
                    return

            # MapLibre パーマリンクエンドポイントの処理（HTMLページ生成）
            if parsed_url.path == '/maplibre':
                try:
                    # Accept either explicit lat/lon/zoom or a permalink string
                    lat = params.get('lat', [None])[0]
                    lon = params.get('lon', [None])[0]
                    zoom = params.get('zoom', [None])[0]
                    permalink = params.get('permalink', [None])[0]

                    html_content = None

                    # Prefer QGIS-aware generator when running inside QGIS
                    try:
                        # Attempt to use the plugin's qmap_maplibre which uses
                        # QGIS transformation APIs to handle arbitrary CRSs.
                        from . import qmap_maplibre as qmap_maplibre
                        import webbrowser
                        import os

                        # /maplibre-style is handled at top-level routing to avoid nested path checks
                        # Prevent qmap_maplibre.open_maplibre_from_permalink from
                        # actually opening the browser: monkey-patch webbrowser.open.
                        _orig_web_open = webbrowser.open
                        try:
                            webbrowser.open = lambda *a, **k: None
                            # call generator which writes a temp HTML file and
                            # returns its path
                            temp_path = None
                            # Determine optional WFS typename from outer params (prefer explicit param)
                            wfs_typename = None
                            try:
                                for k in ('typename', 'typenames', 'TYPENAME', 'TYPENAMES', 'layer', 'layers', 'type', 'typeName'):
                                    if k in params and params.get(k):
                                        wfs_typename = params.get(k)[0]
                                        break
                            except Exception:
                                wfs_typename = None

                            # If typename not provided by request, try to auto-select
                            # from the project's /wfs-layers list (prefer layers with
                            # a finite bbox). This uses the same project-configured
                            # WFSLayers as the /wfs-layers endpoint.
                            if not wfs_typename:
                                try:
                                    layers_list = self._collect_wfs_layers()
                                    if layers_list:
                                        import math
                                        chosen = None
                                        for L in layers_list:
                                            bbox = L.get('bbox', {}) or {}
                                            try:
                                                minx = float(bbox.get('minx'))
                                                if math.isfinite(minx):
                                                    chosen = L
                                                    break
                                            except Exception:
                                                continue
                                        if not chosen:
                                            chosen = layers_list[0]
                                        # Use the canonical typename (QGIS layer.id()) when
                                        # auto-selecting a layer. The /wfs-layers entries
                                        # expose both 'name' (UI-normalized) and 'typename'
                                        # (canonical). Prefer 'typename' to avoid generating
                                        # permalinks that reference human-friendly names.
                                        wfs_typename = chosen.get('typename') or chosen.get('id') or chosen.get('name')
                                        try:
                                            from qgis.core import QgsMessageLog, Qgis
                                        except Exception:
                                            pass
                                except Exception:
                                    # ignore and leave wfs_typename as None
                                    pass

                            # Try calling generator with provided permalink (if any) and pass typename
                            try:
                                if permalink:
                                    temp_path = qmap_maplibre.open_maplibre_from_permalink(permalink, wfs_typename)
                                else:
                                    # build a synthetic permalink if lat/lon provided
                                    if lat is not None and lon is not None:
                                        p = f"http://localhost/?lat={lat}&lon={lon}"
                                        if zoom is not None:
                                            p += f"&zoom={zoom}"
                                        temp_path = qmap_maplibre.open_maplibre_from_permalink(p, wfs_typename)
                                    else:
                                        # Fallback: attempt to generate with empty permalink but pass typename
                                        temp_path = qmap_maplibre.open_maplibre_from_permalink('', wfs_typename)
                            except Exception as e:
                                # If generator failed (e.g. couldn't parse permalink), attempt a safe fallback
                                try:
                                    QgsMessageLog.logMessage(f"⚠️ MapLibre generator failed: {e} - retrying with empty permalink", "QMapPermalink", Qgis.Warning)
                                except Exception:
                                    pass
                                try:
                                    temp_path = qmap_maplibre.open_maplibre_from_permalink('', None)
                                except Exception:
                                    # re-raise original to be handled by outer exception handler
                                    raise

                            # Read the generated HTML file and send it
                            if temp_path and os.path.exists(temp_path):
                                with open(temp_path, 'r', encoding='utf-8') as f:
                                    html_content = f.read()
                        finally:
                            # restore original webbrowser.open regardless of outcome
                            try:
                                webbrowser.open = _orig_web_open
                            except Exception:
                                pass
                    except Exception:
                        # Any failure here falls back to lightweight generator
                        html_content = None

                    if not html_content:
                        # We assume PyQGIS is available in this simplified unified
                        # setup. If the QGIS-aware generator failed for any
                        # reason, return an error page rather than falling back
                        # to the standalone/lightweight generator which we are
                        # removing to keep the codebase PyQGIS-centric.
                        from . import http_server
                        error_html = self._generate_error_html_page(
                            "MapLibre HTML generation failed (QGIS-dependent generator failed)."
                        )
                        http_server.send_http_response(conn, 500, "Internal Server Error", error_html, "text/html; charset=utf-8")
                        return

                    from . import http_server
                    http_server.send_http_response(conn, 200, "OK", html_content, "text/html; charset=utf-8")
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ MapLibre HTML page error: {e}", "QMapPermalink", Qgis.Critical)
                    import traceback
                    QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, "Internal Server Error", f"MapLibre HTML page generation failed: {str(e)}")
                return
            
            # WMTS endpoint: delegate to qmap_wmts_service for GetCapabilities and tiles
            if parsed_url.path.startswith('/wmts'):
                try:
                    # lazily create service if missing
                    if not hasattr(self, 'wmts_service') or self.wmts_service is None:
                        try:
                            from .qmap_wmts_service import QMapPermalinkWMTSService
                            self.wmts_service = QMapPermalinkWMTSService(self)
                        except Exception:
                            self.wmts_service = None

                    if self.wmts_service:
                        self.wmts_service.handle_wmts_request(conn, parsed_url, params, host)
                    else:
                        from . import http_server
                        http_server.send_http_response(conn, 501, 'Not Implemented', 'WMTS service not available')
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ WMTS delegation error: {e}", "QMapPermalink", Qgis.Critical)
                    import traceback
                    QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, "Internal Server Error", f"WMTS processing failed: {str(e)}")
                return

            # Lightweight JSON endpoint to list publishable WFS vector layers
            if parsed_url.path == '/wfs-layers':
                try:
                    self._handle_wfs_layers(conn, params)
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ wfs-layers handler error: {e}", "QMapPermalink", Qgis.Critical)
                    import traceback
                    QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, "Internal Server Error", f"wfs-layers failed: {str(e)}")
                return
            
            # WFS endpoint: delegate to qmap_wfs_service for GetCapabilities, GetFeature, DescribeFeatureType, and GetStyles
            if parsed_url.path.startswith('/wfs') or ('SERVICE' in params and params.get('SERVICE', [''])[0].upper() == 'WFS'):
                try:
                    # lazily create service if missing
                    if not hasattr(self, 'wfs_service') or self.wfs_service is None:
                        try:
                            from .qmap_wfs_service import QMapPermalinkWFSService
                            self.wfs_service = QMapPermalinkWFSService(self.iface, self.server_port)
                        except Exception:
                            self.wfs_service = None

                    if self.wfs_service:
                        # QMapPermalinkWFSService.handle_wfs_request expects (conn, params, host)
                        # (not parsed_url). Pass parameters accordingly.
                        try:
                            self.wfs_service.handle_wfs_request(conn, params, host)
                        except TypeError:
                            # Defensive fallback for older/alternate signatures that accept parsed_url
                            try:
                                self.wfs_service.handle_wfs_request(conn, parsed_url, params, host)
                            except Exception:
                                raise
                    else:
                        from . import http_server
                        http_server.send_http_response(conn, 501, 'Not Implemented', 'WFS service not available')
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ WFS delegation error: {e}", "QMapPermalink", Qgis.Critical)
                    import traceback
                    QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, "Internal Server Error", f"WFS processing failed: {str(e)}")
                return
            if parsed_url.path == '/debug-bookmarks':
                try:
                    if hasattr(self, '_handle_debug_bookmarks') and callable(getattr(self, '_handle_debug_bookmarks')):
                        self._handle_debug_bookmarks(conn)
                    else:
                        # Handler not implemented in this instance
                        from . import http_server
                        http_server.send_http_response(conn, 501, 'Not Implemented', 'debug-bookmarks handler not available')
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ debug-bookmarks handler error: {e}", "QMapPermalink", Qgis.Critical)
                    import traceback
                    QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, "Internal Server Error", f"debug-bookmarks failed: {str(e)}")
                return
            
            # --- 静的ファイル配信: favicon.ico, style.json, data.geojson など ---
            import os
            # Support a few well-known static assets. Also allow serving small
            # companion scripts stored under maplibre/scripts (qmap_postload.js,
            # wmts_layers.js) by searching that directory as a fallback.
            static_files = ["/favicon.ico", "/style.json", "/data.geojson", "/qmap_postload.js", "/wmts_layers.js"]
            if parsed_url.path in static_files:
                # プラグインディレクトリからファイルを探す
                plugin_dir = os.path.dirname(os.path.abspath(__file__))
                fname = parsed_url.path.lstrip("/")

                # Candidate locations: plugin root, then maplibre/scripts
                candidates = [os.path.join(plugin_dir, fname), os.path.join(plugin_dir, 'maplibre', 'scripts', fname)]
                found = None
                for fpath in candidates:
                    try:
                        if os.path.exists(fpath):
                            found = fpath
                            break
                    except Exception:
                        continue

                if found:
                    # Content-Type判定
                    if fname.endswith(".ico"):
                        content_type = "image/x-icon"
                    elif fname.endswith(".json"):
                        content_type = "application/json; charset=utf-8"
                    elif fname.endswith(".geojson"):
                        content_type = "application/geo+json; charset=utf-8"
                    elif fname.endswith(".js"):
                        content_type = "application/javascript; charset=utf-8"
                    else:
                        content_type = "application/octet-stream"
                    with open(found, "rb") as f:
                        data = f.read()
                    http_server.send_binary_response(conn, 200, "OK", data, content_type)
                    return
                else:
                    http_server.send_http_response(conn, 404, "Not Found", f"File not found: {fname}", "text/plain; charset=utf-8")
                    return

            # 未対応のエンドポイントは404エラー
            QgsMessageLog.logMessage(f"❌ Unknown endpoint: {parsed_url.path}", "QMapPermalink", Qgis.Warning)
            from . import http_server
            # 明示的に利用可能なエンドポイント一覧に /wmts と /wfs を含める
            http_server.send_http_response(
                conn,
                404,
                "Not Found",
                "Available endpoints: /wms (PNG image), /qgis-map (OpenLayers HTML), /maplibre (MapLibre HTML), /wmts (WMTS tiles), /wfs (WFS service)"
            )
            return
    def _build_navigation_data_from_params(self, params):
        """クエリパラメータからナビゲーション用辞書を構築する

        params: urllib.parse.parse_qs の戻り値（辞書: key -> [values]）

        戻り値の形式:
            {'type': 'coordinates', 'x': float, 'y': float, 'scale': float, 'crs': str, ...}
            または
            {'type': 'location', 'location': '<encoded json string>'}
        """
        # location ベースのパラメータがあれば優先
        if 'location' in params:
            # location はエンコード済みJSON文字列を想定
            loc_val = params.get('location', [''])[0]
            if not loc_val:
                raise ValueError('location パラメータが空です')
            return {'type': 'location', 'location': loc_val}

        # 個別座標パラメータをチェック
        if 'x' in params and 'y' in params and ('scale' in params or 'zoom' in params or 'crs' in params):
            try:
                x = float(params.get('x', [None])[0])
                y = float(params.get('y', [None])[0])
            except Exception:
                raise ValueError('x/y パラメータが数値ではありません')

            scale = None
            if 'scale' in params:
                try:
                    scale = float(params.get('scale', [None])[0])
                except Exception:
                    scale = None

            zoom = None
            if 'zoom' in params:
                try:
                    zoom = float(params.get('zoom', [None])[0])
                except Exception:
                    zoom = None

            crs = params.get('crs', [None])[0]
            rotation = None
            if 'rotation' in params:
                try:
                    rotation = float(params.get('rotation', [None])[0])
                except Exception:
                    rotation = None

            theme_info = None
            if 'theme' in params:
                theme_info = params.get('theme', [None])[0]

            return {
                'type': 'coordinates',
                'x': x,
                'y': y,
                'scale': scale,
                'zoom': zoom,
                'crs': crs,
                'rotation': rotation,
                'theme_info': theme_info,
            }

        # 条件に合致しない場合はエラー
        raise ValueError('ナビゲーションパラメータが見つかりません')

    def _get_canvas_extent_info(self):
        """キャンバスから現在の範囲情報を取得してWMS XMLに埋め込む"""
        try:
            canvas = self.iface.mapCanvas()
            if not canvas:
                return "<EX_GeographicBoundingBox><westBoundLongitude>-180</westBoundLongitude><eastBoundLongitude>180</eastBoundLongitude><southBoundLatitude>-90</southBoundLatitude><northBoundLatitude>90</northBoundLatitude></EX_GeographicBoundingBox>"
            
            # 現在の表示範囲を取得
            extent = canvas.extent()
            crs = canvas.mapSettings().destinationCrs()
            
            # WGS84に変換
            from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject
            wgs84_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            
            if crs.authid() != "EPSG:4326":
                transform = QgsCoordinateTransform(crs, wgs84_crs, QgsProject.instance())
                try:
                    extent = transform.transformBoundingBox(extent)
                except Exception:
                    pass  # 変換失敗時はそのまま使用
            
            # XML形式で範囲情報を生成
            extent_xml = f"""<EX_GeographicBoundingBox>
        <westBoundLongitude>{extent.xMinimum():.6f}</westBoundLongitude>
        <eastBoundLongitude>{extent.xMaximum():.6f}</eastBoundLongitude>
        <southBoundLatitude>{extent.yMinimum():.6f}</southBoundLatitude>
        <northBoundLatitude>{extent.yMaximum():.6f}</northBoundLatitude>
      </EX_GeographicBoundingBox>
      <BoundingBox CRS="{crs.authid()}" minx="{extent.xMinimum():.6f}" miny="{extent.yMinimum():.6f}" maxx="{extent.xMaximum():.6f}" maxy="{extent.yMaximum():.6f}"/>"""
            
            return extent_xml
            
        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"⚠️ Error getting canvas extent info: {e}", "QMapPermalink", Qgis.Warning)
            return "<EX_GeographicBoundingBox><westBoundLongitude>-180</westBoundLongitude><eastBoundLongitude>180</eastBoundLongitude><southBoundLatitude>-90</southBoundLatitude><northBoundLatitude>90</northBoundLatitude></EX_GeographicBoundingBox>"




            height = self._safe_int(params.get('HEIGHT', ['256'])[0], 256)
            bbox = params.get('BBOX', [''])[0]
            # WMS version and CRS/SRS handling: accept both CRS (1.3.0) and SRS (1.1.1)
            wms_version = params.get('VERSION', params.get('version', ['1.3.0']))[0]
            # Prefer CRS (WMS 1.3.0) but fall back to SRS if provided
            original_crs = None
            if 'CRS' in params and params.get('CRS'):
                original_crs = params.get('CRS', [''])[0]
            elif 'SRS' in params and params.get('SRS'):
                original_crs = params.get('SRS', [''])[0]
            if not original_crs:
                original_crs = 'EPSG:3857'

            # If WMS 1.3.0 and CRS is EPSG:4326, axis order in BBOX is lat,lon (y,x)
            # so we need to swap coordinates when parsing. For other CRSs assume BBOX
            # is minx,miny,maxx,maxy.
            try:
                bbox_coords = [float(v) for v in bbox.split(',')] if bbox else []
                if bbox_coords and wms_version and str(wms_version).startswith('1.3') and original_crs and original_crs.upper().endswith('4326') and len(bbox_coords) == 4:
                    # incoming BBOX: miny,minx,maxy,maxx -> reorder to minx,miny,maxx,maxy
                    bbox = f"{bbox_coords[1]},{bbox_coords[0]},{bbox_coords[3]},{bbox_coords[2]}"
                else:
                    # keep as-is
                    bbox = ','.join(str(v) for v in bbox_coords) if bbox_coords else ''
            except Exception:
                # if parsing fails, keep original string
                pass
            # オプションで任意CRSを強制的にEPSG:3857として扱う
            if getattr(self, 'force_epsg3857', False):
                crs = 'EPSG:3857'
            else:
                crs = original_crs
            
            # リクエストで与えられたBBOXがある場合、必要なら元々のCRSからEPSG:3857に変換する
            # BBOXを変換するのは force_epsg3857 が無効な場合のみ
            if not getattr(self, 'force_epsg3857', False):
                try:
                    if bbox and original_crs and original_crs.upper() != 'EPSG:3857':
                        from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsRectangle
                        src_crs = QgsCoordinateReferenceSystem(original_crs)
                        tgt_crs = QgsCoordinateReferenceSystem('EPSG:3857')
                        if src_crs.isValid():
                            try:
                                coords = [float(x) for x in bbox.split(',')]
                                if len(coords) == 4:
                                            rect = QgsRectangle(coords[0], coords[1], coords[2], coords[3])
                                            transform = QgsCoordinateTransform(src_crs, tgt_crs, QgsProject.instance())
                                            rect = transform.transformBoundingBox(rect)
                                            bbox = f"{rect.xMinimum()},{rect.yMinimum()},{rect.xMaximum()},{rect.yMaximum()}"
                                            # Ensure the CRS variable matches the transformed BBOX coordinates
                                            crs = 'EPSG:3857'
                            except Exception as e:
                                QgsMessageLog.logMessage(f"⚠️ Failed to transform BBOX to EPSG:3857: {e}", "QMapPermalink", Qgis.Warning)
                        else:
                            QgsMessageLog.logMessage(f"⚠️ Invalid source CRS '{original_crs}' - forcing to EPSG:3857", "QMapPermalink", Qgis.Warning)
                except Exception:
                    # non-fatal: continue with original crs/bbox
                    pass
            # Use the QGIS canvas-based rendering as the authoritative renderer.
            # This ensures we rely on QGIS official rendering (layer symbology, styles
            # and labeling) rather than any independent/custom renderer which may
            # produce different visuals.
            png_data = self._generate_qgis_map_png(width, height, bbox, crs)
            if png_data and len(png_data) > 1000:
                from . import http_server
                http_server.send_binary_response(conn, 200, "OK", png_data, "image/png")
                return
            else:
                QgsMessageLog.logMessage("❌ Canvas rendering failed", "QMapPermalink", Qgis.Warning)
                # フォールバック: エラー画像を生成
                error_image = self._generate_error_image(width, height, "QGIS Map Generation Failed")
                from . import http_server
                http_server.send_binary_response(conn, 200, "OK", error_image, "image/png")
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ WMS GetMap error: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            
            # エラー時は最小限のテスト画像を返す
            test_image = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x01\x00\x00\x00\x01\x00\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\tpHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\x16tEXtSoftware\x00www.inkscape.org\x9b\xee<\x1a\x00\x00\x00\x1ftEXtTitle\x00Test Image\x87\x96\xf0\x8e\x00\x00\x00\x12IDATx\x9cc\xf8\x0f\x00\x00\x01\x00\x01\x00\x18\xdd\x8d\xb4\x00\x00\x00\x00IEND\xaeB`\x82'
            self._send_binary_response(conn, 200, "OK", test_image, "image/png")

    def _handle_permalink_as_wms_getmap(self, conn, params):
        """パーマリンクパラメータをWMS GetMapリクエストとして処理"""
        from qgis.core import QgsMessageLog, Qgis
        
        try:
            
            # パーマリンクパラメータを取得
            x = float(params.get('x', ['0'])[0])
            y = float(params.get('y', ['0'])[0])
            scale = float(params.get('scale', ['10000'])[0])
            crs = params.get('crs', ['EPSG:3857'])[0]
            # パーマリンクでも内部処理はEPSG:3857を使用する（元CRSを保持）
            original_permalink_crs = crs
            crs = 'EPSG:3857'
            rotation = float(params.get('rotation', ['0'])[0])
            
            # デフォルトの画像サイズ（パラメータで指定可能）
            width = self._safe_int(params.get('width', ['512'])[0], 512)
            height = self._safe_int(params.get('height', ['512'])[0], 512)
            
            
            # スケールから表示範囲（BBOX）を計算（計算は元CRSで行う）
            bbox = self._calculate_bbox_from_permalink(x, y, scale, width, height, original_permalink_crs)
            
            if bbox:
                # If permalink requested CRS is not EPSG:3857, transform computed
                # BBOX into EPSG:3857 and render in EPSG:3857.
                try:
                    # If computed bbox is in a CRS different from EPSG:3857, transform to 3857
                    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsRectangle
                    src_crs = QgsCoordinateReferenceSystem(original_permalink_crs)
                    tgt_crs = QgsCoordinateReferenceSystem('EPSG:3857')
                    if src_crs.isValid():
                        coords = [float(x) for x in bbox.split(',')]
                        if len(coords) == 4:
                            rect = QgsRectangle(coords[0], coords[1], coords[2], coords[3])
                            transform = QgsCoordinateTransform(src_crs, tgt_crs, QgsProject.instance())
                            rect = transform.transformBoundingBox(rect)
                            bbox = f"{rect.xMinimum()},{rect.yMinimum()},{rect.xMaximum()},{rect.yMaximum()}"
                    else:
                        QgsMessageLog.logMessage(f"⚠️ Invalid permalink CRS '{original_permalink_crs}' - forcing to EPSG:3857", "QMapPermalink", Qgis.Warning)
                        # leave bbox as-is; downstream code will force EPSG:3857 as needed
                except Exception as ex:
                    QgsMessageLog.logMessage(f"⚠️ Error transforming permalink BBOX: {ex}", "QMapPermalink", Qgis.Warning)

                # Use canvas-based rendering for permalink requests. Rotation, if
                # needed, should be handled by the canvas adjustment routines.
                png_data = self._generate_qgis_map_png(width, height, bbox, crs, rotation)
                if png_data and len(png_data) > 1000:
                    from . import http_server
                    http_server.send_binary_response(conn, 200, "OK", png_data, "image/png")
                    return
                else:
                    QgsMessageLog.logMessage("❌ Permalink canvas rendering failed", "QMapPermalink", Qgis.Warning)
                    error_image = self._generate_error_image(width, height, "Permalink Rendering Failed")
                    from . import http_server
                    http_server.send_binary_response(conn, 200, "OK", error_image, "image/png")
                    return
            else:
                QgsMessageLog.logMessage("❌ Failed to calculate BBOX from permalink parameters", "QMapPermalink", Qgis.Warning)
                error_image = self._generate_error_image(width, height, "Invalid Permalink Parameters")
                from . import http_server
                http_server.send_binary_response(conn, 200, "OK", error_image, "image/png")
                
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Permalink processing error: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            
            # エラー時はエラー画像を返す
            error_image = self._generate_error_image(512, 512, f"Permalink Error: {str(e)}")
            self._send_binary_response(conn, 200, "OK", error_image, "image/png")

    def _handle_permalink_html_page(self, conn, params):
        """パーマリンクパラメータに基づいてWMSエンドポイントを使用するHTMLページを生成"""
        from qgis.core import QgsMessageLog, Qgis
        
        try:
            
            # パーマリンクパラメータを取得
            x = params.get('x', [None])[0]
            y = params.get('y', [None])[0]
            scale = params.get('scale', [None])[0]
            crs = params.get('crs', ['EPSG:3857'])[0]
            rotation = params.get('rotation', ['0.0'])[0]
            width = params.get('width', ['800'])[0]
            height = params.get('height', ['600'])[0]
            
            
            # Convert incoming center coordinates to EPSG:3857 unconditionally
            try:
                from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsPointXY
                if x is None or y is None:
                    raise ValueError('x/y パラメータがありません')
                src = QgsCoordinateReferenceSystem(str(crs))
                tgt = QgsCoordinateReferenceSystem('EPSG:3857')
                fx = float(x); fy = float(y)
                if src.isValid() and src.authid() != 'EPSG:3857':
                    transform = QgsCoordinateTransform(src, tgt, QgsProject.instance())
                    pt = transform.transform(QgsPointXY(fx, fy))
                    x3857 = str(pt.x()); y3857 = str(pt.y())
                else:
                    x3857 = str(fx); y3857 = str(fy)
            except Exception as ex:
                # If transformation fails, fall back to treating the values as already EPSG:3857
                x3857 = str(x if x is not None else 0)
                y3857 = str(y if y is not None else 0)

            # Generate HTML page using converted EPSG:3857 center coordinates
            html_content = self._generate_wms_based_html_page(x3857, y3857, scale, 'EPSG:3857', rotation, width, height)
            # HTMLレスポンスを送信
            from . import http_server
            http_server.send_http_response(conn, 200, "OK", html_content, "text/html; charset=utf-8")
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Permalink HTML page generation error: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            
            # エラー時はエラーページを返す
            error_html = self._generate_error_html_page(f"Error generating permalink page: {str(e)}")
            from . import http_server
            http_server.send_http_response(conn, 500, "Internal Server Error", error_html, "text/html; charset=utf-8")

    def _handle_debug_bookmarks(self, conn):
        """Return a JSON list of collected bookmarks (for debugging)."""
        from qgis.core import QgsProject
        try:
            bookmarks_list = []
            mgr = None
            try:
                mgr = QgsProject.instance().bookmarkManager()
            except Exception:
                try:
                    mgr = QgsProject.instance().bookmarks()
                except Exception:
                    mgr = None

            raw = None
            if mgr is not None:
                try:
                    raw = mgr.bookmarks()
                except Exception:
                    try:
                        raw = mgr.getBookmarks()
                    except Exception:
                        raw = None

            if raw:
                for b in raw:
                    name = ''
                    try:
                        if hasattr(b, 'name'):
                            name = b.name()
                        else:
                            name = str(getattr(b, 'displayName', '') or '')
                    except Exception:
                        try:
                            if isinstance(b, dict) and 'name' in b:
                                name = str(b.get('name'))
                        except Exception:
                            name = ''

                    bx = None; by = None
                    try:
                        if hasattr(b, 'point'):
                            p = b.point(); bx = p.x(); by = p.y()
                    except Exception:
                        bx = None; by = None

                    if (bx is None or by is None) and hasattr(b, 'center'):
                        try:
                            p = b.center(); bx = p.x(); by = p.y()
                        except Exception:
                            pass

                    if (bx is None or by is None) and hasattr(b, 'extent'):
                        try:
                            ext = b.extent(); bx = (ext.xMinimum() + ext.xMaximum()) / 2.0; by = (ext.yMinimum() + ext.yMaximum()) / 2.0
                        except Exception:
                            pass

                    if (bx is None or by is None) and isinstance(b, dict):
                        try:
                            if 'x' in b and 'y' in b:
                                bx = float(b.get('x')); by = float(b.get('y'))
                            elif 'lon' in b and 'lat' in b:
                                bx = float(b.get('lon')); by = float(b.get('lat'))
                        except Exception:
                            pass

                    if bx is None or by is None:
                        continue

                    # Attempt to determine source CRS id
                    src_crs_id = None
                    try:
                        if hasattr(b, 'crs'):
                            src_crs_id = b.crs()
                    except Exception:
                        src_crs_id = None

                    # Provide orig coords and placeholder for transformed values (transformation done elsewhere)
                    bookmarks_list.append({
                        'name': str(name),
                        'x': bx,
                        'y': by,
                        'src_crs': src_crs_id,
                        'orig_x': bx,
                        'orig_y': by
                    })

            import json
            payload = json.dumps({'bookmarks': bookmarks_list}, ensure_ascii=False)
            from . import http_server
            http_server.send_http_response(conn, 200, 'OK', payload, 'application/json; charset=utf-8')
        except Exception as e:
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(f'❌ debug-bookmarks error: {e}', 'QMapPermalink', Qgis.Warning)
            except Exception:
                pass
            from . import http_server
            http_server.send_http_response(conn, 500, 'Internal Server Error', f'{{"error": "{str(e)}"}}', 'application/json; charset=utf-8')

    def _handle_wfs_layers(self, conn, params=None):
        """Return a JSON list of vector layers that can be exposed via WFS.

        Each item contains: name (normalized for TYPENAME), title, crs, bbox (WGS84)
        Supports query param 'only-visible' (1/true/yes) to return only layers
        currently visible in the map canvas.
        """
        try:
            from qgis.core import QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem, QgsCoordinateTransform
            layers_list = []

            # parse only-visible param
            only_visible = False
            try:
                if params:
                    val = params.get('only-visible', params.get('only_visible', params.get('visible', [''])))[0]
                    if isinstance(val, str) and val.lower() in ('1', 'true', 'yes', 'on'):
                        only_visible = True
            except Exception:
                only_visible = False

            visible_ids = None
            if only_visible:
                try:
                    canvas = self.iface.mapCanvas()
                    if canvas:
                        layer_tree_root = QgsProject.instance().layerTreeRoot()
                        visible_ids = set()
                        for lay in canvas.layers():
                            try:
                                lnode = layer_tree_root.findLayer(lay.id())
                                if lnode and lnode.isVisible():
                                    visible_ids.add(lay.id())
                            except Exception:
                                continue
                except Exception:
                    visible_ids = None

            # Prefer project-level WFSLayers entry if present (QGIS project OWS/WFS export list)
            project = QgsProject.instance()
            try:
                wfs_ids, ok = project.readListEntry('WFSLayers', '/')
            except Exception:
                wfs_ids, ok = ([], False)

            # Determine which layer ids to iterate: require WFSLayers to be present
            if ok and wfs_ids:
                candidate_ids = [str(i) for i in wfs_ids]
            else:
                # No WFSLayers defined in project -> per request, do NOT fallback to all layers.
                import json
                payload = json.dumps({'layers': []}, ensure_ascii=False)
                from . import http_server
                http_server.send_http_response(conn, 200, 'OK', payload, 'application/json; charset=utf-8')
                return

            for lid in candidate_ids:
                try:
                    layer = QgsProject.instance().mapLayer(lid)
                    if not layer:
                        # skip missing / invalid entries
                        continue

                    if not isinstance(layer, QgsVectorLayer):
                        continue

                    if visible_ids is not None and layer.id() not in visible_ids:
                        continue

                    title = layer.name()
                    name_norm = title.replace(' ', '_')
                    crs = layer.crs().authid() if layer.crs().isValid() else 'EPSG:4326'

                    # attempt to get layer extent and convert to WGS84

                    def _sanitize_bbox_val(val):
                        import math
                        if val is None or not isinstance(val, (int, float)) or math.isnan(val) or math.isinf(val):
                            return None
                        return float(val)

                    try:
                        extent = layer.extent()
                        if layer.crs().authid() != 'EPSG:4326':
                            src = layer.crs()
                            tgt = QgsCoordinateReferenceSystem('EPSG:4326')
                            transform = QgsCoordinateTransform(src, tgt, QgsProject.instance())
                            extent = transform.transformBoundingBox(extent)
                        bbox = {
                            'minx': _sanitize_bbox_val(extent.xMinimum()),
                            'miny': _sanitize_bbox_val(extent.yMinimum()),
                            'maxx': _sanitize_bbox_val(extent.xMaximum()),
                            'maxy': _sanitize_bbox_val(extent.yMaximum())
                        }
                    except Exception:
                        bbox = {'minx': -180, 'miny': -90, 'maxx': 180, 'maxy': 90}

                    # レイヤの主色・線色を取得（単一シンボルのみ）
                    color = None
                    stroke_color = None
                    try:
                        renderer = layer.renderer()
                        if renderer and renderer.type() == 'singleSymbol':
                            symbol = renderer.symbol()
                            if symbol:
                                geom_type = layer.geometryType() if hasattr(layer, 'geometryType') else None
                                # 0: Point, 1: Line, 2: Polygon
                                if geom_type == 0:  # Point
                                    color = symbol.color().name(QColor.HexArgb) if hasattr(symbol.color(), 'name') else symbol.color().name()
                                elif geom_type == 1:  # Line
                                    color = symbol.color().name(QColor.HexArgb) if hasattr(symbol.color(), 'name') else symbol.color().name()
                                elif geom_type == 2:  # Polygon
                                    if hasattr(symbol, 'fillColor'):
                                        color = symbol.fillColor().name(QColor.HexArgb) if hasattr(symbol.fillColor(), 'name') else symbol.fillColor().name()
                                    if hasattr(symbol, 'strokeColor'):
                                        stroke_color = symbol.strokeColor().name(QColor.HexArgb) if hasattr(symbol.strokeColor(), 'name') else symbol.strokeColor().name()
                                    else:
                                        stroke_color = symbol.color().name(QColor.HexArgb) if hasattr(symbol.color(), 'name') else symbol.color().name()
                    except Exception:
                        color = None
                        stroke_color = None

                    try:
                        gt = layer.geometryType() if hasattr(layer, 'geometryType') else None
                        if gt == 0:
                            geom_type_name = 'Point'
                        elif gt == 1:
                            geom_type_name = 'LineString'
                        elif gt == 2:
                            geom_type_name = 'Polygon'
                        elif gt is None:
                            geom_type_name = 'Unknown'
                        else:
                            geom_type_name = str(gt)
                    except Exception:
                        geom_type_name = 'Unknown'

                    layer_entry = {
                        'id': layer.id(),
                        # canonical typename: use the QGIS layer.id() exactly
                        'typename': layer.id(),
                        'name': name_norm,
                        'title': title,
                        'crs': crs,
                        'bbox': bbox,
                        'geom_type': geom_type_name
                    }
                    if color:
                        layer_entry['color'] = color
                    if stroke_color:
                        layer_entry['stroke_color'] = stroke_color
                    layers_list.append(layer_entry)
                except Exception:
                    continue

            import json
            payload = json.dumps({'layers': layers_list}, ensure_ascii=False)
            from . import http_server
            http_server.send_http_response(conn, 200, 'OK', payload, 'application/json; charset=utf-8')
        except Exception as e:
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(f'❌ wfs-layers error: {e}', 'QMapPermalink', Qgis.Warning)
            except Exception:
                pass
            from . import http_server
            http_server.send_http_response(conn, 500, 'Internal Server Error', f'{{"error": "{str(e)}"}}', 'application/json; charset=utf-8')

    def _collect_wfs_layers(self, only_visible: bool = False):
        """内部用: プロジェクトの WFSLayers エントリから publishable なレイヤ情報リストを返す。

        戻り値: list of dict items with keys: name, title, crs, bbox
        """
        try:
            from qgis.core import QgsProject, QgsVectorLayer, QgsCoordinateReferenceSystem, QgsCoordinateTransform
            layers_list = []

            visible_ids = None
            if only_visible:
                try:
                    canvas = self.iface.mapCanvas()
                    if canvas:
                        layer_tree_root = QgsProject.instance().layerTreeRoot()
                        visible_ids = set()
                        for lay in canvas.layers():
                            try:
                                lnode = layer_tree_root.findLayer(lay.id())
                                if lnode and lnode.isVisible():
                                    visible_ids.add(lay.id())
                            except Exception:
                                continue
                except Exception:
                    visible_ids = None

            project = QgsProject.instance()
            try:
                wfs_ids, ok = project.readListEntry('WFSLayers', '/')
            except Exception:
                wfs_ids, ok = ([], False)

            if not (ok and wfs_ids):
                return []

            for lid in [str(i) for i in wfs_ids]:
                try:
                    layer = QgsProject.instance().mapLayer(lid)
                    if not layer:
                        continue
                    if not isinstance(layer, QgsVectorLayer):
                        continue
                    if visible_ids is not None and layer.id() not in visible_ids:
                        continue

                    title = layer.name()
                    name_norm = title.replace(' ', '_')
                    crs = layer.crs().authid() if layer.crs().isValid() else 'EPSG:4326'


                    def _sanitize_bbox_val(val):
                        import math
                        if val is None or not isinstance(val, (int, float)) or math.isnan(val) or math.isinf(val):
                            return None
                        return float(val)

                    try:
                        extent = layer.extent()
                        if layer.crs().authid() != 'EPSG:4326':
                            src = layer.crs()
                            tgt = QgsCoordinateReferenceSystem('EPSG:4326')
                            transform = QgsCoordinateTransform(src, tgt, QgsProject.instance())
                            extent = transform.transformBoundingBox(extent)
                        bbox = {
                            'minx': _sanitize_bbox_val(extent.xMinimum()),
                            'miny': _sanitize_bbox_val(extent.yMinimum()),
                            'maxx': _sanitize_bbox_val(extent.xMaximum()),
                            'maxy': _sanitize_bbox_val(extent.yMaximum())
                        }
                    except Exception:
                        bbox = {'minx': None, 'miny': None, 'maxx': None, 'maxy': None}


                    # レイヤの主色・線色を取得（QGISバージョン差異に配慮）
                    color = None
                    stroke_color = None
                    try:
                        from qgis.PyQt.QtGui import QColor
                        renderer = layer.renderer()
                        symbol = None
                        # categorizedSymbol/ruleBased/gradiented など複数シンボル系にも対応
                        if renderer:
                            rtype = renderer.type() if hasattr(renderer, 'type') else ''
                            if rtype == 'categorizedSymbol' and hasattr(renderer, 'categories'):
                                cats = renderer.categories()
                                if cats and hasattr(cats[0], 'symbol'):
                                    symbol = cats[0].symbol()
                            elif rtype == 'ruleRenderer' and hasattr(renderer, 'rootRule'):
                                root = renderer.rootRule()
                                rules = root.children() if root and hasattr(root, 'children') else []
                                if rules and hasattr(rules[0], 'symbol'):
                                    symbol = rules[0].symbol()
                            elif rtype == 'graduatedSymbol' and hasattr(renderer, 'ranges'):
                                ranges = renderer.ranges()
                                if ranges and hasattr(ranges[0], 'symbol'):
                                    symbol = ranges[0].symbol()
                            elif hasattr(renderer, 'symbols') and callable(renderer.symbols):
                                symbols = renderer.symbols()
                                if symbols:
                                    symbol = symbols[0]
                            elif hasattr(renderer, 'symbol') and callable(renderer.symbol):
                                symbol = renderer.symbol()
                        if symbol:
                            geom_type = layer.geometryType() if hasattr(layer, 'geometryType') else None
                            symbol_layer = symbol.symbolLayer(0) if hasattr(symbol, 'symbolLayer') and callable(symbol.symbolLayer) else None
                            if symbol_layer:
                                if hasattr(symbol_layer, 'fillColor') and callable(symbol_layer.fillColor):
                                    fill_c = symbol_layer.fillColor()
                                    color = fill_c.name(QColor.HexArgb) if hasattr(fill_c, 'name') else str(fill_c.name())
                                if hasattr(symbol_layer, 'strokeColor') and callable(symbol_layer.strokeColor):
                                    stroke_c = symbol_layer.strokeColor()
                                    stroke_color = stroke_c.name(QColor.HexArgb) if hasattr(stroke_c, 'name') else str(stroke_c.name())
                                if geom_type == 1 and not color and hasattr(symbol_layer, 'strokeColor') and callable(symbol_layer.strokeColor):
                                    stroke_c = symbol_layer.strokeColor()
                                    color = stroke_c.name(QColor.HexArgb) if hasattr(stroke_c, 'name') else str(stroke_c.name())
                                if geom_type == 0 and not color and hasattr(symbol_layer, 'fillColor') and callable(symbol_layer.fillColor):
                                    fill_c = symbol_layer.fillColor()
                                    color = fill_c.name(QColor.HexArgb) if hasattr(fill_c, 'name') else str(fill_c.name())
                            if not color and hasattr(symbol, 'color') and callable(symbol.color):
                                c = symbol.color()
                                color = c.name(QColor.HexArgb) if hasattr(c, 'name') else str(c.name())
                            if not stroke_color and hasattr(symbol, 'color') and callable(symbol.color):
                                c = symbol.color()
                                stroke_color = c.name(QColor.HexArgb) if hasattr(c, 'name') else str(c.name())
                        # symbol is None の場合は何もしない
                    except Exception:
                        color = None
                        stroke_color = None

                    try:
                        gt = layer.geometryType() if hasattr(layer, 'geometryType') else None
                        if gt == 0:
                            geom_type_name = 'Point'
                        elif gt == 1:
                            geom_type_name = 'LineString'
                        elif gt == 2:
                            geom_type_name = 'Polygon'
                        elif gt is None:
                            geom_type_name = 'Unknown'
                        else:
                            geom_type_name = str(gt)
                    except Exception:
                        geom_type_name = 'Unknown'

                    layer_entry = {
                        'id': layer.id(),
                        # canonical typename: use the QGIS layer.id() exactly
                        'typename': layer.id(),
                        'name': name_norm,
                        'title': title,
                        'crs': crs,
                        'bbox': bbox,
                        'geom_type': geom_type_name
                    }
                    if color:
                        layer_entry['color'] = color
                    if stroke_color:
                        layer_entry['stroke_color'] = stroke_color
                    layers_list.append(layer_entry)
                except Exception:
                    continue

            return layers_list
        except Exception:
            return []

    def _generate_wms_based_html_page(self, x, y, scale, crs, rotation, width, height):
        """WMSエンドポイントを使用するHTMLページを生成（WebMapGeneratorを使用）"""
        
        try:
            # WebMapGeneratorを使用してWMSベースのHTMLページを生成
            navigation_data = {
                'x': float(x),
                'y': float(y),
                'scale': float(scale),
                'crs': str(crs),
                'rotation': float(rotation)
            }
            
            server_port = self.http_server.getsockname()[1] if self.http_server else 8089
            # Try to collect QGIS spatial bookmarks and inject into navigation_data
            bookmarks_list = []
            try:
                from qgis.core import QgsProject, QgsMessageLog, Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsPointXY

                # Try common bookmark manager access patterns
                mgr = None
                try:
                    mgr = QgsProject.instance().bookmarkManager()
                except Exception:
                    try:
                        mgr = QgsProject.instance().bookmarks()
                    except Exception:
                        mgr = None

                if mgr is None:
                    QgsMessageLog.logMessage('🔍 Bookmark manager not found (mgr is None)', 'QMapPermalink', Qgis.Warning)

                raw = None
                if mgr is not None:
                    try:
                        raw = mgr.bookmarks()
                    except Exception:
                        try:
                            raw = mgr.getBookmarks()
                        except Exception:
                            raw = None

                if raw is None:
                    pass
                else:
                    try:
                        length = len(raw)
                    except Exception:
                        length = 'unknown'

                if raw:
                    for b in raw:
                        # Extract name
                        name = ''
                        try:
                            if hasattr(b, 'name'):
                                name = b.name()
                            else:
                                name = str(getattr(b, 'displayName', '') or '')
                        except Exception:
                            try:
                                if isinstance(b, dict) and 'name' in b:
                                    name = str(b.get('name'))
                            except Exception:
                                name = ''

                        # Extract point-like coordinates from common accessors
                        bx = None; by = None
                        try:
                            if hasattr(b, 'point'):
                                p = b.point(); bx = p.x(); by = p.y()
                        except Exception:
                            bx = None; by = None

                        if (bx is None or by is None) and hasattr(b, 'center'):
                            try:
                                p = b.center(); bx = p.x(); by = p.y()
                            except Exception:
                                pass

                        if (bx is None or by is None) and hasattr(b, 'extent'):
                            try:
                                ext = b.extent(); bx = (ext.xMinimum() + ext.xMaximum()) / 2.0; by = (ext.yMinimum() + ext.yMaximum()) / 2.0
                            except Exception:
                                pass

                        if (bx is None or by is None) and isinstance(b, dict):
                            try:
                                if 'x' in b and 'y' in b:
                                    bx = float(b.get('x')); by = float(b.get('y'))
                                elif 'lon' in b and 'lat' in b:
                                    bx = float(b.get('lon')); by = float(b.get('lat'))
                            except Exception:
                                pass

                        if bx is None or by is None:
                            # couldn't obtain coordinates for this bookmark
                            continue

                        # Determine source CRS for bookmark if available
                        src_crs = None
                        try:
                            if hasattr(b, 'crs'):
                                src_crs = b.crs()
                        except Exception:
                            src_crs = None

                        if not src_crs:
                            try:
                                src_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
                            except Exception:
                                src_crs = QgsCoordinateReferenceSystem('EPSG:3857')

                        # Transform bookmark original coordinates to EPSG:3857 (client expects 3857)
                        try:
                            tgt_crs = QgsCoordinateReferenceSystem('EPSG:3857')
                            transform = QgsCoordinateTransform(src_crs, tgt_crs, QgsProject.instance())
                            pt = transform.transform(QgsPointXY(bx, by))
                            lon = float(pt.x()); lat = float(pt.y())
                        except Exception:
                            lon = float(bx); lat = float(by)

                        # determine original source CRS id for potential proj4 registration
                        src_crs_id = None
                        try:
                            if hasattr(src_crs, 'authid'):
                                src_crs_id = src_crs.authid()
                            else:
                                src_crs_id = str(src_crs)
                        except Exception:
                            src_crs_id = None

                        # Keep both a client-friendly lon/lat in EPSG:4326 and the
                        # original bookmark coordinates (orig_x/orig_y) in the
                        # bookmark's source CRS so the client can request the
                        # server to render using the original CRS when available.
                        bookmarks_list.append({
                            'name': str(name),
                            # provide bookmark coordinates already in EPSG:3857 for client
                            'x': lon,
                            'y': lat,
                            'crs': 'EPSG:3857',
                            'src_crs': src_crs_id,
                            'orig_x': bx,
                            'orig_y': by
                        })
            except Exception:
                # On any issue, don't block page generation; just omit bookmarks
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage('❌ Error while extracting bookmarks; skipping bookmarks', 'QMapPermalink', Qgis.Warning)
                except Exception:
                    pass

            if bookmarks_list:
                navigation_data['bookmarks'] = bookmarks_list

            # Try to collect available map themes and inject into navigation_data
            themes_list = []
            try:
                from qgis.core import QgsProject
                project = QgsProject.instance()
                try:
                    theme_collection = project.mapThemeCollection()
                except Exception:
                    theme_collection = None

                if theme_collection:
                    try:
                        available = theme_collection.mapThemes()
                        # mapThemes() may return dict-like or iterable of names
                        if isinstance(available, dict):
                            themes_list = sorted(list(available.keys()))
                        else:
                            # ensure list of strings
                            themes_list = [str(t) for t in available]
                    except Exception:
                        themes_list = []
            except Exception:
                themes_list = []

            if themes_list:
                navigation_data['themes'] = themes_list

            # WebMapGeneratorの新しいメソッドを使用
            html_content = self.webmap_generator.generate_wms_based_html_page(
                navigation_data, 
                int(width), 
                int(height), 
                server_port
            )
            
            return html_content
            
        except Exception as e:
            # フォールバック: シンプルなWMSベースHTMLページ
            server_port = self.http_server.getsockname()[1] if self.http_server else 8089
            # Use relative WMS URL so clients use the same origin as the HTML page
            base_url = f"/"
            wms_url = f"/wms?x={x}&y={y}&scale={scale}&crs={crs}&rotation={rotation}&width={width}&height={height}"
        
        # Build head scripts for OpenLayers using shared utility
        try:
            from qmap_permalink.proj_utils import build_ol_proj_head, crs_has_proj4
            head_scripts = build_ol_proj_head(crs)
        except Exception:
            # fallback include
            head_scripts = (
                '    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@v8.2.0/ol.css" type="text/css">\n'
                '    <script src="https://cdn.jsdelivr.net/npm/ol@v8.2.0/dist/ol.js"></script>\n'
            )

        # Projection registration via proj4 is no longer used. The plugin
        # enforces EPSG:3857 on the client and performs server-side transforms
        # earlier in the request handling, so no additional special-case is necessary here.

        # OpenLayersを使用したHTMLページテンプレート
        html_template = f"""<!DOCTYPE html>
<html lang="ja">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QMap Permalink - 地図表示</title>
{head_scripts}
    <style>
        body {{
            margin: 0;
            padding: 20px;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .header {{
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }}
        .map-container {{
            position: relative;
            height: 600px;
            border: 2px solid #ddd;
        }}
        #map {{
            width: 100%;
            height: 100%;
        }}
        .info-panel {{
            padding: 20px;
            background: #ecf0f1;
            border-top: 1px solid #ddd;
        }}
        .info-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }}
        .info-item {{
            background: white;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #3498db;
        }}
        .info-label {{
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }}
        .info-value {{
            color: #555;
            font-family: monospace;
        }}
        .controls {{
            padding: 20px;
            background: #f8f9fa;
            border-top: 1px solid #ddd;
            text-align: center;
        }}
        .btn {{
            padding: 10px 20px;
            margin: 5px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }}
        .btn:hover {{
            background: #2980b9;
        }}
        .btn-secondary {{
            background: #95a5a6;
        }}
        .btn-secondary:hover {{
            background: #7f8c8d;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🗺️ QMap Permalink</h1>
            <p>QGISプラグインによる統合地図表示 - WMSエンドポイント使用</p>
        </div>
        
        <div class="map-container">
            <div id="map"></div>
        </div>
        
        <div class="info-panel">
            <h3>📍 地図情報</h3>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">中心座標 (X)</div>
                    <div class="info-value">{x}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">中心座標 (Y)</div>
                    <div class="info-value">{y}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">縮尺</div>
                    <div class="info-value">1:{scale}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">座標系</div>
                    <div class="info-value">{crs}</div>
                </div>
                <div class="info-item">
                    <div class="info-label">回転角度</div>
                    <div class="info-value">{rotation}°</div>
                </div>
                <div class="info-item">
                    <div class="info-label">画像サイズ</div>
                    <div class="info-value">{width} × {height}</div>
                </div>
            </div>
        </div>
        
        <div class="controls">
            <h3>🔧 コントロール</h3>
            <a href="{wms_url}" target="_blank" class="btn">📷 WMS画像を表示</a>
            <a href="/wms?SERVICE=WMS&REQUEST=GetCapabilities" target="_blank" class="btn btn-secondary">📋 WMS Capabilities</a>
            <button onclick="refreshMap()" class="btn">🔄 地図を更新</button>
            <button onclick="copyPermalink()" class="btn btn-secondary">🔗 パーマリンクをコピー</button>
        </div>
    </div>

    <script>
        // OpenLayers地図の初期化
        const centerX = parseFloat('{x}');
        const centerY = parseFloat('{y}');
        const mapScale = parseFloat('{scale}');
        const mapRotation = parseFloat('{rotation}') * Math.PI / 180; // ラジアンに変換
        const mapCrs = '{crs}';
        
        // 地図の初期化
        const map = new ol.Map({{
            target: 'map',
            layers: [
                new ol.layer.Image({{
                    source: new ol.source.ImageWMS({{
                        url: '/wms',
                        params: {{
                            'x': centerX,
                            'y': centerY,
                            'scale': mapScale,
                            'crs': mapCrs,
                            'ANGLE': {rotation},
                            'width': 800,
                            'height': 600
                        }},
                        serverType: 'qgis',
                        crossOrigin: 'anonymous'
                    }})
                }})
            ],
            view: new ol.View({{
                center: [centerX, centerY],
                zoom: calculateZoomFromScale(mapScale),
                rotation: mapRotation,
                projection: mapCrs
            }})
        }});

        // Ensure the WMS source receives the initial ANGLE param (degrees)
        try {{
            var _wmsSrc = map.getLayers().getArray()[0].getSource();
            try {{ window.wmsSource = _wmsSrc; }} catch(e) {{}}
            var _initAngleDeg = 0;
            try {{ _initAngleDeg = (typeof mapRotation === 'number') ? (mapRotation * 180 / Math.PI) : (parseFloat('{rotation}') || 0); }} catch(e) {{ _initAngleDeg = parseFloat('{rotation}') || 0; }}
            if(_wmsSrc && typeof _wmsSrc.updateParams === 'function') {{
                try {{ _wmsSrc.updateParams({{ 'ANGLE': _initAngleDeg }}); }} catch(e) {{}}
                try {{ _wmsSrc.refresh(); }} catch(e) {{}}
            }}
        }} catch(e) {{ /* fail silently */ }}
        
        // 北向き矢印コントロールを追加
        map.addControl(new ol.control.Rotate({{
            tipLabel: '北向きに回転',
            resetNorthLabel: '北向きにリセット'
        }}));
        
        // スケールからズームレベルを計算する関数
        function calculateZoomFromScale(scale) {{
            // 概算でのズームレベル計算
            const baseScale = 591657527.591555;
            return Math.log2(baseScale / scale);
        }}
        
        // 地図の回転に合わせてWMSパラメータも更新
        map.getView().on('change:rotation', function() {{
            const rotation = map.getView().getRotation();
            const angleDeg = rotation * 180 / Math.PI;
            const wmsSource = map.getLayers().getArray()[0].getSource();
            if(wmsSource && typeof wmsSource.updateParams === 'function'){{
                wmsSource.updateParams({{ 'ANGLE': angleDeg }});
                wmsSource.refresh();
            }}
        }});
        
        // 地図を更新する関数
        function refreshMap() {{
            map.getView().setCenter([centerX, centerY]);
            map.getView().setZoom(calculateZoomFromScale(mapScale));
            // Do not force rotation to 0 here; preserve current view rotation.
            map.getLayers().getArray()[0].getSource().refresh();
        }}
        
        // パーマリンクをコピーする関数
        function copyPermalink() {{
            const permalink = window.location.href;
            navigator.clipboard.writeText(permalink).then(() => {{
                alert('パーマリンクをクリップボードにコピーしました！');
            }}).catch(() => {{
                // フォールバック
                const textArea = document.createElement('textarea');
                textArea.value = permalink;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                alert('パーマリンクをクリップボードにコピーしました！');
            }});
        }}
        
        // ページ読み込み完了時の処理
        document.addEventListener('DOMContentLoaded', function() {{
            console.log('🗺️ QMap Permalink page loaded');
            console.log('📍 Center:', centerX, centerY);
            console.log('📏 Scale:', mapScale);
            console.log('🔄 Rotation:', '{rotation}°');
            console.log('🌐 CRS:', mapCrs);
        }});
    </script>
</body>
</html>"""
        
        return html_template

    def _get_ol_proj_head(self, crs):
        """Return HTML head scripts for OpenLayers.

        If QGIS can provide a proj4 definition for the given CRS, include
        proj4.js and register the definition so OpenLayers can use the CRS.
        Otherwise return the minimal OpenLayers includes.

        This is a single method to keep the projection-registration logic
        simple and centralized.

        Args:
            crs (str): CRS identifier like 'EPSG:3857'

        Returns:
            str: HTML snippet to insert into the <head>
        """
        try:
            from qgis.core import QgsCoordinateReferenceSystem
            crs_obj = QgsCoordinateReferenceSystem(str(crs))
            if crs_obj.isValid():
                try:
                    proj4_def = crs_obj.toProj4()
                except Exception:
                    proj4_def = ''
                if proj4_def:
                    # Escape quotes/newlines for embedding
                    proj4_def_escaped = proj4_def.replace('"', '\\"').replace('\n', ' ')
                    return (
                        '    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@v8.2.0/ol.css" type="text/css">\n'
                        '    <script src="https://cdnjs.cloudflare.com/ajax/libs/proj4js/2.8.0/proj4.js"></script>\n'
                        '    <script src="https://cdn.jsdelivr.net/npm/ol@v8.2.0/dist/ol.js"></script>\n'
                        f'    <script>try{{proj4.defs("{crs}", "{proj4_def_escaped}"); if (ol && ol.proj && ol.proj.proj4) {{ ol.proj.proj4.register(proj4); }} else {{ console.warn("ol.proj.proj4 not available - projection registration skipped"); }} }}catch(e){{console.warn("proj4 registration failed", e);}}</script>'
                    )
        except Exception:
            # any failure -> fallthrough to default head
            pass

        # default: only include OpenLayers
        return (
            '    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ol@v8.2.0/ol.css" type="text/css">\n'
            '    <script src="https://cdn.jsdelivr.net/npm/ol@v8.2.0/dist/ol.js"></script>\n'
        )

    def _crs_has_proj4(self, crs):
        """Return True if QGIS can provide a proj4 definition for the CRS."""
        try:
            from qgis.core import QgsCoordinateReferenceSystem
            crs_obj = QgsCoordinateReferenceSystem(str(crs))
            if not crs_obj.isValid():
                return False
            try:
                proj4_def = crs_obj.toProj4()
            except Exception:
                proj4_def = ''
            return bool(proj4_def)
        except Exception:
            return False

    def _build_navigation_data_from_params(self, params):
        """互換性用: HTTPパラメータ(dict of lists)から navigation_data を構築して返す

        params: dict where values are lists (urllib.parse.parse_qs形式)

        Returns:
            dict: navigation_data. Examples:
                {'type': 'location', 'location': '<encoded json>'}
                {'type': 'coordinates', 'x': x, 'y': y, 'scale': scale, 'crs': crs, 'zoom': zoom, 'rotation': rotation, 'theme_info': theme}

        Raises:
            ValueError: 必要なパラメータが不足している場合
        """
        from qgis.core import QgsMessageLog, Qgis

        try:
            # location パラメータがあれば location タイプ
            if 'location' in params and params['location']:
                location_val = params['location'][0]
                return {'type': 'location', 'location': location_val}

            # coordinates ベース: x, y が必須
            if 'x' in params and 'y' in params:
                x_val = params.get('x', [None])[0]
                y_val = params.get('y', [None])[0]
                if x_val is None or y_val is None:
                    raise ValueError('x or y parameter missing')

                # optional params
                scale_val = params.get('scale', [None])[0]
                zoom_val = params.get('zoom', [None])[0]
                crs_val = params.get('crs', [None])[0]
                rotation_val = params.get('rotation', [None])[0]
                theme_val = params.get('theme', [None])[0]

                navigation_data = {
                    'type': 'coordinates',
                    'x': float(x_val) if x_val is not None else None,
                    'y': float(y_val) if y_val is not None else None,
                    'scale': float(scale_val) if scale_val is not None else None,
                    'zoom': float(zoom_val) if zoom_val is not None else None,
                    'crs': str(crs_val) if crs_val is not None else None,
                    'rotation': float(rotation_val) if rotation_val is not None else None,
                    'theme_info': theme_val
                }

                return navigation_data

            # フォールバック: 不明なパラメータ
            raise ValueError('No navigation parameters found')

        except Exception as e:
            QgsMessageLog.logMessage(f"Error building navigation_data from params: {e}", "QMapPermalink", Qgis.Warning)
            raise

    def _generate_error_html_page(self, error_message):
        """エラーページのHTMLを生成"""
        error_html = f"""<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QMap Permalink - エラー</title>
    <style>
        body {{
            margin: 0;
            padding: 40px;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .error-container {{
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 500px;
        }}
        .error-icon {{
            font-size: 4rem;
            margin-bottom: 20px;
        }}
        .error-title {{
            color: #e74c3c;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }}
        .error-message {{
            color: #555;
            margin-bottom: 30px;
            line-height: 1.6;
        }}
        .btn {{
            padding: 12px 24px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin: 5px;
        }}
        .btn:hover {{
            background: #2980b9;
        }}
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-icon">❌</div>
        <h1 class="error-title">パーマリンクページの生成に失敗</h1>
        <p class="error-message">{html.escape(error_message)}</p>
        <a href="javascript:history.back()" class="btn">🔙 戻る</a>
        <a href="/" class="btn">🏠 ホーム</a>
    </div>
</body>
</html>"""
        return error_html

    def _calculate_bbox_from_permalink(self, center_x, center_y, scale, width, height, crs):
        """パーマリンクパラメータからBBOXを計算"""
        try:
            from qgis.core import QgsMessageLog, Qgis
            
            # 画面解像度（DPI）とピクセルあたりのサイズを計算
            dpi = 96  # 標準DPI
            meters_per_inch = 0.0254
            pixels_per_meter = dpi / meters_per_inch
            
            # スケールから地図単位での表示範囲を計算
            map_width_m = (width / pixels_per_meter) * scale
            map_height_m = (height / pixels_per_meter) * scale
            
            # 中心点から範囲を計算
            half_width = map_width_m / 2
            half_height = map_height_m / 2
            
            minx = center_x - half_width
            miny = center_y - half_height
            maxx = center_x + half_width
            maxy = center_y + half_height
            
            bbox = f"{minx},{miny},{maxx},{maxy}"
            
            
            return bbox
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ BBOX calculation error: {e}", "QMapPermalink", Qgis.Warning)
            return None

    def _handle_wms_get_map_with_bbox(self, conn, bbox, crs, width, height, rotation=0.0):
        """計算されたBBOXでWMS GetMapを処理"""
        from qgis.core import QgsMessageLog, Qgis
        
        try:
            # If requested CRS is not EPSG:3857, transform bbox to EPSG:3857
            try:
                if crs and crs.upper() != 'EPSG:3857' and bbox:
                    from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsRectangle
                    src_crs = QgsCoordinateReferenceSystem(crs)
                    tgt_crs = QgsCoordinateReferenceSystem('EPSG:3857')
                    if src_crs.isValid():
                        coords = [float(x) for x in bbox.split(',')]
                        if len(coords) == 4:
                            rect = QgsRectangle(coords[0], coords[1], coords[2], coords[3])
                            transform = QgsCoordinateTransform(src_crs, tgt_crs, QgsProject.instance())
                            rect = transform.transformBoundingBox(rect)
                            bbox = f"{rect.xMinimum()},{rect.yMinimum()},{rect.xMaximum()},{rect.yMaximum()}"
                            crs = 'EPSG:3857'
                    else:
                        QgsMessageLog.logMessage(f"⚠️ Invalid CRS '{crs}' - forcing to EPSG:3857", "QMapPermalink", Qgis.Warning)
                        crs = 'EPSG:3857'
            except Exception:
                pass

            # Use canvas-based rendering as the authoritative method for
            # permalink BBOX requests. Rotation handling should be applied
            # via canvas extent/rotation adjustment if needed.
            png_data = self._generate_qgis_map_png(width, height, bbox, crs, rotation)
            if png_data and len(png_data) > 1000:
                from . import http_server
                http_server.send_binary_response(conn, 200, "OK", png_data, "image/png")
                return
            
            # 最終フォールバック: エラー画像
            error_image = self._generate_error_image(width, height, "Permalink Rendering Failed")
            from . import http_server
            http_server.send_binary_response(conn, 200, "OK", error_image, "image/png")
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ WMS GetMap with BBOX error: {e}", "QMapPermalink", Qgis.Critical)
            error_image = self._generate_error_image(width, height, f"Error: {str(e)}")
            from . import http_server
            http_server.send_binary_response(conn, 200, "OK", error_image, "image/png")

    def _generate_webmap_png(self, width, height, bbox, crs):
        """WebMapGeneratorを使用してPNG画像を生成"""
        try:
            from qgis.core import QgsMessageLog, Qgis
            
            if not self.webmap_generator:
                QgsMessageLog.logMessage("❌ WebMapGenerator not available", "QMapPermalink", Qgis.Warning)
                return None
            
            # WebMapGeneratorにダミーのナビゲーションデータを渡す
            navigation_data = {
                'type': 'coordinates',
                'lat': 35.6762,  # 東京駅
                'lon': 139.6503,
                'crs': 'EPSG:4326',
                'scale': 10000,
                'zoom': 10
            }
            
            # WMSパラメータからナビゲーションデータを更新
            if bbox and crs:
                try:
                    coords = [float(x) for x in bbox.split(',')]
                    if len(coords) == 4:
                        minx, miny, maxx, maxy = coords
                        center_lon = (minx + maxx) / 2
                        center_lat = (miny + maxy) / 2
                        navigation_data.update({
                            'lon': center_lon,
                            'lat': center_lat,
                            'crs': crs
                        })
                except Exception as e:
                    QgsMessageLog.logMessage(f"⚠️ Failed to parse BBOX: {e}", "QMapPermalink", Qgis.Warning)
            
            # WebMapGeneratorを使って画像を生成
            try:
                # generate_qgis_image_map メソッドを使用（HTML文字列を取得）
                html_content = self.webmap_generator.generate_qgis_image_map(navigation_data, width, height)
                
                # HTMLコンテンツからbase64画像データを抽出
                import re
                base64_match = re.search(r'data:image/png;base64,([A-Za-z0-9+/=]+)', html_content)
                if base64_match:
                    import base64
                    png_data = base64.b64decode(base64_match.group(1))
                    return png_data
                else:
                    QgsMessageLog.logMessage("❌ No base64 image found in WebMapGenerator output", "QMapPermalink", Qgis.Warning)
                    return None
                    
            except Exception as e:
                QgsMessageLog.logMessage(f"❌ WebMapGenerator generation failed: {e}", "QMapPermalink", Qgis.Warning)
                return None
                
        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"❌ Error in _generate_webmap_png: {e}", "QMapPermalink", Qgis.Critical)
            return None

    def _generate_qgis_map_png(self, width, height, bbox, crs, rotation=0.0):
        """Generate PNG using PyQGIS independent renderer only.

        This implementation avoids canvas capture and always uses the
        independent renderer (QgsMapSettings + QgsMapRendererParallelJob).
        """
        from qgis.core import QgsMessageLog, Qgis

        try:
            return self._render_map_image(width, height, bbox, crs, rotation)
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Error in _generate_qgis_map_png (delegated): {e}", "QMapPermalink", Qgis.Critical)
            return None

    def _set_canvas_extent_from_bbox(self, bbox, crs):
        """WMS BBOXパラメータからキャンバスの表示範囲を設定"""
        from qgis.core import QgsMessageLog, Qgis
        
        try:
            # BBOXの解析 (minx,miny,maxx,maxy)
            coords = [float(x) for x in bbox.split(',')]
            if len(coords) != 4:
                QgsMessageLog.logMessage(f"❌ Invalid BBOX format: {bbox}", "QMapPermalink", Qgis.Warning)
                return False
            
            minx, miny, maxx, maxy = coords
            
            # QGISの座標系変換を設定
            from qgis.core import QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsRectangle
            
            # 入力CRS
            source_crs = QgsCoordinateReferenceSystem(crs)
            if not source_crs.isValid():
                QgsMessageLog.logMessage(f"❌ Invalid CRS: {crs}", "QMapPermalink", Qgis.Warning)
                return False
            
            # キャンバスのCRS取得
            canvas = self.iface.mapCanvas()
            if not canvas:
                QgsMessageLog.logMessage("❌ No map canvas available", "QMapPermalink", Qgis.Warning)
                return False
            
            dest_crs = canvas.mapSettings().destinationCrs()
            
            # 座標変換が必要かチェック
            extent = QgsRectangle(minx, miny, maxx, maxy)
            
            if source_crs.authid() != dest_crs.authid():
                # 座標変換実行
                transform = QgsCoordinateTransform(source_crs, dest_crs, QgsProject.instance())
                try:
                    extent = transform.transformBoundingBox(extent)
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ Coordinate transformation failed: {e}", "QMapPermalink", Qgis.Warning)
                    return False
            
            # キャンバスの表示範囲を設定
            canvas.setExtent(extent)
            canvas.refresh()
            
            return True
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Error setting canvas extent: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            return False

    def _capture_canvas_image(self, width, height):
        """キャンバスから直接画像をキャプチャ"""
        # Qt GUI operations (like canvas.grab()) must run in the GUI/main thread.
        # The HTTP server runs in a worker thread, so calling canvas.grab() directly
        # can cause an access violation. To avoid this we request a capture on the
        # main thread via a helper QObject that emits a signal when done, and
        # we wait synchronously (with a timeout) for the result.
        try:
            from qgis.core import QgsMessageLog, Qgis
            from qgis.PyQt.QtCore import QObject, pyqtSignal, pyqtSlot, QEventLoop, QTimer, QCoreApplication

            # Define the helper only once and keep it on the instance.
            if not hasattr(self, '_capture_helper') or self._capture_helper is None:
                class _CanvasCaptureHelper(QObject):
                    request_capture = pyqtSignal(int, int)
                    finished = pyqtSignal(bytes)

                    def __init__(self, iface):
                        super().__init__()
                        self.iface = iface
                        # connect request -> internal slot which runs in helper's thread
                        self.request_capture.connect(self._do_capture)

                    @pyqtSlot(int, int)
                    def _do_capture(self, w, h):
                        try:
                            canvas = self.iface.mapCanvas()
                            if not canvas:
                                QgsMessageLog.logMessage("❌ No map canvas available (helper)", "QMapPermalink", Qgis.Warning)
                                self.finished.emit(b'')
                                return

                            # Allow pending paint events to finish so labels/symbols
                            # complete rendering before grabbing.
                            try:
                                from qgis.PyQt.QtWidgets import QApplication
                                QApplication.processEvents()
                            except Exception:
                                pass

                            pixmap = canvas.grab()
                            if pixmap.isNull():
                                QgsMessageLog.logMessage("❌ Failed to grab canvas pixmap (helper)", "QMapPermalink", Qgis.Warning)
                                self.finished.emit(b'')
                                return

                            # scale if requested size differs
                            try:
                                from qgis.PyQt.QtCore import Qt
                                # For WMS we should match the requested size exactly
                                if w and h and (w != pixmap.width() or h != pixmap.height()):
                                    pixmap = pixmap.scaled(w, h, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
                            except Exception:
                                pass

                            image = pixmap.toImage()
                            if image.isNull():
                                QgsMessageLog.logMessage("❌ Failed to convert pixmap to image (helper)", "QMapPermalink", Qgis.Warning)
                                self.finished.emit(b'')
                                return

                            from qgis.PyQt.QtCore import QByteArray, QBuffer, QIODevice
                            byte_array = QByteArray()
                            buffer = QBuffer(byte_array)
                            buffer.open(QIODevice.WriteOnly)
                            success = image.save(buffer, "PNG")
                            if not success:
                                QgsMessageLog.logMessage("❌ Failed to save image as PNG (helper)", "QMapPermalink", Qgis.Warning)
                                self.finished.emit(b'')
                                return

                            png_data = byte_array.data()
                            self.finished.emit(png_data)

                        except Exception as e:
                            QgsMessageLog.logMessage(f"❌ Exception in helper capture: {e}", "QMapPermalink", Qgis.Warning)
                            try:
                                self.finished.emit(b'')
                            except Exception:
                                pass

                # Create helper and move it to the main (GUI) thread so its slot runs there.
                helper = _CanvasCaptureHelper(self.iface)
                try:
                    main_thread = QCoreApplication.instance().thread()
                    helper.moveToThread(main_thread)
                except Exception:
                    # If moveToThread fails for any reason, keep helper in current thread
                    pass
                self._capture_helper = helper

            helper = self._capture_helper

            # Prepare an event loop to wait for the capture to finish (with timeout).
            loop = QEventLoop()
            captured = {'data': b''}

            def _on_finished(data):
                captured['data'] = data or b''
                try:
                    loop.quit()
                except Exception:
                    pass

            helper.finished.connect(_on_finished)

            # Emit request; because helper lives in GUI thread, the connected slot
            # will be invoked there. Emission from worker thread is safe and
            # delivery is queued to the helper's thread.
            helper.request_capture.emit(int(width), int(height))

            # Safety timeout (5 seconds) to avoid hanging the server thread forever.
            timer = QTimer()
            timer.setSingleShot(True)
            timer.timeout.connect(lambda: loop.quit())
            timer.start(5000)

            loop.exec_()
            try:
                helper.finished.disconnect(_on_finished)
            except Exception:
                pass

            png = captured.get('data')
            if png and len(png) > 0:
                return png

            # If capture failed or timed out, fallback to None so caller can try
            # other rendering approaches.
            QgsMessageLog.logMessage("⚠️ Canvas capture timed out or failed", "QMapPermalink", Qgis.Warning)
            return None

        except Exception as e:
            from qgis.core import QgsMessageLog, Qgis
            QgsMessageLog.logMessage(f"❌ Error in _capture_canvas_image: {e}", "QMapPermalink", Qgis.Critical)
            return None

    def _render_map_image(self, width, height, bbox, crs, rotation=0.0):
        """独立レンダラでPNGを生成する（rotation をサポート）

        Args:
            width, height: 出力ピクセルサイズ
            bbox: 'minx,miny,maxx,maxy' 文字列または None
            crs: CRS文字列（例: 'EPSG:3857'）
            rotation: 地図回転角度（度単位）。QgsMapSettings の回転サポートがある場合に使用されます。
        """
        from qgis.core import QgsMessageLog, Qgis

        try:
            # WMS独立レンダリング設定を作成
            map_settings = self._create_wms_map_settings(width, height, bbox, crs, rotation=rotation)
            if not map_settings:
                QgsMessageLog.logMessage("❌ Failed to create WMS map settings", "QMapPermalink", Qgis.Warning)
                return None

            # 独立したマップレンダラーでPNG画像を生成
            png_data = self._execute_map_rendering(map_settings)
            if png_data:
                return png_data
            else:
                QgsMessageLog.logMessage("❌ Professional WMS rendering failed", "QMapPermalink", Qgis.Warning)
                return None

        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Error in professional WMS rendering: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            return None

    def _create_wms_map_settings(self, width, height, bbox, crs, rotation=0.0):
        """WMS用の独立したマップ設定を作成 - キャンバスに依存しない

        rotation: 回転角度（度） — map settings が回転をサポートする場合は適用します。
        """
        from qgis.core import QgsMapSettings, QgsRectangle, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsMessageLog, Qgis
        
        try:
            # 新しいマップ設定オブジェクトを作成
            map_settings = QgsMapSettings()
            
            # 1. レイヤ設定 - QGISデスクトップの表示状態を踏襲
            canvas = self.iface.mapCanvas()
            if canvas:
                # アクティブなレイヤのみを取得（表示状態を踏襲）
                visible_layers = []
                layer_tree_root = QgsProject.instance().layerTreeRoot()
                
                for layer in canvas.layers():
                    layer_tree_layer = layer_tree_root.findLayer(layer.id())
                    if layer_tree_layer and layer_tree_layer.isVisible():
                        visible_layers.append(layer)
                
                map_settings.setLayers(visible_layers)
                map_settings.setBackgroundColor(canvas.canvasColor())
            else:
                # キャンバスが無い場合はプロジェクトの全レイヤを使用
                from qgis.core import QgsProject
                project = QgsProject.instance()
                map_settings.setLayers(project.mapLayers().values())
                QgsMessageLog.logMessage("⚠️ No canvas, using all project layers", "QMapPermalink", Qgis.Warning)
            
            # 2. 出力サイズ設定
            from PyQt5.QtCore import QSize
            map_settings.setOutputSize(QSize(width, height))
            
            # 3. 座標系と範囲設定 - WMSパラメータに基づく
            if bbox and crs:
                success = self._configure_wms_extent_and_crs(map_settings, bbox, crs)
                if not success:
                    QgsMessageLog.logMessage("❌ Failed to configure WMS extent/CRS", "QMapPermalink", Qgis.Warning)
                    return None
            else:
                # デフォルト範囲設定
                if canvas:
                    map_settings.setDestinationCrs(canvas.mapSettings().destinationCrs())
                    map_settings.setExtent(canvas.extent())
                else:
                    # 世界全体をデフォルトに
                    world_crs = QgsCoordinateReferenceSystem("EPSG:4326")
                    world_extent = QgsRectangle(-180, -90, 180, 90)
                    map_settings.setDestinationCrs(world_crs)
                    map_settings.setExtent(world_extent)
            
            # 4. 品質設定
            map_settings.setFlag(QgsMapSettings.Antialiasing, True)
            map_settings.setFlag(QgsMapSettings.UseAdvancedEffects, True)
            map_settings.setFlag(QgsMapSettings.ForceVectorOutput, False)
            map_settings.setFlag(QgsMapSettings.DrawEditingInfo, False)
            
            # 5. DPI設定
            map_settings.setOutputDpi(96)

            # 6. 回転（度） - QgsMapSettings には setRotation がある場合に適用
            try:
                # Apply rotation when caller provided a rotation value (including 0.0).
                # This ensures ANGLE=0 and ANGLE!=0 follow the same code path.
                if rotation is not None and hasattr(map_settings, 'setRotation'):
                    map_settings.setRotation(float(rotation))
            except Exception:
                pass
            
            return map_settings
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Error creating WMS map settings: {e}", "QMapPermalink", Qgis.Critical)
            return None

    def _configure_wms_extent_and_crs(self, map_settings, bbox, crs):
        """WMSパラメータに基づいて範囲と座標系を設定"""
        from qgis.core import QgsRectangle, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject, QgsMessageLog, Qgis
        
        try:
            # BBOXの解析 (minx,miny,maxx,maxy)
            coords = [float(x) for x in bbox.split(',')]
            if len(coords) != 4:
                QgsMessageLog.logMessage(f"❌ Invalid BBOX format: {bbox}", "QMapPermalink", Qgis.Warning)  
                return False
            
            minx, miny, maxx, maxy = coords
            extent = QgsRectangle(minx, miny, maxx, maxy)
            
            # CRS設定
            target_crs = QgsCoordinateReferenceSystem(crs)
            if not target_crs.isValid():
                QgsMessageLog.logMessage(f"❌ Invalid CRS: {crs}", "QMapPermalink", Qgis.Warning)
                return False
            
            map_settings.setDestinationCrs(target_crs)
            map_settings.setExtent(extent)
            
            return True
            
        except ValueError as e:
            QgsMessageLog.logMessage(f"❌ Error parsing BBOX coordinates: {e}", "QMapPermalink", Qgis.Warning)
            return False
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Error configuring WMS extent/CRS: {e}", "QMapPermalink", Qgis.Critical)
            return False

    def _execute_map_rendering(self, map_settings):
        """独立したマップレンダラーでPNG画像を生成"""
        from qgis.core import QgsMapRendererParallelJob, QgsMessageLog, Qgis
        
        try:
            # 並列レンダリングジョブを作成
            job = QgsMapRendererParallelJob(map_settings)
            
            # レンダリング実行
            job.start()
            job.waitForFinished()
            
            # レンダリング結果を取得
            image = job.renderedImage()
            if image.isNull():
                QgsMessageLog.logMessage("❌ Rendered image is null", "QMapPermalink", Qgis.Warning)
                return None
            
            # PNG形式でバイト配列に変換
            from PyQt5.QtCore import QByteArray, QBuffer, QIODevice
            byte_array = QByteArray()
            buffer = QBuffer(byte_array)
            buffer.open(QIODevice.WriteOnly)
            
            success = image.save(buffer, "PNG")
            if not success:
                QgsMessageLog.logMessage("❌ Failed to save rendered image as PNG", "QMapPermalink", Qgis.Warning)
                return None
            
            png_data = byte_array.data()
            return png_data
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Error executing map rendering: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            return None
            
            # マップレンダリング実行
            from qgis.core import QgsMapRendererParallelJob
            from PyQt5.QtGui import QImage
            
            job = QgsMapRendererParallelJob(map_settings)
            job.start()
            job.waitForFinished()
            
            image = job.renderedImage()
            if image.isNull():
                QgsMessageLog.logMessage("❌ Rendered image is null", "QMapPermalink", Qgis.Warning)
                return None
            
            # PNG形式でバイト配列に変換
            from PyQt5.QtCore import QByteArray, QBuffer, QIODevice
            byte_array = QByteArray()
            buffer = QBuffer(byte_array)
            buffer.open(QIODevice.WriteOnly)
            
            success = image.save(buffer, "PNG")
            if not success:
                QgsMessageLog.logMessage("❌ Failed to save image as PNG", "QMapPermalink", Qgis.Warning)
                return None
            
            png_data = byte_array.data()
            return png_data
            
        except Exception as e:
            QgsMessageLog.logMessage(f"❌ Error generating QGIS map PNG: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            return None

    def _generate_error_image(self, width, height, error_message):
        """エラーメッセージ付きの画像を生成"""
        try:
            from PyQt5.QtGui import QImage, QPainter, QFont, QColor
            from PyQt5.QtCore import Qt, QByteArray, QBuffer, QIODevice
            
            # 画像を作成
            image = QImage(width, height, QImage.Format_ARGB32)
            image.fill(QColor(240, 240, 240))  # 明るいグレー背景
            
            # ペインターで描画
            painter = QPainter(image)
            painter.setRenderHint(QPainter.Antialiasing)
            
            # フォントとペンを設定
            font = QFont("Arial", 12)
            painter.setFont(font)
            painter.setPen(QColor(180, 0, 0))  # 赤色のテキスト
            
            # エラーメッセージを描画
            rect = image.rect()
            painter.drawText(rect, Qt.AlignCenter | Qt.TextWordWrap, f"Error:\n{error_message}")
            
            painter.end()
            
            # PNG形式でバイト配列に変換
            byte_array = QByteArray()
            buffer = QBuffer(byte_array)
            buffer.open(QIODevice.WriteOnly)
            image.save(buffer, "PNG")
            
            return byte_array.data()
            
        except Exception as e:
            # 最小限のPNG画像を返す
            return b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x01\x00\x00\x00\x01\x00\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\tpHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\x16tEXtSoftware\x00www.inkscape.org\x9b\xee<\x1a\x00\x00\x00\x1ftEXtTitle\x00Error Image\x87\x96\xf0\x8e\x00\x00\x00\x12IDATx\x9cc\xf8\x0f\x00\x00\x01\x00\x01\x00\x18\xdd\x8d\xb4\x00\x00\x00\x00IEND\xaeB`\x82'

    def _guess_bind_ip(self):
        """サーバの外向きIPv4アドレスを推定して返す（簡易）"""
        try:
            import socket as _socket
            # 外部に到達可能なダミー接続を作って自IPを取得
            s = _socket.socket(_socket.AF_INET, _socket.SOCK_DGRAM)
            try:
                s.connect(('8.8.8.8', 53))
                ip = s.getsockname()[0]
            except Exception:
                ip = '127.0.0.1'
            finally:
                try:
                    s.close()
                except Exception:
                    pass
            return ip
        except Exception:
            return '127.0.0.1'

    def find_available_port(self, start_port, end_port):
        """使用可能なポートを探す
        
        Args:
            start_port: 開始ポート番号
            end_port: 終了ポート番号
            
        Returns:
            使用可能なポート番号
        """
        for port in range(start_port, end_port + 1):
            try:
                # test bind on all interfaces
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    s.bind(('0.0.0.0', port))
                    return port
            except OSError:
                continue
        raise RuntimeError(f"ポート範囲 {start_port}-{end_port} で使用可能なポートが見つかりません")

    def is_server_running(self):
        """サーバーが稼働中かどうかを確認"""
        return self._http_running and self.http_server is not None

    def get_server_port(self):
        """現在のサーバーポートを取得"""
        return self.server_port if self.is_server_running() else None

    def get_last_request(self):
        """最後のHTTPリクエストテキストを取得"""
        return self._last_request_text