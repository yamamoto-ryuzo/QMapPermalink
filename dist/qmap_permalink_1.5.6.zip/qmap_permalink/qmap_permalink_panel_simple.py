# -*- coding: utf-8 -*-
"""
パネルテスト用の簡易版
"""

import os
from qgis.PyQt.QtWidgets import QDockWidget, QWidget, QVBoxLayout, QLabel, QPushButton
from qgis.PyQt.QtCore import Qt

class SimpleQMapPermalinkPanel(QDockWidget):
    """簡易テスト版のパネル"""
    
    def __init__(self, parent=None):
        super(SimpleQMapPermalinkPanel, self).__init__(parent)
        
        # パネルのタイトルを設定
        self.setWindowTitle("QMap Permalink - Simple")
        
        # ドッキングエリアを設定
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        
        # 内部ウィジェットを作成
        self.widget = QWidget()
        layout = QVBoxLayout()
        
        # 簡単なコンテンツを追加
        label = QLabel("QMap Permalink Panel Test")
        self.pushButton_generate = QPushButton("Generate Permalink")
        self.pushButton_navigate = QPushButton("Navigate")
        self.pushButton_copy = QPushButton("Copy")
        
        layout.addWidget(label)
        layout.addWidget(self.pushButton_generate)
        layout.addWidget(self.pushButton_navigate)
        layout.addWidget(self.pushButton_copy)
        
        self.widget.setLayout(layout)
        self.setWidget(self.widget)
        
        # パネルのサイズを設定
        self.setMinimumWidth(250)
        self.setMaximumWidth(400)
        
    def update_server_status(self, port, running):
        """ダミーメソッド"""
        pass