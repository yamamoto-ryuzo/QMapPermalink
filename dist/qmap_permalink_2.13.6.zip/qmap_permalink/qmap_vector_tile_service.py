# -*- coding: utf-8 -*-
"""
Simple Vector Tile (MVT) service for QMapPermalink.

This handler attempts to generate Mapbox Vector Tile (.pbf) bytes
using the PyQGIS APIs when available (QGIS >= 3.22+ typically). It
falls back to a clear 501 response when the native API is not present.

Design goals:
- lightweight: delegate feature selection to QGIS layer queries
- safe: do not crash the server if MVT writer API is absent
- compatible: produce tiles in EPSG:3857 tile scheme
"""
import re
import json
import traceback

from qgis.core import QgsMessageLog, Qgis


class QMapPermalinkVectorTileService:
    def __init__(self, server_manager):
        self.server_manager = server_manager

    def handle_vectortile_request(self, conn, parsed_url, params, host=None):
        """Handle incoming /vectortile/{z}/{x}/{y}.pbf requests.

        Returns a native MVT (application/x-protobuf) when the environment
        supports it. Otherwise returns 501 Not Implemented with a helpful
        message.
        """
        try:
            QgsMessageLog.logMessage(f"🌐 VectorTile request: {parsed_url.path}", "QMapPermalink", Qgis.Info)

            m = re.match(r'^/vectortile/(\d+)/(\d+)/(\d+)\.(pbf|mvt)$', parsed_url.path)
            if not m:
                # not a tile path we support
                return

            z = int(m.group(1))
            x = int(m.group(2))
            y = int(m.group(3))

            # Compute EPSG:3857 bbox for XYZ tile (origin top-left)
            def tile_xyz_to_bbox(z, x, y):
                origin = 20037508.342789244
                tiles = 2 ** z
                tile_size = (origin * 2) / tiles
                minx = -origin + x * tile_size
                maxx = -origin + (x + 1) * tile_size
                maxy = origin - y * tile_size
                miny = origin - (y + 1) * tile_size
                return (minx, miny, maxx, maxy)

            bbox = tile_xyz_to_bbox(z, x, y)
            QgsMessageLog.logMessage(f"🔎 VectorTile tile -> BBOX z={z},x={x},y={y} => {bbox}", "QMapPermalink", Qgis.Info)

            # Try native PyQGIS vector tile writer first
            try:
                from qgis.core import QgsVectorTileWriter, QgsRectangle, QgsProject

                # Create rectangle in EPSG:3857
                rect = QgsRectangle(bbox[0], bbox[1], bbox[2], bbox[3])

                # Prepare list of visible vector layers to include
                canvas = None
                try:
                    canvas = self.server_manager.iface.mapCanvas()
                except Exception:
                    canvas = None

                layers = []
                if canvas:
                    for lyr in canvas.layers():
                        try:
                            # include vector layers only and visible ones
                            from qgis.core import QgsVectorLayer
                            if isinstance(lyr, QgsVectorLayer):
                                layers.append(lyr)
                        except Exception:
                            pass

                if not layers:
                    QgsMessageLog.logMessage("⚠️ No vector layers available to build vector tiles", "QMapPermalink", Qgis.Warning)
                    # respond with empty tile (valid MVT must still be a protobuf, but for simplicity return 204)
                    from . import http_server
                    http_server.send_http_response(conn, 204, 'No Content', 'No vector layers available')
                    return

                # Use QgsVectorTileWriter to build PBF in memory when possible.
                # Note: API shapes across QGIS versions; attempt common approach.
                try:
                    writer = QgsVectorTileWriter()
                    # Configure writer: target CRS EPSG:3857, extent from rect
                    options = {}
                    # Some versions accept writeTile(layers, z, x, y, extent, options, outputBuffer)
                    # We'll attempt a few calling conventions defensively.
                    pbf_bytes = None

                    # Preferred: writeTile returning bytes or accepting a bytearray buffer
                    try:
                        # Newer API may expose writeTile(layers, z, x, y, rect, options)
                        pbf_bytes = writer.writeTile(layers, z, x, y, rect, options)
                    except TypeError:
                        try:
                            # Older variants may require providing a filename; use temp file then read
                            import tempfile, os
                            fd, path = tempfile.mkstemp(suffix='.pbf')
                            os.close(fd)
                            try:
                                res = writer.writeTile(layers, z, x, y, rect, options, path)
                                if os.path.exists(path):
                                    with open(path, 'rb') as f:
                                        pbf_bytes = f.read()
                            finally:
                                try:
                                    os.remove(path)
                                except Exception:
                                    pass
                        except Exception:
                            pbf_bytes = None

                    if pbf_bytes:
                        from . import http_server
                        http_server.send_binary_response(conn, 200, 'OK', pbf_bytes, 'application/x-protobuf')
                        return
                    else:
                        raise RuntimeError('QgsVectorTileWriter returned no bytes')

                except Exception as e:
                    QgsMessageLog.logMessage(f"⚠️ Native QgsVectorTileWriter failed: {e}\n{traceback.format_exc()}", "QMapPermalink", Qgis.Warning)
                    # fallthrough to try mapbox_vector_tile if available
            except Exception as e:
                QgsMessageLog.logMessage(f"⚠️ Native vector tile writer not available: {e}", "QMapPermalink", Qgis.Info)

            # Fallback: try to build GeoJSON and encode with mapbox_vector_tile if installed
            try:
                import mapbox_vector_tile
                from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsGeometry, QgsCoordinateTransform, QgsProject, QgsCoordinateReferenceSystem

                # Build GeoJSON features per layer
                features_by_layer = {}
                rect3857 = bbox
                for lyr in self.server_manager.iface.mapCanvas().layers():
                    try:
                        from qgis.core import QgsVectorLayer
                        if not isinstance(lyr, QgsVectorLayer):
                            continue
                        # Transform bbox to layer CRS
                        layer_crs = lyr.crs()
                        tgt_crs = QgsCoordinateReferenceSystem('EPSG:3857')
                        if layer_crs.authid() != tgt_crs.authid():
                            transform = QgsCoordinateTransform(tgt_crs, layer_crs, QgsProject.instance())
                            minx, miny, maxx, maxy = rect3857
                            r = QgsRectangle(minx, miny, maxx, maxy)
                            r = transform.transformBoundingBox(r)
                        else:
                            r = QgsRectangle(*rect3857)

                        req = QgsFeatureRequest().setFilterRect(r)
                        feats = []
                        for feat in lyr.getFeatures(req):
                            g = feat.geometry()
                            try:
                                geom_json = json.loads(g.asJson())
                            except Exception:
                                # asJson may not be GeoJSON; try WKT fallback
                                try:
                                    geom_json = {'type': 'GeometryCollection', 'geometries': []}
                                except Exception:
                                    geom_json = None
                            props = {}
                            fields = lyr.fields()
                            for i, f in enumerate(fields):
                                try:
                                    props[f.name()] = feat.attribute(i)
                                except Exception:
                                    pass
                            feats.append({'type': 'Feature', 'geometry': geom_json, 'properties': props})
                        if feats:
                            features_by_layer[lyr.name()] = feats
                    except Exception:
                        pass

                if not features_by_layer:
                    from . import http_server
                    http_server.send_http_response(conn, 204, 'No Content', 'No features for tile')
                    return

                # mapbox_vector_tile.encode expects {layername: features}
                pbf = mapbox_vector_tile.encode(features_by_layer)
                from . import http_server
                http_server.send_binary_response(conn, 200, 'OK', pbf, 'application/x-protobuf')
                return
            except Exception as e:
                QgsMessageLog.logMessage(f"⚠️ mapbox_vector_tile unavailable or failed: {e}\n{traceback.format_exc()}", "QMapPermalink", Qgis.Info)

            # If we reached here, we cannot produce MVT in this environment.
            QgsMessageLog.logMessage("❌ Vector tile generation is not available in this environment", "QMapPermalink", Qgis.Critical)
            from . import http_server
            http_server.send_http_response(conn, 501, 'Not Implemented', 'Native vector tile generation not available in this QGIS environment. Please enable QgsVectorTileWriter or install mapbox_vector_tile.')

        except Exception as e:
            QgsMessageLog.logMessage(f"❌ VectorTile service error: {e}\n{traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            try:
                from . import http_server
                http_server.send_http_response(conn, 500, 'Internal Server Error', f'VectorTile processing failed: {e}')
            except Exception:
                pass
