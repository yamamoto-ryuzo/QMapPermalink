# -*- coding: utf-8 -*-
"""
Lightweight "general" vector-tile-like service handler.

This module provides a small service class that mirrors the WMTS
approach: it exposes a minimal GetCapabilities response and a
/{service}/{z}/{x}/{y}.pbf (or .mvt) tile URL template. For now the
implementation intentionally stays small and conservative:

- If PyQGIS is available (running inside QGIS) the handler will log
  via QgsMessageLog and attempt to delegate rendering to the
  server manager's existing WMS-with-BBOX pipeline (so clients can
  still obtain an image tile). Producing true MVT vector tiles is
  non-trivial and omitted here; this module is intended as a
  starting point for adding such functionality.
- If PyQGIS is not available (standard Python interpreter) the
  handler fails gracefully and returns HTTP 501 responses so no
  additional pip installs are required.

The goal is to add a general-purpose service endpoint similar to
the WMTS handler while keeping runtime dependencies to the
standard Python distribution unless running inside QGIS.
"""
import re


try:
    from qgis.core import QgsMessageLog, Qgis
    _HAS_QGIS = True
except Exception:
    # Running in plain Python (no PyQGIS available)
    _HAS_QGIS = False


def _log(msg, level=None):
    """Log using QgsMessageLog when available, otherwise print.

    We avoid referencing Qgis.* at import time so the module can be
    imported in plain Python interpreters without PyQGIS installed.
    """
    qlevel = level
    if _HAS_QGIS and qlevel is None:
        try:
            # use QgsMessageLog level constant when available
            qlevel = Qgis.Info
        except Exception:
            qlevel = None

    if _HAS_QGIS and qlevel is not None:
        try:
            QgsMessageLog.logMessage(msg, "QMapPermalink", qlevel)
            return
        except Exception:
            # degrade to print
            pass

    # fallback for non-QGIS environments
    print(f"QMapPermalink: {msg}")


class QMapPermalinkVectorTileService:
    """General-purpose vector-tile-like service handler.

    This class intentionally keeps behaviour simple: it provides a
    GetCapabilities XML and a tile URL template /vectortile/{z}/{x}/{y}.pbf
    or .mvt. Tile requests are translated to an EPSG:3857 BBOX and
    delegated to the server manager's WMS-BBOX pipeline when possible.
    Producing real vector tiles is left for a later extension.
    """

    def __init__(self, server_manager, service_name='vectortile'):
        self.server_manager = server_manager
        self.service_name = service_name

    def handle_vector_tile_request(self, conn, parsed_url, params, host=None):
        """Handle an incoming /vectortile request.

        Args:
            conn: socket-like connection
            parsed_url: result of urllib.parse.urlparse(target)
            params: dict from urllib.parse.parse_qs
            host: Host header value (optional)
        """
        try:
            _log(f"🌐 Vector service handling: {parsed_url.path}")

            # Simple GetCapabilities support
            req = ''
            try:
                req = params.get('REQUEST', [params.get('request', [''])[0]])[0] if params else ''
            except Exception:
                req = ''

            if (req and str(req).upper() == 'GETCAPABILITIES'):
                # Debug helper: return available QGIS vector tile API symbols when requested
                try:
                    if params and ('debug_api' in params or 'api_debug' in params):
                        info = {}
                        if _HAS_QGIS:
                            try:
                                import inspect
                                from qgis import core as qcore
                                # collect some candidate symbols
                                for name in ('QgsVectorTileWriter', 'writeVectorTile'):
                                    try:
                                        obj = getattr(qcore, name)
                                        info[name] = sorted([m for m in dir(obj) if not m.startswith('_')])
                                    except Exception:
                                        info[name] = None
                            except Exception as e:
                                info['error'] = str(e)
                        else:
                            info['qgis'] = False
                        from . import http_server
                        import json
                        http_server.send_http_response(conn, 200, 'OK', json.dumps(info, ensure_ascii=False), 'application/json; charset=utf-8')
                        return
                except Exception:
                    pass
                try:
                    server_port = self.server_manager.http_server.getsockname()[1] if self.server_manager.http_server else self.server_manager.server_port
                except Exception:
                    server_port = getattr(self.server_manager, 'server_port', 8089)

                if not host:
                    host = f'localhost:{server_port}'

                tile_url = f"http://{host}/{self.service_name}/{{z}}/{{x}}/{{y}}.pbf"
                xml = (
                    '<?xml version="1.0" encoding="UTF-8"?>\n'
                    '<Capabilities version="1.0.0">\n'
                    '  <Service>\n'
                    f'    <Title>QGIS Map (Generic Vector Service)</Title>\n'
                    f'    <Identifier>{self.service_name}</Identifier>\n'
                    f'    <TileURLTemplate>{tile_url}</TileURLTemplate>\n'
                    '  </Service>\n'
                    '</Capabilities>'
                )

                from . import http_server
                http_server.send_http_response(conn, 200, 'OK', xml, 'text/xml; charset=utf-8')
                return

            # Serve a minimal TileJSON-like descriptor at /vectortile.json to help
            # MapLibre clients probe availability. The server manager routes any
            # path starting with /vectortile here, so check for the JSON request.
            try:
                if parsed_url.path == f'/{self.service_name}.json' or parsed_url.path.endswith('/vectortile.json'):
                    try:
                        server_port = self.server_manager.http_server.getsockname()[1] if self.server_manager.http_server else self.server_manager.server_port
                    except Exception:
                        server_port = getattr(self.server_manager, 'server_port', 8089)
                    if not host:
                        host = f'localhost:{server_port}'
                    base = f'http://{host}/{self.service_name}/{{z}}/{{x}}/{{y}}.pbf'
                    tj = {
                        'tilejson': '2.0.0',
                        'name': 'QMapPermalink Vector Tiles',
                        'version': getattr(self.server_manager, 'plugin_version', 'unknown'),
                        'tiles': [ base ],
                        'vector_layers': {}
                    }
                    import json
                    from . import http_server
                    http_server.send_http_response(conn, 200, 'OK', json.dumps(tj, ensure_ascii=False), 'application/json; charset=utf-8')
                    return
            except Exception:
                # non-fatal: continue to tile handling
                pass

            # Tile request pattern: /{service}/{z}/{x}/{y}.(pbf|mvt)
            m = re.match(rf'^/{re.escape(self.service_name)}/(\d+)/(\d+)/(\d+)\.(pbf|mvt|png|jpg|jpeg)$', parsed_url.path)
            if m:
                z = int(m.group(1))
                x = int(m.group(2))
                y = int(m.group(3))
                fmt = m.group(4)

                _log(f"🔎 Vector tile request -> z={z},x={x},y={y}, fmt={fmt}")

                # compute WebMercator bbox for XYZ tile (origin top-left)
                def tile_xyz_to_bbox(z, x, y):
                    origin = 20037508.342789244
                    tiles = 2 ** z
                    tile_size = (origin * 2) / tiles
                    minx = -origin + x * tile_size
                    maxx = -origin + (x + 1) * tile_size
                    maxy = origin - y * tile_size
                    miny = origin - (y + 1) * tile_size
                    return f"{minx},{miny},{maxx},{maxy}"

                bbox = tile_xyz_to_bbox(z, x, y)
                _log(f"🔎 Converted to BBOX: {bbox}")

                # Attempt to generate an MVT (.pbf) using PyQGIS (QGIS 3.44+ expected).
                # We try a few likely APIs (QgsVectorTileWriter variants) and fall
                # back to the existing WMS-BBOX pipeline when not available.
                try:
                    if _HAS_QGIS:
                        from qgis.core import QgsRectangle, QgsCoordinateReferenceSystem, QgsProject
                        from . import http_server

                        # create rectangle for the tile in EPSG:3857
                        coords = [float(v) for v in bbox.split(',')]
                        rect = QgsRectangle(coords[0], coords[1], coords[2], coords[3])

                        # Try to import a VectorTile writer class if available
                        writer_cls = None
                        try:
                            from qgis.core import QgsVectorTileWriter
                            writer_cls = QgsVectorTileWriter
                        except Exception:
                            writer_cls = None

                        # Try several possible dynamic APIs if a writer class exists
                        if writer_cls is not None:
                            writer_instance = None
                            created = False
                            # Try common constructor signatures (best-effort)
                            try:
                                try:
                                    writer_instance = writer_cls(QgsProject.instance())
                                    created = True
                                except Exception:
                                    try:
                                        writer_instance = writer_cls()
                                        created = True
                                    except Exception:
                                        writer_instance = None
                                        created = False
                            except Exception:
                                writer_instance = None
                                created = False

                            def _to_bytes(d):
                                if d is None:
                                    return None
                                if isinstance(d, (bytes, bytearray)):
                                    return bytes(d)
                                try:
                                    if hasattr(d, 'data') and callable(d.data):
                                        return bytes(d.data())
                                except Exception:
                                    pass
                                try:
                                    if isinstance(d, memoryview):
                                        return bytes(d)
                                except Exception:
                                    pass
                                try:
                                    return bytes(d)
                                except Exception:
                                    return None

                            # 1) Prefer instance method writeSingleTile / writeTiles if present
                            single_names = ('writeSingleTile', 'writeTile', 'writeTileBytes', 'tileBytes')
                            tried = False
                            for name in single_names:
                                if writer_instance and hasattr(writer_instance, name):
                                    meth = getattr(writer_instance, name)
                                    try:
                                        # try common signatures
                                        data = None
                                        try:
                                            data = meth(z, x, y)
                                        except TypeError:
                                            try:
                                                data = meth(x, y, z)
                                            except TypeError:
                                                try:
                                                    data = meth(z, x, y, rect)
                                                except TypeError:
                                                    data = None

                                        b = _to_bytes(data)
                                        if b is not None:
                                            http_server.send_binary_response(conn, 200, 'OK', b, 'application/vnd.mapbox-vector-tile')
                                            return
                                        tried = True
                                    except Exception:
                                        pass

                            # 2) Some writers write to a destination URI. Try setting a temp file
                            import tempfile, os
                            temp_path = None
                            try:
                                if writer_instance is not None and hasattr(writer_instance, 'setDestinationUri'):
                                    fd, temp_path = tempfile.mkstemp(suffix='.pbf')
                                    os.close(fd)
                                    try:
                                        writer_instance.setDestinationUri(temp_path)
                                    except Exception:
                                        # some APIs expect a URI like 'file://...'
                                        try:
                                            writer_instance.setDestinationUri(f'file://{temp_path}')
                                        except Exception:
                                            pass

                                    # Try to invoke writeSingleTile or writeTiles to produce file
                                    try:
                                        invoked = False
                                        if hasattr(writer_instance, 'writeSingleTile'):
                                            try:
                                                writer_instance.writeSingleTile(z, x, y)
                                                invoked = True
                                            except Exception:
                                                try:
                                                    writer_instance.writeSingleTile(x, y, z)
                                                    invoked = True
                                                except Exception:
                                                    pass
                                        if not invoked and hasattr(writer_instance, 'writeTiles'):
                                            try:
                                                # try a single-tile invocation pattern
                                                writer_instance.writeTiles(z, x, y)
                                                invoked = True
                                            except Exception:
                                                try:
                                                    writer_instance.writeTiles([ (z, x, y) ])
                                                    invoked = True
                                                except Exception:
                                                    pass

                                        # If invoked, read temp file
                                        if invoked and temp_path and os.path.exists(temp_path):
                                            try:
                                                with open(temp_path, 'rb') as tf:
                                                    data = tf.read()
                                                if data:
                                                    http_server.send_binary_response(conn, 200, 'OK', data, 'application/vnd.mapbox-vector-tile')
                                                    try:
                                                        os.remove(temp_path)
                                                    except Exception:
                                                        pass
                                                    return
                                            except Exception:
                                                pass
                                    finally:
                                        try:
                                            if temp_path and os.path.exists(temp_path):
                                                os.remove(temp_path)
                                        except Exception:
                                            pass
                            except Exception:
                                try:
                                    if temp_path and os.path.exists(temp_path):
                                        os.remove(temp_path)
                                except Exception:
                                    pass

                        # If writer class not available or produced no data, try newer helper functions
                        # Some QGIS versions offer module-level helpers; try a best-effort approach.
                        try:
                            # Example hypothetical helper: qgis.core.writeVectorTile(z,x,y,rect,project)
                            from qgis.core import writeVectorTile
                            data = writeVectorTile(z, x, y, rect, QgsProject.instance())
                            if data and isinstance(data, (bytes, bytearray)):
                                http_server.send_binary_response(conn, 200, 'OK', bytes(data), 'application/vnd.mapbox-vector-tile')
                                return
                        except Exception:
                            pass

                        # Fallback: delegate to WMS pipeline to return a PNG (pragmatic)
                        if hasattr(self.server_manager, '_handle_wms_get_map_with_bbox'):
                            _log('⚠️ Vector tile writer not available or failed: falling back to WMS PNG')
                            self.server_manager._handle_wms_get_map_with_bbox(conn, bbox, 'EPSG:3857', 256, 256, rotation=0.0)
                            return
                        else:
                            http_server.send_http_response(conn, 501, 'Not Implemented', 'Vector tile generation not available on this server (requires QGIS vector tile API)')
                            return

                    else:
                        # PyQGIS not present: cannot produce MVT
                        from . import http_server
                        msg = 'Vector tile generation requires running inside QGIS with vector tile support (QGIS 3.44+)'
                        http_server.send_http_response(conn, 501, 'Not Implemented', msg)
                        return

                except Exception as e:
                    _log(f"❌ Vector tile handler error: {e}")
                    from . import http_server
                    http_server.send_http_response(conn, 500, 'Internal Server Error', f'Vector tile failed: {e}')
                return

        except Exception as e:
            _log(f"❌ Vector service error: {e}")
            try:
                from . import http_server
                http_server.send_http_response(conn, 500, 'Internal Server Error', f'Vector service processing failed: {e}')
            except Exception:
                pass
