// WMTS layers list provided by the plugin. This file is intended to be
// copied next to the generated HTML and loaded via <script src="wmts_layers.js">.

const wmtsLayers = [
    { id: 'qmap', title: 'QGIS Map (WMTS)' }
];
