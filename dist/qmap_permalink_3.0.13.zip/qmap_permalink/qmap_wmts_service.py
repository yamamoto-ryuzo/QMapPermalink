# -*- coding: utf-8 -*-
"""
Lightweight WMTS-like service for QMapPermalink.

This module provides a small class that handles /wmts requests and
delegates actual rendering to the server manager's existing WMS
GetMap-with-BBOX pipeline. The class is intentionally small to avoid
duplicate rendering code and to prevent circular imports: it expects
to receive the server manager instance at construction time.
"""
import re
import os
import tempfile
import hashlib
from qgis.core import QgsMessageLog, Qgis


class QMapPermalinkWMTSService:
    """Simple WMTS-like handler that maps XYZ tiles to a WMS GetMap BBOX.

    The service does not implement a full WMTS server — just a minimal
    GetCapabilities response and XYZ tile URL pattern /wmts/{z}/{x}/{y}.png
    which it translates into an EPSG:3857 BBOX and calls the server
    manager's _handle_wms_get_map_with_bbox method.
    """

    def __init__(self, server_manager):
        self.server_manager = server_manager
        # Maximum allowed zoom to avoid absurd requests (sane default)
        self._max_zoom = 30

    def _tile_xyz_to_bbox(self, z, x, y):
        """Convert XYZ tile coordinates to WebMercator bbox string.

        Returns: string "minx,miny,maxx,maxy"
        """
        origin = 20037508.342789244
        tiles = 2 ** z
        tile_size = (origin * 2) / tiles
        minx = -origin + x * tile_size
        maxx = -origin + (x + 1) * tile_size
        maxy = origin - y * tile_size
        miny = origin - (y + 1) * tile_size
        return f"{minx},{miny},{maxx},{maxy}"

    def _validate_tile_coords(self, z, x, y):
        """Basic validation for z/x/y ranges. Returns (True, None) or (False, message)."""
        try:
            if z < 0 or z > self._max_zoom:
                return False, f"zoom out of range (0-{self._max_zoom})"
            tiles = 2 ** z
            if x < 0 or x >= tiles or y < 0 or y >= tiles:
                return False, "tile coordinates out of range for given zoom"
            return True, None
        except Exception as e:
            return False, str(e)

    def handle_wmts_request(self, conn, parsed_url, params, host=None):
        """Handle an incoming /wmts request.

        Args:
            conn: socket connection
            parsed_url: result of urllib.parse.urlparse(target)
            params: dict from urllib.parse.parse_qs
            host: Host header value (optional)
        """
        try:

            # Accept WMTS GetCapabilities via REQUEST=GetCapabilities or SERVICE=WMTS (without other REQUEST)
            req = params.get('REQUEST', [params.get('request', [''])[0]])[0] if params else ''
            svc = params.get('SERVICE', [params.get('service', [''])[0]])[0] if params else ''
            
            # Handle GetCapabilities explicitly
            # Treat either explicit REQUEST=GetCapabilities or SERVICE=WMTS (with no REQUEST)
            if (req and str(req).upper() == 'GETCAPABILITIES') or (not req and svc and str(svc).upper() == 'WMTS'):
                try:
                    server_port = self.server_manager.http_server.getsockname()[1] if self.server_manager.http_server else self.server_manager.server_port
                except Exception:
                    server_port = self.server_manager.server_port
                if not host:
                    host = f'localhost:{server_port}'
                # Provide both a simple template URL and a WMTS ResourceURL entry to help clients
                # Use str.format with doubled braces so the template placeholders remain literal in the XML
                tile_url = "http://{host}/wmts/{{z}}/{{x}}/{{y}}.png".format(host=host)
                tile_url_template = "http://{host}/wmts/{{TileMatrix}}/{{TileCol}}/{{TileRow}}.png".format(host=host)

                # Build TileMatrix entries for each zoom level (0.._max_zoom)
                origin = 20037508.342789244
                full_width = origin * 2
                tile_size = 256
                initial_resolution = full_width / tile_size
                tile_matrices = []
                for zlevel in range(0, self._max_zoom + 1):
                    matrix_width = 2 ** zlevel
                    matrix_height = matrix_width
                    resolution = initial_resolution / (2 ** zlevel)
                    # scaleDenominator = resolution / 0.00028 (pixel size 0.28 mm)
                    scale_denominator = resolution / 0.00028
                    tile_matrices.append(
                        f"      <TileMatrix>\n"
                        f"        <Identifier>{zlevel}</Identifier>\n"
                        f"        <ScaleDenominator>{scale_denominator:.6f}</ScaleDenominator>\n"
                        f"        <TopLeftCorner>{-origin} {origin}</TopLeftCorner>\n"
                        f"        <TileWidth>{tile_size}</TileWidth>\n"
                        f"        <TileHeight>{tile_size}</TileHeight>\n"
                        f"        <MatrixWidth>{matrix_width}</MatrixWidth>\n"
                        f"        <MatrixHeight>{matrix_height}</MatrixHeight>\n"
                        f"      </TileMatrix>"
                    )

                tile_matrices_xml = "\n".join(tile_matrices)

                xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<Capabilities xmlns="http://www.opengis.net/wmts/1.0" version="1.0.0">
  <Contents>
    <Layer>
      <Title>QGIS Map (WMTS)</Title>
      <Identifier>qgis_map</Identifier>
      <TileMatrixSetLink>
        <TileMatrixSet>EPSG:3857</TileMatrixSet>
      </TileMatrixSetLink>
      <ResourceURL format="image/png" resourceType="tile" template="{tile_url_template}"/>
    </Layer>
    <TileMatrixSet>
      <Identifier>EPSG:3857</Identifier>
      <SupportedCRS>EPSG:3857</SupportedCRS>
{tile_matrices_xml}
      <!-- Minimal: clients should use the /wmts/{{z}}/{{x}}/{{y}}.png template -->
    </TileMatrixSet>
  </Contents>
  <ServiceMetadataURL>{tile_url}</ServiceMetadataURL>
</Capabilities>'''
                from . import http_server
                http_server.send_http_response(conn, 200, 'OK', xml, 'text/xml; charset=utf-8')
                return
            
            # Handle GetTile via KVP encoding (WMTS standard)
            if req and str(req).upper() == 'GETTILE':
                try:
                    # Extract TILEMATRIX (z), TILECOL (x), TILEROW (y) from params
                    z = int(params.get('TILEMATRIX', params.get('tilematrix', ['0']))[0])
                    x = int(params.get('TILECOL', params.get('tilecol', ['0']))[0])
                    y = int(params.get('TILEROW', params.get('tilerow', ['0']))[0])

                    # Detect TMS (bottom-left origin) flag in params (tms=1 or tms=true)
                    tms_flag = False
                    try:
                        tms_val = params.get('tms', params.get('TMS', ['0']))[0] if params else '0'
                        tms_flag = str(tms_val).lower() in ('1', 'true', 'yes')
                    except Exception:
                        tms_flag = False

                    # If request is TMS (y origin bottom-left), convert to XYZ (top-left) by inverting y
                    if tms_flag:
                        try:
                            y = (2 ** z - 1) - y
                        except Exception:
                            pass

                    # validate coordinates before expensive rendering
                    ok, msg = self._validate_tile_coords(z, x, y)
                    if not ok:
                        from . import http_server
                        http_server.send_http_response(conn, 400, 'Bad Request', msg, 'text/plain; charset=utf-8')
                        return

                    # compute WebMercator bbox for XYZ tile (origin top-left)
                    bbox = self._tile_xyz_to_bbox(z, x, y)

                    # Try to serve from cache. Cache key based on z/x/y and host
                    try:
                        cache_dir = os.path.join(os.path.dirname(__file__), '.cache', 'wmts')
                        os.makedirs(cache_dir, exist_ok=True)
                        cache_key = f"{z}/{x}/{y}"
                        # safe filename via hashing to avoid path injection
                        key_hash = hashlib.sha1(cache_key.encode('utf-8')).hexdigest()
                        cache_path = os.path.join(cache_dir, f"{key_hash}.png")
                        if os.path.exists(cache_path):
                            with open(cache_path, 'rb') as fh:
                                data = fh.read()
                            from . import http_server
                            http_server.send_binary_response(conn, 200, 'OK', data, 'image/png')
                            return
                    except Exception:
                        # If cache check errors, continue to rendering path
                        pass

                    # Delegate to server manager's WMS GetMap-with-BBOX pipeline (256x256)
                    if hasattr(self.server_manager, '_handle_wms_get_map_with_bbox'):
                        # Capture the outgoing bytes from the server_manager so we can cache the image
                        class _CaptureConn:
                            def __init__(self):
                                self._buf = bytearray()
                            def sendall(self, b):
                                if isinstance(b, (bytes, bytearray)):
                                    self._buf.extend(b)
                            def close(self):
                                pass
                        cap = _CaptureConn()
                        # Call renderer with capture conn
                        self.server_manager._handle_wms_get_map_with_bbox(cap, bbox, 'EPSG:3857', 256, 256, rotation=0.0)
                        # Parse captured response: split header and body by CRLFCRLF
                        try:
                            raw = bytes(cap._buf)
                            sep = b"\r\n\r\n"
                            if sep in raw:
                                hdr, body = raw.split(sep, 1)
                                # parse headers to find Content-Type
                                hdr_text = hdr.decode('utf-8', errors='ignore')
                                content_type = 'application/octet-stream'
                                for line in hdr_text.splitlines():
                                    if line.lower().startswith('content-type:'):
                                        content_type = line.split(':',1)[1].strip()
                                        break
                                # if image, cache it
                                if content_type.startswith('image'):
                                    try:
                                        tmpfd, tmppath = tempfile.mkstemp(dir=cache_dir, suffix='.tmp')
                                        with os.fdopen(tmpfd, 'wb') as tfh:
                                            tfh.write(body)
                                        os.replace(tmppath, cache_path)
                                    except Exception:
                                        try:
                                            if os.path.exists(tmppath):
                                                os.remove(tmppath)
                                        except Exception:
                                            pass
                                # forward the captured bytes to original conn
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    try:
                                        from . import http_server
                                        http_server.send_http_response(conn, 500, 'Internal Server Error', 'Failed to forward response', 'text/plain; charset=utf-8')
                                    except Exception:
                                        pass
                                return
                            else:
                                # not an HTTP response: just forward raw buffer
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    pass
                                return
                        except Exception as e:
                            from . import http_server
                            http_server.send_http_response(conn, 500, 'Internal Server Error', str(e), 'text/plain; charset=utf-8')
                            return
                    else:
                        raise RuntimeError('WMS rendering method not available on server manager')
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ WMTS GetTile KVP handler error: {e}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, 'Internal Server Error', str(e), 'text/plain; charset=utf-8')
                    return

            # Tile request pattern: /wmts/{z}/{x}/{y}.png
            m = re.match(r'^/wmts/(\d+)/(\d+)/(\d+)\.(png|jpg|jpeg)$', parsed_url.path, flags=re.IGNORECASE)
            if m:
                z = int(m.group(1))
                x = int(m.group(2))
                y = int(m.group(3))

                # Detect TMS (bottom-left origin) flag in params (tms=1 or tms=true)
                tms_flag = False
                try:
                    tms_val = params.get('tms', params.get('TMS', ['0']))[0] if params else '0'
                    tms_flag = str(tms_val).lower() in ('1', 'true', 'yes')
                except Exception:
                    tms_flag = False

                # If TMS requested, invert y before validation and bbox computation
                if tms_flag:
                    try:
                        y = (2 ** z - 1) - y
                    except Exception:
                        pass

                ok, msg = self._validate_tile_coords(z, x, y)
                if not ok:
                    from . import http_server
                    http_server.send_http_response(conn, 400, 'Bad Request', msg, 'text/plain; charset=utf-8')
                    return

                # compute WebMercator bbox for XYZ tile (origin top-left)
                bbox = self._tile_xyz_to_bbox(z, x, y)

                try:
                    # Try cache first
                    try:
                        cache_dir = os.path.join(os.path.dirname(__file__), '.cache', 'wmts')
                        os.makedirs(cache_dir, exist_ok=True)
                        cache_key = f"{z}/{x}/{y}"
                        key_hash = hashlib.sha1(cache_key.encode('utf-8')).hexdigest()
                        cache_path = os.path.join(cache_dir, f"{key_hash}.png")
                        if os.path.exists(cache_path):
                            with open(cache_path, 'rb') as fh:
                                data = fh.read()
                            from . import http_server
                            http_server.send_binary_response(conn, 200, 'OK', data, 'image/png')
                            return
                    except Exception:
                        pass

                    # Delegate to server manager's WMS GetMap-with-BBOX pipeline (256x256)
                    if hasattr(self.server_manager, '_handle_wms_get_map_with_bbox'):
                        class _CaptureConn:
                            def __init__(self):
                                self._buf = bytearray()
                            def sendall(self, b):
                                if isinstance(b, (bytes, bytearray)):
                                    self._buf.extend(b)
                            def close(self):
                                pass
                        cap = _CaptureConn()
                        self.server_manager._handle_wms_get_map_with_bbox(cap, bbox, 'EPSG:3857', 256, 256, rotation=0.0)
                        try:
                            raw = bytes(cap._buf)
                            sep = b"\r\n\r\n"
                            if sep in raw:
                                hdr, body = raw.split(sep, 1)
                                hdr_text = hdr.decode('utf-8', errors='ignore')
                                content_type = 'application/octet-stream'
                                for line in hdr_text.splitlines():
                                    if line.lower().startswith('content-type:'):
                                        content_type = line.split(':',1)[1].strip()
                                        break
                                if content_type.startswith('image'):
                                    try:
                                        tmpfd, tmppath = tempfile.mkstemp(dir=cache_dir, suffix='.tmp')
                                        with os.fdopen(tmpfd, 'wb') as tfh:
                                            tfh.write(body)
                                        os.replace(tmppath, cache_path)
                                    except Exception:
                                        try:
                                            if os.path.exists(tmppath):
                                                os.remove(tmppath)
                                        except Exception:
                                            pass
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    pass
                                return
                            else:
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    pass
                                return
                        except Exception as e:
                            QgsMessageLog.logMessage(f"❌ WMTS tile handler error: {e}", "QMapPermalink", Qgis.Critical)
                            from . import http_server
                            http_server.send_http_response(conn, 500, 'Internal Server Error', f'WMTS tile failed: {e}')
                    else:
                        raise RuntimeError('WMS rendering method not available on server manager')
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ WMTS tile handler error: {e}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, 'Internal Server Error', f'WMTS tile failed: {e}')
                return

        except Exception as e:
            QgsMessageLog.logMessage(f"❌ WMTS service error: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            try:
                from . import http_server
                http_server.send_http_response(conn, 500, 'Internal Server Error', f'WMTS processing failed: {e}')
            except Exception:
                pass
