# -*- coding: utf-8 -*-
"""
Lightweight WMTS-like service for QMapPermalink.

This module provides a small class that handles /wmts requests and
delegates actual rendering to the server manager's existing WMS
GetMap-with-BBOX pipeline. The class is intentionally small to avoid
duplicate rendering code and to prevent circular imports: it expects
to receive the server manager instance at construction time.
"""
import re
import os
import tempfile
import hashlib
import json
from qgis.core import QgsMessageLog, Qgis


class QMapPermalinkWMTSService:
    """Simple WMTS-like handler that maps XYZ tiles to a WMS GetMap BBOX.

    The service does not implement a full WMTS server — just a minimal
    GetCapabilities response and XYZ tile URL pattern /wmts/{z}/{x}/{y}.png
    which it translates into an EPSG:3857 BBOX and calls the server
    manager's _handle_wms_get_map_with_bbox method.
    """

    def __init__(self, server_manager):
        self.server_manager = server_manager
        # Maximum allowed zoom to avoid absurd requests (sane default)
        self._max_zoom = 30

    def _tile_xyz_to_bbox(self, z, x, y):
        """Convert XYZ tile coordinates to WebMercator bbox string.

        Returns: string "minx,miny,maxx,maxy"
        """
        origin = 20037508.342789244
        tiles = 2 ** z
        tile_size = (origin * 2) / tiles
        minx = -origin + x * tile_size
        maxx = -origin + (x + 1) * tile_size
        maxy = origin - y * tile_size
        miny = origin - (y + 1) * tile_size
        return f"{minx},{miny},{maxx},{maxy}"

    def _validate_tile_coords(self, z, x, y):
        """Basic validation for z/x/y ranges. Returns (True, None) or (False, message)."""
        try:
            if z < 0 or z > self._max_zoom:
                return False, f"zoom out of range (0-{self._max_zoom})"
            tiles = 2 ** z
            if x < 0 or x >= tiles or y < 0 or y >= tiles:
                return False, "tile coordinates out of range for given zoom"
            return True, None
        except Exception as e:
            return False, str(e)

    def _compute_cache_identity(self):
        """Compute a short identity for the current visible layers or theme.

        This method remains for backward compatibility and returns a short
        hex string (12 chars). Prefer using _get_identity_info() which returns
        both a short id and the raw identity string used to build it.
        """
        try:
            short, _raw = self._get_identity_info()
            return short
        except Exception:
            return 'def'

    def _get_identity_info(self):
        """Return (short_id, raw_identity_string).

        raw_identity_string is a readable representation of the current theme
        or the ordered list of visible layer IDs. short_id is the first 12
        hex chars of sha1(raw_identity_string).
        """
        try:
            # Prefer constructing a deterministic, structured identity from visible layers
            # because this module caches the current canvas layers by default.
            # Prefer explicit server_manager attributes, then fall back to iface.mapCanvas()
            canvas = getattr(self.server_manager, 'map_canvas', None) or getattr(self.server_manager, 'canvas', None)
            if (not canvas) and hasattr(self.server_manager, 'iface'):
                try:
                    canvas = self.server_manager.iface.mapCanvas()
                except Exception:
                    canvas = None

            # Prefer layer-tree order and visibility when available (more accurate)
            try:
                from qgis.core import QgsProject
                root = QgsProject.instance().layerTreeRoot()
            except Exception:
                root = None

            # Debug: log whether we found a project root / canvas for troubleshooting
            try:
                try:
                    found_canvas = bool(canvas)
                except Exception:
                    found_canvas = False
                try:
                    found_root = bool(root)
                except Exception:
                    found_root = False
                QgsMessageLog.logMessage(f"WMTS identity debug: canvas_present={found_canvas}, layer_tree_root_present={found_root}", 'QMapPermalink', Qgis.Info)
                try:
                    print(f"WMTS identity debug: canvas_present={found_canvas}, layer_tree_root_present={found_root}")
                except Exception:
                    pass
            except Exception:
                pass

            if root is not None:
                try:
                    # root.findLayers() returns layer nodes in tree order when available
                    lnodes = []
                    try:
                        lnodes = root.findLayers()
                    except Exception:
                        # fallback: iterate children and collect layer nodes
                        try:
                            for ch in root.children():
                                try:
                                    if hasattr(ch, 'layerId'):
                                        lnodes.append(ch)
                                except Exception:
                                    continue
                        except Exception:
                            lnodes = []

                    # Debug: log number of layer-tree nodes and sample ids
                    try:
                        try:
                            lnode_count = len(lnodes)
                        except Exception:
                            lnode_count = sum(1 for _ in lnodes) if hasattr(lnodes, '__iter__') else 0
                        sample_ids = []
                        for n in (lnodes[:10] if hasattr(lnodes, '__getitem__') else list(lnodes)[:10]):
                            try:
                                lidv = n.layerId()
                            except Exception:
                                lidv = getattr(n, 'layerId', None)
                                if callable(lidv):
                                    try:
                                        lidv = lidv()
                                    except Exception:
                                        lidv = None
                            sample_ids.append(lidv)
                        QgsMessageLog.logMessage(f"WMTS identity debug: layer_tree_nodes={lnode_count}, sample_layernode_ids={sample_ids}", 'QMapPermalink', Qgis.Info)
                        try:
                            print(f"WMTS identity debug: layer_tree_nodes={lnode_count}, sample_layernode_ids={sample_ids}")
                        except Exception:
                            pass
                    except Exception:
                        pass

                    layers_info = []
                    for idx, lnode in enumerate(lnodes):
                        try:
                            lid = None
                            try:
                                lid = lnode.layerId()
                            except Exception:
                                lid = getattr(lnode, 'layerId', None)
                            if not lid:
                                continue
                            # retrieve layer object from project
                            from qgis.core import QgsProject as _QProj
                            layer_obj = _QProj.instance().mapLayer(lid)
                            if not layer_obj:
                                try:
                                    QgsMessageLog.logMessage(f"WMTS identity debug: mapLayer returned None for layerId={lid}", 'QMapPermalink', Qgis.Info)
                                    try:
                                        print(f"WMTS identity debug: mapLayer returned None for layerId={lid}")
                                    except Exception:
                                        pass
                                except Exception:
                                    pass
                                continue

                            info = {}
                            info['order'] = idx
                            info['id'] = layer_obj.id()
                            # source
                            try:
                                src_attr = getattr(layer_obj, 'source', None)
                                if callable(src_attr):
                                    try:
                                        info['source'] = src_attr()
                                    except Exception:
                                        try:
                                            info['source'] = str(src_attr)
                                        except Exception:
                                            info['source'] = ''
                                else:
                                    info['source'] = str(src_attr) if src_attr is not None else ''
                            except Exception:
                                info['source'] = ''
                            # style fingerprint — normalize to avoid non-deterministic memory addresses
                            try:
                                style_str = ''
                                if hasattr(layer_obj, 'style'):
                                    try:
                                        style_str = str(layer_obj.style())
                                    except Exception:
                                        style_str = ''
                                elif hasattr(layer_obj, 'renderer'):
                                    try:
                                        style_str = str(layer_obj.renderer())
                                    except Exception:
                                        style_str = ''
                                # normalize common non-deterministic parts (memory addresses)
                                try:
                                    # replace hex pointers like 0x7ffdeadbeef
                                    style_str = re.sub(r'0x[0-9a-fA-F]+', '<addr>', style_str)
                                    # collapse whitespace
                                    style_str = re.sub(r'\s+', ' ', style_str).strip()
                                except Exception:
                                    pass
                                info['style_hash'] = hashlib.sha1((style_str or '').encode('utf-8')).hexdigest()
                            except Exception:
                                info['style_hash'] = ''
                            # visibility from node
                            try:
                                vis = bool(lnode.isVisible()) if hasattr(lnode, 'isVisible') else False
                            except Exception:
                                vis = False
                            info['visible'] = bool(vis)
                            layers_info.append(info)
                        except Exception:
                            continue
                    # Debug: log constructed layers_info count and sample
                    try:
                        QgsMessageLog.logMessage(f"WMTS identity debug: constructed layers_info count={len(layers_info)}, sample={layers_info[:5]}", 'QMapPermalink', Qgis.Info)
                        try:
                            print(f"WMTS identity debug: constructed layers_info count={len(layers_info)}, sample={layers_info[:5]}")
                        except Exception:
                            pass
                    except Exception:
                        pass

                    # canonical JSON of layers_info (preserving order)
                    raw = json.dumps(layers_info, separators=(',', ':'), ensure_ascii=False)
                    short = hashlib.sha1(raw.encode('utf-8')).hexdigest()[:12]
                    return short, raw
                except Exception:
                    # fall through to canvas-based method
                    pass

            if canvas and hasattr(canvas, 'layers'):
                try:
                    layer_objs = canvas.layers()
                    # Debug: log canvas.layers count and sample ids/reprs
                    try:
                        try:
                            canvas_count = len(layer_objs)
                        except Exception:
                            canvas_count = sum(1 for _ in layer_objs) if hasattr(layer_objs, '__iter__') else 0
                        canvas_sample = []
                        # attempt to collect stable identifiers for a few layers
                        for li in (layer_objs[:10] if hasattr(layer_objs, '__getitem__') else list(layer_objs)[:10]):
                            try:
                                lid = None
                                try:
                                    lid = li.id()
                                except Exception:
                                    lid = getattr(li, 'source', None) or getattr(li, 'name', None) or str(li)
                                canvas_sample.append(lid)
                            except Exception:
                                canvas_sample.append(None)
                        QgsMessageLog.logMessage(f"WMTS identity debug: canvas_layers_count={canvas_count}, canvas_sample_ids={canvas_sample}", 'QMapPermalink', Qgis.Info)
                        try:
                            print(f"WMTS identity debug: canvas_layers_count={canvas_count}, canvas_sample_ids={canvas_sample}")
                        except Exception:
                            pass
                    except Exception:
                        pass
                    layers_info = []
                    for idx, l in enumerate(layer_objs):
                        info = {}
                        # order first to preserve determinism
                        info['order'] = idx
                        # stable id if available
                        lid = None
                        try:
                            lid = l.id()
                        except Exception:
                            lid = None
                        if not lid:
                            try:
                                # common QGIS layer property
                                lid = getattr(l, 'source', None)
                            except Exception:
                                lid = None
                        if not lid:
                            try:
                                prov = getattr(l, 'dataProvider', None)
                                if prov and callable(prov):
                                    dp = prov()
                                else:
                                    dp = prov
                                if dp and hasattr(dp, 'dataSourceUri'):
                                    try:
                                        lid = dp.dataSourceUri()
                                    except Exception:
                                        lid = None
                            except Exception:
                                lid = None
                        if not lid:
                            try:
                                lid = str(l)
                            except Exception:
                                lid = ''
                        info['id'] = lid

                        # source (best-effort)
                        src = None
                        try:
                            if hasattr(l, 'source'):
                                src_attr = getattr(l, 'source', None)
                                if callable(src_attr):
                                    try:
                                        src = src_attr()
                                    except Exception:
                                        try:
                                            src = str(src_attr)
                                        except Exception:
                                            src = None
                                else:
                                    src = str(src_attr) if src_attr is not None else None
                            else:
                                dp = getattr(l, 'dataProvider', None)
                                if dp and hasattr(dp, 'dataSourceUri'):
                                    try:
                                        src = dp.dataSourceUri()
                                    except Exception:
                                        src = None
                        except Exception:
                            src = None
                        info['source'] = src or ''

                        # style fingerprint (best-effort) — normalize to avoid non-deterministic parts
                        style_str = ''
                        try:
                            if hasattr(l, 'style'):
                                try:
                                    style_str = str(l.style())
                                except Exception:
                                    style_str = ''
                            elif hasattr(l, 'renderer'):
                                try:
                                    style_str = str(l.renderer())
                                except Exception:
                                    style_str = ''
                            try:
                                style_str = re.sub(r'0x[0-9a-fA-F]+', '<addr>', style_str)
                                style_str = re.sub(r'\s+', ' ', style_str).strip()
                            except Exception:
                                pass
                        except Exception:
                            style_str = ''
                        info['style_hash'] = hashlib.sha1((style_str or '').encode('utf-8')).hexdigest()

                        # visible flag: prefer layer-tree node visibility (more accurate)
                        vis = False
                        try:
                            from qgis.core import QgsProject
                            root = QgsProject.instance().layerTreeRoot()
                            lnode = root.findLayer(info.get('id')) if root and info.get('id') else None
                            if lnode and hasattr(lnode, 'isVisible'):
                                vis = bool(lnode.isVisible())
                            else:
                                # fall back to layer object's isVisible (if present)
                                if hasattr(l, 'isVisible') and callable(getattr(l, 'isVisible')):
                                    vis = bool(l.isVisible())
                                else:
                                    vis = bool(getattr(l, 'visible', False))
                        except Exception:
                            try:
                                if hasattr(l, 'isVisible') and callable(getattr(l, 'isVisible')):
                                    vis = bool(l.isVisible())
                                else:
                                    vis = bool(getattr(l, 'visible', False))
                            except Exception:
                                vis = False
                        info['visible'] = bool(vis)

                        layers_info.append(info)

                    # canonical JSON of layers_info (preserving order)
                    raw = json.dumps(layers_info, separators=(',', ':'), ensure_ascii=False)
                    short = hashlib.sha1(raw.encode('utf-8')).hexdigest()[:12]
                    return short, raw
                except Exception:
                    pass

            # If no canvas-based identity, fall back to server_manager theme-like attributes
            try:
                QgsMessageLog.logMessage("WMTS identity debug: falling back to theme attributes (no usable layer identity)", 'QMapPermalink', Qgis.Info)
                try:
                    print("WMTS identity debug: falling back to theme attributes (no usable layer identity)")
                except Exception:
                    pass
                # log available theme-like attrs for debugging
                try:
                    avail = {attr: (getattr(self.server_manager, attr, None) is not None) for attr in ('current_theme', 'active_theme', 'theme', 'selected_theme')}
                    QgsMessageLog.logMessage(f"WMTS identity debug: server_manager_theme_attrs={avail}", 'QMapPermalink', Qgis.Info)
                    try:
                        print(f"WMTS identity debug: server_manager_theme_attrs={avail}")
                    except Exception:
                        pass
                except Exception:
                    pass
            except Exception:
                pass
            for attr in ('current_theme', 'active_theme', 'theme', 'selected_theme'):
                val = getattr(self.server_manager, attr, None)
                if val:
                    try:
                        theme_val = val() if callable(val) else val
                        # canonicalize theme via json when possible
                        try:
                            raw = json.dumps(theme_val, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
                        except Exception:
                            raw = str(theme_val)
                        short = hashlib.sha1(raw.encode('utf-8')).hexdigest()[:12]
                        return short, raw
                    except Exception:
                        continue

            # Last resort: constant
            return 'defaultid', 'defaultid'
        except Exception:
            return 'def', 'def'

    def get_identity_diagnostics(self):
        """Return a dict with diagnostic info about layer-tree and canvas layers.

        This helper is intended for interactive debugging from the QGIS
        Python console. It does not modify cache or files.
        """
        diag = {
            'canvas_present': False,
            'layer_tree_root_present': False,
            'lnode_count': None,
            'sample_layernode_ids': None,
            'constructed_layers_info_count': None,
            'constructed_layers_info_sample': None,
            'canvas_layers_count': None,
            'canvas_sample_ids': None,
            'server_manager_theme_attrs': None,
        }
        try:
            canvas = getattr(self.server_manager, 'map_canvas', None) or getattr(self.server_manager, 'canvas', None)
            if (not canvas) and hasattr(self.server_manager, 'iface'):
                try:
                    canvas = self.server_manager.iface.mapCanvas()
                except Exception:
                    canvas = None
            diag['canvas_present'] = bool(canvas)

            try:
                from qgis.core import QgsProject
                root = QgsProject.instance().layerTreeRoot()
            except Exception:
                root = None
            diag['layer_tree_root_present'] = bool(root)

            # layer-tree nodes
            try:
                lnodes = []
                if root is not None:
                    try:
                        lnodes = root.findLayers()
                    except Exception:
                        try:
                            for ch in root.children():
                                if hasattr(ch, 'layerId'):
                                    lnodes.append(ch)
                        except Exception:
                            lnodes = []
                try:
                    diag['lnode_count'] = len(lnodes)
                except Exception:
                    diag['lnode_count'] = sum(1 for _ in lnodes) if hasattr(lnodes, '__iter__') else None
                sample = []
                for n in (lnodes[:10] if hasattr(lnodes, '__getitem__') else list(lnodes)[:10]):
                    try:
                        lid = None
                        try:
                            lid = n.layerId()
                        except Exception:
                            lid = getattr(n, 'layerId', None)
                            if callable(lid):
                                try:
                                    lid = lid()
                                except Exception:
                                    lid = None
                        sample.append(lid)
                    except Exception:
                        sample.append(None)
                diag['sample_layernode_ids'] = sample
            except Exception:
                pass

            # attempt to build layers_info via layer-tree path (but don't stop on failure)
            try:
                layers_info = []
                if root is not None and diag.get('lnode_count'):
                    from qgis.core import QgsProject as _QProj
                    for idx, lnode in enumerate(lnodes):
                        try:
                            lid = None
                            try:
                                lid = lnode.layerId()
                            except Exception:
                                lid = getattr(lnode, 'layerId', None)
                            if not lid:
                                continue
                            layer_obj = _QProj.instance().mapLayer(lid)
                            if not layer_obj:
                                continue
                            info = {
                                'order': idx,
                                'id': layer_obj.id(),
                                'source': getattr(layer_obj, 'source', '') or '',
                                'style_hash': hashlib.sha1((str(getattr(layer_obj, 'style', '') or getattr(layer_obj, 'renderer', ''))).encode('utf-8')).hexdigest(),
                                'visible': bool(lnode.isVisible()) if hasattr(lnode, 'isVisible') else False,
                            }
                            layers_info.append(info)
                        except Exception:
                            continue
                diag['constructed_layers_info_count'] = len(layers_info)
                diag['constructed_layers_info_sample'] = layers_info[:5]
            except Exception:
                pass

            # canvas.layers() info
            try:
                if canvas and hasattr(canvas, 'layers'):
                    layer_objs = canvas.layers()
                    try:
                        diag['canvas_layers_count'] = len(layer_objs)
                    except Exception:
                        diag['canvas_layers_count'] = sum(1 for _ in layer_objs) if hasattr(layer_objs, '__iter__') else None
                    sample = []
                    for li in (layer_objs[:10] if hasattr(layer_objs, '__getitem__') else list(layer_objs)[:10]):
                        try:
                            lid = None
                            try:
                                lid = li.id()
                            except Exception:
                                lid = getattr(li, 'source', None) or getattr(li, 'name', None) or str(li)
                            sample.append(lid)
                        except Exception:
                            sample.append(None)
                    diag['canvas_sample_ids'] = sample
            except Exception:
                pass

            # server_manager theme attrs
            try:
                avail = {attr: (getattr(self.server_manager, attr, None) is not None) for attr in ('current_theme', 'active_theme', 'theme', 'selected_theme')}
                diag['server_manager_theme_attrs'] = avail
            except Exception:
                diag['server_manager_theme_attrs'] = None

        except Exception:
            pass
        # also log for convenience
        try:
            QgsMessageLog.logMessage(f"WMTS identity diagnostics: {diag}", 'QMapPermalink', Qgis.Info)
            try:
                print("WMTS identity diagnostics:", diag)
            except Exception:
                pass
        except Exception:
            pass
        return diag

    def handle_wmts_request(self, conn, parsed_url, params, host=None):
        """Handle an incoming /wmts request.

        Args:
            conn: socket connection
            parsed_url: result of urllib.parse.urlparse(target)
            params: dict from urllib.parse.parse_qs
            host: Host header value (optional)
        """
        try:

            # Accept WMTS GetCapabilities via REQUEST=GetCapabilities or SERVICE=WMTS (without other REQUEST)
            req = params.get('REQUEST', [params.get('request', [''])[0]])[0] if params else ''
            svc = params.get('SERVICE', [params.get('service', [''])[0]])[0] if params else ''
            
            # Handle GetCapabilities explicitly
            # Treat either explicit REQUEST=GetCapabilities or SERVICE=WMTS (with no REQUEST)
            if (req and str(req).upper() == 'GETCAPABILITIES') or (not req and svc and str(svc).upper() == 'WMTS'):
                try:
                    server_port = self.server_manager.http_server.getsockname()[1] if self.server_manager.http_server else self.server_manager.server_port
                except Exception:
                    server_port = self.server_manager.server_port
                if not host:
                    host = f'localhost:{server_port}'

    
                # Provide both a simple template URL and a WMTS ResourceURL entry to help clients
                # Use str.format with doubled braces so the template placeholders remain literal in the XML
                tile_url = "http://{host}/wmts/{{z}}/{{x}}/{{y}}.png".format(host=host)
                tile_url_template = "http://{host}/wmts/{{TileMatrix}}/{{TileCol}}/{{TileRow}}.png".format(host=host)

                # Build TileMatrix entries for each zoom level (0.._max_zoom)
                origin = 20037508.342789244
                full_width = origin * 2
                tile_size = 256
                initial_resolution = full_width / tile_size
                tile_matrices = []
                for zlevel in range(0, self._max_zoom + 1):
                    matrix_width = 2 ** zlevel
                    matrix_height = matrix_width
                    resolution = initial_resolution / (2 ** zlevel)
                    # scaleDenominator = resolution / 0.00028 (pixel size 0.28 mm)
                    scale_denominator = resolution / 0.00028
                    tile_matrices.append(
                        f"      <TileMatrix>\n"
                        f"        <Identifier>{zlevel}</Identifier>\n"
                        f"        <ScaleDenominator>{scale_denominator:.6f}</ScaleDenominator>\n"
                        f"        <TopLeftCorner>{-origin} {origin}</TopLeftCorner>\n"
                        f"        <TileWidth>{tile_size}</TileWidth>\n"
                        f"        <TileHeight>{tile_size}</TileHeight>\n"
                        f"        <MatrixWidth>{matrix_width}</MatrixWidth>\n"
                        f"        <MatrixHeight>{matrix_height}</MatrixHeight>\n"
                        f"      </TileMatrix>"
                    )

                tile_matrices_xml = "\n".join(tile_matrices)

                xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<Capabilities xmlns="http://www.opengis.net/wmts/1.0" version="1.0.0">
  <Contents>
    <Layer>
      <Title>QGIS Map (WMTS)</Title>
      <Identifier>qgis_map</Identifier>
      <TileMatrixSetLink>
        <TileMatrixSet>EPSG:3857</TileMatrixSet>
      </TileMatrixSetLink>
      <ResourceURL format="image/png" resourceType="tile" template="{tile_url_template}"/>
    </Layer>
    <TileMatrixSet>
      <Identifier>EPSG:3857</Identifier>
      <SupportedCRS>EPSG:3857</SupportedCRS>
{tile_matrices_xml}
      <!-- Minimal: clients should use the /wmts/{{z}}/{{x}}/{{y}}.png template -->
    </TileMatrixSet>
  </Contents>
  <ServiceMetadataURL>{tile_url}</ServiceMetadataURL>
</Capabilities>'''
                from . import http_server
                http_server.send_http_response(conn, 200, 'OK', xml, 'text/xml; charset=utf-8')
                return
            
            # Handle GetTile via KVP encoding (WMTS standard)
            if req and str(req).upper() == 'GETTILE':
                try:
                    # Extract TILEMATRIX (z), TILECOL (x), TILEROW (y) from params
                    z = int(params.get('TILEMATRIX', params.get('tilematrix', ['0']))[0])
                    x = int(params.get('TILECOL', params.get('tilecol', ['0']))[0])
                    y = int(params.get('TILEROW', params.get('tilerow', ['0']))[0])

                    # Detect TMS (bottom-left origin) flag in params (tms=1 or tms=true)
                    tms_flag = False
                    try:
                        tms_val = params.get('tms', params.get('TMS', ['0']))[0] if params else '0'
                        tms_flag = str(tms_val).lower() in ('1', 'true', 'yes')
                    except Exception:
                        tms_flag = False

                    # If request is TMS (y origin bottom-left), convert to XYZ (top-left) by inverting y
                    if tms_flag:
                        try:
                            y = (2 ** z - 1) - y
                        except Exception:
                            pass

                    # validate coordinates before expensive rendering
                    ok, msg = self._validate_tile_coords(z, x, y)
                    if not ok:
                        from . import http_server
                        http_server.send_http_response(conn, 400, 'Bad Request', msg, 'text/plain; charset=utf-8')
                        return

                    # compute WebMercator bbox for XYZ tile (origin top-left)
                    bbox = self._tile_xyz_to_bbox(z, x, y)

                    # Try to serve from cache. Include visible-theme identity and format
                    try:
                        cache_dir = os.path.join(os.path.dirname(__file__), '.cache', 'wmts')
                        os.makedirs(cache_dir, exist_ok=True)
                        # determine requested format from KVP params (default png)
                        fmt = 'png'
                        try:
                            fmt_val = params.get('FORMAT', params.get('format', [fmt]))[0] if params else fmt
                            if fmt_val:
                                if isinstance(fmt_val, str) and fmt_val.lower().startswith('image/'):
                                    fmt = fmt_val.split('/', 1)[1].split('+')[0]
                                else:
                                    fmt = str(fmt_val)
                        except Exception:
                            fmt = 'png'
                        if fmt.lower() == 'jpeg':
                            fmt = 'jpg'

                        # Determine a stable identity for the current layer/theme
                        identity_short, identity_raw = self._get_identity_info()
                        cache_key = f"{identity_short}:{fmt}:{z}/{x}/{y}"

                        # create identity-scoped folder using full sha1 of the raw identity
                        identity_hash = hashlib.sha1(identity_raw.encode('utf-8')).hexdigest()
                        identity_dir = os.path.join(cache_dir, identity_hash)
                        try:
                            os.makedirs(identity_dir, exist_ok=True)
                        except Exception:
                            pass

                        # ensure an identity meta file exists for this folder
                        try:
                            meta_index_path = os.path.join(identity_dir, 'identity.meta.json')
                            if not os.path.exists(meta_index_path):
                                meta_index = {
                                    'identity_short': identity_short,
                                    'identity_raw': identity_raw,
                                }
                                with open(meta_index_path, 'w', encoding='utf-8') as mf:
                                    json.dump(meta_index, mf, ensure_ascii=False, indent=2)
                        except Exception:
                            pass

                        # tile path: nested by z/x/y for easier inspection
                        tile_dir = os.path.join(identity_dir, str(z), str(x))
                        try:
                            os.makedirs(tile_dir, exist_ok=True)
                        except Exception:
                            pass

                        cache_path = os.path.join(tile_dir, f"{y}.{fmt}")
                        if os.path.exists(cache_path):
                            with open(cache_path, 'rb') as fh:
                                data = fh.read()
                            from . import http_server
                            # Log which cache key/file was used
                            try:
                                msg = f"WMTS cache serve (KVP): {cache_key} -> {cache_path}"
                                QgsMessageLog.logMessage(msg, 'QMapPermalink', Qgis.Info)
                            except Exception:
                                pass
                            try:
                                print(f"WMTS cache serve (KVP): {cache_key} -> {cache_path}")
                            except Exception:
                                pass
                            content_type = 'image/png' if fmt.lower() == 'png' else f'image/{fmt}'
                            http_server.send_binary_response(conn, 200, 'OK', data, content_type)
                            return
                    except Exception:
                        # If cache check errors, continue to rendering path
                        pass

                    # Delegate to server manager's WMS GetMap-with-BBOX pipeline (256x256)
                    if hasattr(self.server_manager, '_handle_wms_get_map_with_bbox'):
                        # Capture the outgoing bytes from the server_manager so we can cache the image
                        class _CaptureConn:
                            def __init__(self):
                                self._buf = bytearray()
                            def sendall(self, b):
                                if isinstance(b, (bytes, bytearray)):
                                    self._buf.extend(b)
                            def close(self):
                                pass
                        cap = _CaptureConn()
                        # Call renderer with capture conn
                        self.server_manager._handle_wms_get_map_with_bbox(cap, bbox, 'EPSG:3857', 256, 256, rotation=0.0)
                        # Parse captured response: split header and body by CRLFCRLF
                        try:
                            raw = bytes(cap._buf)
                            sep = b"\r\n\r\n"
                            if sep in raw:
                                hdr, body = raw.split(sep, 1)
                                # parse headers to find Content-Type
                                hdr_text = hdr.decode('utf-8', errors='ignore')
                                content_type = 'application/octet-stream'
                                for line in hdr_text.splitlines():
                                    if line.lower().startswith('content-type:'):
                                        content_type = line.split(':',1)[1].strip()
                                        break
                                # if image, cache it
                                if content_type.startswith('image'):
                                    try:
                                        tmpfd, tmppath = tempfile.mkstemp(dir=identity_dir, suffix='.tmp')
                                        with os.fdopen(tmpfd, 'wb') as tfh:
                                            tfh.write(body)
                                        os.replace(tmppath, cache_path)
                                        # Log cache write
                                        try:
                                            msg = f"WMTS cache write (KVP): {cache_key} -> {cache_path}"
                                            QgsMessageLog.logMessage(msg, 'QMapPermalink', Qgis.Info)
                                        except Exception:
                                            pass
                                        try:
                                            print(f"WMTS cache write (KVP): {cache_key} -> {cache_path}")
                                        except Exception:
                                            pass
                                        # write sidecar metadata for easier inspection
                                        meta_path = cache_path + '.meta.json'
                                        try:
                                            with open(meta_path, 'w', encoding='utf-8') as mf:
                                                json.dump({
                                                    'cache_key': cache_key,
                                                    'identity_short': identity_short,
                                                    'identity_raw': identity_raw,
                                                    'format': fmt,
                                                    'z': z,
                                                    'x': x,
                                                    'y': y,
                                                    'path': cache_path,
                                                }, mf, ensure_ascii=False, indent=2)
                                        except Exception:
                                            pass
                                    except Exception:
                                        try:
                                            if os.path.exists(tmppath):
                                                os.remove(tmppath)
                                        except Exception:
                                            pass
                                # forward the captured bytes to original conn
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    try:
                                        from . import http_server
                                        http_server.send_http_response(conn, 500, 'Internal Server Error', 'Failed to forward response', 'text/plain; charset=utf-8')
                                    except Exception:
                                        pass
                                return
                            else:
                                # not an HTTP response: just forward raw buffer
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    pass
                                return
                        except Exception as e:
                            from . import http_server
                            http_server.send_http_response(conn, 500, 'Internal Server Error', str(e), 'text/plain; charset=utf-8')
                            return
                    else:
                        raise RuntimeError('WMS rendering method not available on server manager')
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ WMTS GetTile KVP handler error: {e}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, 'Internal Server Error', str(e), 'text/plain; charset=utf-8')
                    return

            # Tile request pattern: /wmts/{z}/{x}/{y}.png
            m = re.match(r'^/wmts/(\d+)/(\d+)/(\d+)\.(png|jpg|jpeg)$', parsed_url.path, flags=re.IGNORECASE)
            if m:
                z = int(m.group(1))
                x = int(m.group(2))
                y = int(m.group(3))

                # Detect TMS (bottom-left origin) flag in params (tms=1 or tms=true)
                tms_flag = False
                try:
                    tms_val = params.get('tms', params.get('TMS', ['0']))[0] if params else '0'
                    tms_flag = str(tms_val).lower() in ('1', 'true', 'yes')
                except Exception:
                    tms_flag = False

                # If TMS requested, invert y before validation and bbox computation
                if tms_flag:
                    try:
                        y = (2 ** z - 1) - y
                    except Exception:
                        pass

                ok, msg = self._validate_tile_coords(z, x, y)
                if not ok:
                    from . import http_server
                    http_server.send_http_response(conn, 400, 'Bad Request', msg, 'text/plain; charset=utf-8')
                    return

                # compute WebMercator bbox for XYZ tile (origin top-left)
                bbox = self._tile_xyz_to_bbox(z, x, y)

                try:
                    # Try cache first
                    try:
                        cache_dir = os.path.join(os.path.dirname(__file__), '.cache', 'wmts')
                        os.makedirs(cache_dir, exist_ok=True)
                        # extension comes from the URL match group
                        fmt = m.group(4).lower() if m and m.group(4) else 'png'
                        if fmt == 'jpeg':
                            fmt = 'jpg'

                        # Determine a stable identity for the current layer/theme
                        identity_short, identity_raw = self._get_identity_info()
                        cache_key = f"{identity_short}:{fmt}:{z}/{x}/{y}"

                        # create identity-scoped folder using full sha1 of the raw identity
                        identity_hash = hashlib.sha1(identity_raw.encode('utf-8')).hexdigest()
                        identity_dir = os.path.join(cache_dir, identity_hash)
                        try:
                            os.makedirs(identity_dir, exist_ok=True)
                        except Exception:
                            pass

                        # ensure an identity meta file exists for this folder
                        try:
                            meta_index_path = os.path.join(identity_dir, 'identity.meta.json')
                            if not os.path.exists(meta_index_path):
                                meta_index = {
                                    'identity_short': identity_short,
                                    'identity_raw': identity_raw,
                                }
                                with open(meta_index_path, 'w', encoding='utf-8') as mf:
                                    json.dump(meta_index, mf, ensure_ascii=False, indent=2)
                        except Exception:
                            pass

                        # tile path: nested by z/x/y for easier inspection
                        tile_dir = os.path.join(identity_dir, str(z), str(x))
                        try:
                            os.makedirs(tile_dir, exist_ok=True)
                        except Exception:
                            pass

                        cache_path = os.path.join(tile_dir, f"{y}.{fmt}")
                        if os.path.exists(cache_path):
                            with open(cache_path, 'rb') as fh:
                                data = fh.read()
                            from . import http_server
                            # Log which cache key/file was used
                            try:
                                msg = f"WMTS cache serve (URL): {cache_key} -> {cache_path}"
                                QgsMessageLog.logMessage(msg, 'QMapPermalink', Qgis.Info)
                            except Exception:
                                pass
                            try:
                                print(f"WMTS cache serve (URL): {cache_key} -> {cache_path}")
                            except Exception:
                                pass
                            content_type = 'image/png' if fmt == 'png' else f'image/{fmt}'
                            http_server.send_binary_response(conn, 200, 'OK', data, content_type)
                            return
                    except Exception:
                        pass

                    # Delegate to server manager's WMS GetMap-with-BBOX pipeline (256x256)
                    if hasattr(self.server_manager, '_handle_wms_get_map_with_bbox'):
                        class _CaptureConn:
                            def __init__(self):
                                self._buf = bytearray()
                            def sendall(self, b):
                                if isinstance(b, (bytes, bytearray)):
                                    self._buf.extend(b)
                            def close(self):
                                pass
                        cap = _CaptureConn()
                        self.server_manager._handle_wms_get_map_with_bbox(cap, bbox, 'EPSG:3857', 256, 256, rotation=0.0)
                        try:
                            raw = bytes(cap._buf)
                            sep = b"\r\n\r\n"
                            if sep in raw:
                                hdr, body = raw.split(sep, 1)
                                hdr_text = hdr.decode('utf-8', errors='ignore')
                                content_type = 'application/octet-stream'
                                for line in hdr_text.splitlines():
                                    if line.lower().startswith('content-type:'):
                                        content_type = line.split(':',1)[1].strip()
                                        break
                                if content_type.startswith('image'):
                                    try:
                                        tmpfd, tmppath = tempfile.mkstemp(dir=identity_dir, suffix='.tmp')
                                        with os.fdopen(tmpfd, 'wb') as tfh:
                                            tfh.write(body)
                                        os.replace(tmppath, cache_path)
                                        # Log cache write
                                        try:
                                            msg = f"WMTS cache write (URL): {cache_key} -> {cache_path}"
                                            QgsMessageLog.logMessage(msg, 'QMapPermalink', Qgis.Info)
                                        except Exception:
                                            pass
                                        try:
                                            print(f"WMTS cache write (URL): {cache_key} -> {cache_path}")
                                        except Exception:
                                            pass
                                        # write sidecar metadata for easier inspection
                                        meta_path = cache_path + '.meta.json'
                                        try:
                                            with open(meta_path, 'w', encoding='utf-8') as mf:
                                                json.dump({
                                                    'cache_key': cache_key,
                                                    'identity_short': identity_short,
                                                    'identity_raw': identity_raw,
                                                    'format': fmt,
                                                    'z': z,
                                                    'x': x,
                                                    'y': y,
                                                    'path': cache_path,
                                                }, mf, ensure_ascii=False, indent=2)
                                        except Exception:
                                            pass
                                    except Exception:
                                        try:
                                            if os.path.exists(tmppath):
                                                os.remove(tmppath)
                                        except Exception:
                                            pass
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    pass
                                return
                            else:
                                try:
                                    conn.sendall(raw)
                                except Exception:
                                    pass
                                return
                        except Exception as e:
                            QgsMessageLog.logMessage(f"❌ WMTS tile handler error: {e}", "QMapPermalink", Qgis.Critical)
                            from . import http_server
                            http_server.send_http_response(conn, 500, 'Internal Server Error', f'WMTS tile failed: {e}')
                    else:
                        raise RuntimeError('WMS rendering method not available on server manager')
                except Exception as e:
                    QgsMessageLog.logMessage(f"❌ WMTS tile handler error: {e}", "QMapPermalink", Qgis.Critical)
                    from . import http_server
                    http_server.send_http_response(conn, 500, 'Internal Server Error', f'WMTS tile failed: {e}')
                return

        except Exception as e:
            QgsMessageLog.logMessage(f"❌ WMTS service error: {e}", "QMapPermalink", Qgis.Critical)
            import traceback
            QgsMessageLog.logMessage(f"❌ Error traceback: {traceback.format_exc()}", "QMapPermalink", Qgis.Critical)
            try:
                from . import http_server
                http_server.send_http_response(conn, 500, 'Internal Server Error', f'WMTS processing failed: {e}')
            except Exception:
                pass

    def ensure_identity(self, identity_short=None, identity_raw=None):
        """Ensure the identity folder/meta exists for the given identity.

        If identity_short/raw are omitted, compute from current canvas. This
        method is idempotent and safe to call from signal handlers; it will
        create the identity folder under .cache/wmts and write
        identity.meta.json if missing.

        Returns: (identity_hash, identity_dir) or (None, None) on error.
        """
        try:
            if not identity_short or not identity_raw:
                try:
                    identity_short, identity_raw = self._get_identity_info()
                except Exception:
                    return None, None

            cache_dir = os.path.join(os.path.dirname(__file__), '.cache', 'wmts')
            try:
                os.makedirs(cache_dir, exist_ok=True)
            except Exception:
                pass

            identity_hash = hashlib.sha1(identity_raw.encode('utf-8')).hexdigest()
            identity_dir = os.path.join(cache_dir, identity_hash)
            try:
                os.makedirs(identity_dir, exist_ok=True)
            except Exception:
                pass

            # write identity meta if missing
            try:
                meta_index_path = os.path.join(identity_dir, 'identity.meta.json')
                if not os.path.exists(meta_index_path):
                    meta_index = {
                        'identity_short': identity_short,
                        'identity_raw': identity_raw,
                    }
                    with open(meta_index_path, 'w', encoding='utf-8') as mf:
                        json.dump(meta_index, mf, ensure_ascii=False, indent=2)
            except Exception:
                pass

            return identity_hash, identity_dir
        except Exception:
            return None, None
