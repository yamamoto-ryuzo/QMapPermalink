# -*- coding: utf-8 -*-
"""
Lightweight "general" vector-tile-like service handler.

This module provides a small service class that mirrors the WMTS
approach: it exposes a minimal GetCapabilities response and a
/{service}/{z}/{x}/{y}.pbf (or .mvt) tile URL template. For now the
implementation intentionally stays small and conservative:

- If PyQGIS is available (running inside QGIS) the handler will log
  via QgsMessageLog and attempt to delegate rendering to the
  server manager's existing WMS-with-BBOX pipeline (so clients can
  still obtain an image tile). Producing true MVT vector tiles is
  non-trivial and omitted here; this module is intended as a
  starting point for adding such functionality.
- If PyQGIS is not available (standard Python interpreter) the
  handler fails gracefully and returns HTTP 501 responses so no
  additional pip installs are required.

The goal is to add a general-purpose service endpoint similar to
the WMTS handler while keeping runtime dependencies to the
standard Python distribution unless running inside QGIS.
"""
import re


try:
    from qgis.core import QgsMessageLog, Qgis
    _HAS_QGIS = True
except Exception:
    # Running in plain Python (no PyQGIS available)
    _HAS_QGIS = False


def _log(msg, level=None):
    """Log using QgsMessageLog when available, otherwise print.

    We avoid referencing Qgis.* at import time so the module can be
    imported in plain Python interpreters without PyQGIS installed.
    """
    qlevel = level
    if _HAS_QGIS and qlevel is None:
        try:
            # use QgsMessageLog level constant when available
            qlevel = Qgis.Info
        except Exception:
            qlevel = None

    if _HAS_QGIS and qlevel is not None:
        try:
            QgsMessageLog.logMessage(msg, "QMapPermalink", qlevel)
            return
        except Exception:
            # degrade to print
            pass

    # fallback for non-QGIS environments
    print(f"QMapPermalink: {msg}")


class QMapPermalinkVectorTileService:
    """General-purpose vector-tile-like service handler.

    This class intentionally keeps behaviour simple: it provides a
    GetCapabilities XML and a tile URL template /vectortile/{z}/{x}/{y}.pbf
    or .mvt. Tile requests are translated to an EPSG:3857 BBOX and
    delegated to the server manager's WMS-BBOX pipeline when possible.
    Producing real vector tiles is left for a later extension.
    """

    def __init__(self, server_manager, service_name='vectortile'):
        self.server_manager = server_manager
        self.service_name = service_name

    def handle_vector_tile_request(self, conn, parsed_url, params, host=None):
        """Handle an incoming /vectortile request.

        Args:
            conn: socket-like connection
            parsed_url: result of urllib.parse.urlparse(target)
            params: dict from urllib.parse.parse_qs
            host: Host header value (optional)
        """
        try:
            _log(f"🌐 Vector service handling: {parsed_url.path}")

            # Simple GetCapabilities support
            req = ''
            try:
                req = params.get('REQUEST', [params.get('request', [''])[0]])[0] if params else ''
            except Exception:
                req = ''

            if (req and str(req).upper() == 'GETCAPABILITIES'):
                try:
                    server_port = self.server_manager.http_server.getsockname()[1] if self.server_manager.http_server else self.server_manager.server_port
                except Exception:
                    server_port = getattr(self.server_manager, 'server_port', 8089)
                if not host:
                    host = f'localhost:{server_port}'
                tile_url = f"http://{host}/{self.service_name}/{{z}}/{{x}}/{{y}}.pbf"
                xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<Capabilities version="1.0.0">
  <Service>
    <Title>QGIS Map (Generic Vector Service)</Title>
    <Identifier>{self.service_name}</Identifier>
    <TileURLTemplate>{tile_url}</TileURLTemplate>
  </Service>
</Capabilities>'''
                from . import http_server
                http_server.send_http_response(conn, 200, 'OK', xml, 'text/xml; charset=utf-8')
                return

            # Tile request pattern: /{service}/{z}/{x}/{y}.(pbf|mvt)
            m = re.match(rf'^/{re.escape(self.service_name)}/(\d+)/(\d+)/(\d+)\.(pbf|mvt|png|jpg|jpeg)$', parsed_url.path)
            if m:
                z = int(m.group(1))
                x = int(m.group(2))
                y = int(m.group(3))
                fmt = m.group(4)

                _log(f"🔎 Vector tile request -> z={z},x={x},y={y}, fmt={fmt}")

                # compute WebMercator bbox for XYZ tile (origin top-left)
                def tile_xyz_to_bbox(z, x, y):
                    origin = 20037508.342789244
                    tiles = 2 ** z
                    tile_size = (origin * 2) / tiles
                    minx = -origin + x * tile_size
                    maxx = -origin + (x + 1) * tile_size
                    maxy = origin - y * tile_size
                    miny = origin - (y + 1) * tile_size
                    return f"{minx},{miny},{maxx},{maxy}"

                bbox = tile_xyz_to_bbox(z, x, y)
                _log(f"🔎 Converted to BBOX: {bbox}")

                # If PyQGIS and server manager supports WMS-with-BBOX, delegate
                try:
                    if _HAS_QGIS and hasattr(self.server_manager, '_handle_wms_get_map_with_bbox'):
                        # Delegate to WMS pipeline (returns PNG) as a pragmatic fallback
                        self.server_manager._handle_wms_get_map_with_bbox(conn, bbox, 'EPSG:3857', 256, 256, rotation=0.0)
                    else:
                        # Not available: return 501 Not Implemented so client knows
                        from . import http_server
                        msg = 'Vector tile generation not available on this server (requires PyQGIS and a vector tile exporter)'
                        http_server.send_http_response(conn, 501, 'Not Implemented', msg)
                except Exception as e:
                    _log(f"❌ Vector tile handler error: {e}")
                    from . import http_server
                    http_server.send_http_response(conn, 500, 'Internal Server Error', f'Vector tile failed: {e}')
                return

        except Exception as e:
            _log(f"❌ Vector service error: {e}")
            try:
                from . import http_server
                http_server.send_http_response(conn, 500, 'Internal Server Error', f'Vector service processing failed: {e}')
            except Exception:
                pass
