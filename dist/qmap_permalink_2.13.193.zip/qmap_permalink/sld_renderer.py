# -*- coding: utf-8 -*-
"""Simple SLD renderer helpers

This module provides a lightweight conversion of QGIS renderers (categorized,
graduated, rule-based, single-symbol) into a basic SLD 1.1.0 string. It is
intended as a pragmatic, best-effort exporter for use by WFS GetStyles.

The output focuses on simple symbol properties (fill/stroke color, stroke
width, size, opacity). Complex symbol layers, external graphics or vendor
options are intentionally not fully supported here.
"""

from typing import Optional

from qgis.core import (
    QgsCategorizedSymbolRenderer, QgsGraduatedSymbolRenderer, QgsRuleBasedRenderer,
    QgsSingleSymbolRenderer
)


def _sld_header(layer_name: str) -> str:
    return (
        f'<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<StyledLayerDescriptor version="1.1.0" xmlns="http://www.opengis.net/sld" '
        f'xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" '
        f'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
        f'xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.1.0/StyledLayerDescriptor.xsd">\n'
        f'  <NamedLayer>\n'
        f'    <Name>{layer_name}</Name>\n'
        f'    <UserStyle>\n'
        f'      <FeatureTypeStyle>\n'
    )


def _sld_footer() -> str:
    return (
        f'      </FeatureTypeStyle>\n'
        f'    </UserStyle>\n'
        f'  </NamedLayer>\n'
        f'</StyledLayerDescriptor>'
    )


def _escape_xml(s: Optional[str]) -> str:
    if s is None:
        return ''
    return (str(s)
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;')
            .replace('"', '&quot;')
            .replace("'", '&apos;'))


def _symbol_to_symbolizer(symbol, geom_type: str) -> str:
    """Return a simple Symbolizer XML fragment for the given symbol.

    geom_type: 'Point', 'LineString', or 'Polygon'
    """
    try:
        color = None
        stroke_color = None
        stroke_width = None
        size = None
        opacity = None

        # try common methods; many symbol types provide these
        try:
            color = symbol.color()
        except Exception:
            color = None
        try:
            stroke_color = symbol.strokeColor()
        except Exception:
            try:
                stroke_color = symbol.color()
            except Exception:
                stroke_color = None
        try:
            stroke_width = symbol.strokeWidth()
        except Exception:
            try:
                stroke_width = symbol.width()
            except Exception:
                stroke_width = None
        try:
            size = symbol.size()
        except Exception:
            size = None
        try:
            opacity = symbol.opacity()
        except Exception:
            opacity = None

        # For Polygon symbols, check if brush style is NoBrush (ブラシなし)
        has_brush = True
        if geom_type == 'Polygon':
            try:
                # Check symbol layer(s) for brush style
                if hasattr(symbol, 'symbolLayer') and callable(symbol.symbolLayer):
                    sl = symbol.symbolLayer(0)
                    if sl is not None:
                        # Try to get brush style from symbol layer
                        if hasattr(sl, 'brushStyle') and callable(sl.brushStyle):
                            from PyQt5.QtCore import Qt
                            brush_style = sl.brushStyle()
                            if brush_style == Qt.NoBrush:
                                has_brush = False
                                color = None  # Ensure no fill color
            except Exception as e:
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"⚠️ sld_renderer: Failed to check brushStyle: {e}", "QMapPermalink", Qgis.Warning)
                except Exception:
                    pass
            
            # Also check color alpha
            if has_brush and color is not None:
                try:
                    if hasattr(color, 'alpha') and callable(color.alpha):
                        if color.alpha() == 0:
                            has_brush = False
                            color = None
                except Exception:
                    pass

        # convert QColor-like to hex if possible
        def _color_name(c):
            try:
                if c is None:
                    return None
                if hasattr(c, 'name') and c.isValid():
                    return c.name()
                return str(c)
            except Exception:
                return None

        fill_color = _color_name(color)
        stroke_color = _color_name(stroke_color)

        if geom_type == 'Point':
            if size is None:
                size = 6
            fc = _escape_xml(fill_color or '#000000')
            sc = _escape_xml(stroke_color or '#000000')
            return (
                f'<PointSymbolizer>\n'
                f'  <Graphic>\n'
                f'    <Mark>\n'
                f'      <WellKnownName>circle</WellKnownName>\n'
                f'      <Fill><CssParameter name="fill">{fc}</CssParameter></Fill>\n'
                f'      <Stroke><CssParameter name="stroke">{sc}</CssParameter>\n'
                f'      <CssParameter name="stroke-width">1</CssParameter></Stroke>\n'
                f'    </Mark>\n'
                f'    <Size>{size}</Size>\n'
                f'  </Graphic>\n'
                f'</PointSymbolizer>\n'
            )

        if geom_type == 'LineString':
            sw = stroke_width or 2
            sc = _escape_xml(stroke_color or '#000000')
            return (
                f'<LineSymbolizer>\n'
                f'  <Stroke>\n'
                f'    <CssParameter name="stroke">{sc}</CssParameter>\n'
                f'    <CssParameter name="stroke-width">{sw}</CssParameter>\n'
                f'  </Stroke>\n'
                f'</LineSymbolizer>\n'
            )

        # Polygon
        fw = stroke_width or 1
        sc = _escape_xml(stroke_color or '#000000')
        fo = opacity if (opacity is not None) else 1.0
        
        # Check if the fill should be included (ブラシなし detection)
        # has_brush was determined earlier by checking brushStyle and alpha
        has_fill = has_brush and fill_color is not None
        
        # Build PolygonSymbolizer with conditional Fill
        if has_fill:
            fc = _escape_xml(fill_color)
            return (
                f'<PolygonSymbolizer>\n'
                f'  <Fill>\n'
                f'    <CssParameter name="fill">{fc}</CssParameter>\n'
                f'    <CssParameter name="fill-opacity">{fo}</CssParameter>\n'
                f'  </Fill>\n'
                f'  <Stroke>\n'
                f'    <CssParameter name="stroke">{sc}</CssParameter>\n'
                f'    <CssParameter name="stroke-width">{fw}</CssParameter>\n'
                f'  </Stroke>\n'
                f'</PolygonSymbolizer>\n'
            )
        else:
            # ブラシなし: Fill要素を省略し、Strokeのみ
            # LineSymbolizerを返してポリゴンの枠線のみ描画
            return (
                f'<LineSymbolizer>\n'
                f'  <Stroke>\n'
                f'    <CssParameter name="stroke">{sc}</CssParameter>\n'
                f'    <CssParameter name="stroke-width">{fw}</CssParameter>\n'
                f'  </Stroke>\n'
                f'</LineSymbolizer>\n'
            )
    except Exception:
        return ''


def _rule_xml(name: str, filter_xml: Optional[str], symbolizer_xml: str) -> str:
    nm = _escape_xml(name or '')
    filt = f'{filter_xml}\n' if filter_xml else ''
    return (
        f'        <Rule>\n'
        f'          <Name>{nm}</Name>\n'
        f'{filt}'
        f'{symbolizer_xml}'
        f'        </Rule>\n'
    )


def _filter_equal(field: str, value) -> str:
    return (
        f'          <ogc:Filter>\n'
        f'            <ogc:PropertyIsEqualTo>\n'
        f'              <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
        f'              <ogc:Literal>{_escape_xml(value)}</ogc:Literal>\n'
        f'            </ogc:PropertyIsEqualTo>\n'
        f'          </ogc:Filter>'
    )


def _filter_range(field: str, lower, upper) -> str:
    # Use And of >= lower and < upper (upper may be None meaning >= lower)
    if upper is None:
        return (
            f'          <ogc:Filter>\n'
            f'            <ogc:PropertyIsGreaterThanOrEqualTo>\n'
            f'              <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
            f'              <ogc:Literal>{_escape_xml(lower)}</ogc:Literal>\n'
            f'            </ogc:PropertyIsGreaterThanOrEqualTo>\n'
            f'          </ogc:Filter>'
        )
    return (
        f'          <ogc:Filter>\n'
        f'            <ogc:And>\n'
        f'              <ogc:PropertyIsGreaterThanOrEqualTo>\n'
        f'                <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
        f'                <ogc:Literal>{_escape_xml(lower)}</ogc:Literal>\n'
        f'              </ogc:PropertyIsGreaterThanOrEqualTo>\n'
        f'              <ogc:PropertyIsLessThan>\n'
        f'                <ogc:PropertyName>{_escape_xml(field)}</ogc:PropertyName>\n'
        f'                <ogc:Literal>{_escape_xml(upper)}</ogc:Literal>\n'
        f'              </ogc:PropertyIsLessThan>\n'
        f'            </ogc:And>\n'
        f'          </ogc:Filter>'
    )


def renderer_to_sld(layer, layer_name: Optional[str] = None) -> str:
    """Convert a layer.renderer() to an SLD string (best-effort).

    Returns a full SLD document string.
    """
    ln = layer_name or str(layer.id())
    renderer = layer.renderer()
    if renderer is None:
        # trivial default
        from qgis.core import QgsMessageLog, Qgis
        QgsMessageLog.logMessage(f"No renderer for layer {ln}, returning default SLD", "QMapPermalink", Qgis.Warning)
        return _sld_header(ln) + _rule_xml('default', None, _symbol_to_symbolizer(None, 'Polygon')) + _sld_footer()

    rules = []

    try:
        # Single symbol
        if isinstance(renderer, QgsSingleSymbolRenderer):
            sym = renderer.symbol()
            geom = getattr(sym, 'geometryType', None)
            # fallback: try to guess from layer geometry
            gtype = 'Polygon'
            try:
                if layer.geometryType() == 0:
                    gtype = 'Point'
                elif layer.geometryType() == 1:
                    gtype = 'LineString'
                else:
                    gtype = 'Polygon'
            except Exception:
                pass
            rules.append((_escape_xml('default'), None, _symbol_to_symbolizer(sym, gtype)))

        # Categorized
        elif isinstance(renderer, QgsCategorizedSymbolRenderer):
            field = ''
            try:
                field = renderer.classAttribute()
            except Exception:
                try:
                    field = renderer.attribute()
                except Exception:
                    field = ''
            try:
                cats = renderer.categories()
                for c in cats:
                    val = c.value()
                    label = c.label() or str(val)
                    sym = c.symbol()
                    # guess geom type from layer if possible
                    gtype = 'Polygon'
                    try:
                        if layer.geometryType() == 0:
                            gtype = 'Point'
                        elif layer.geometryType() == 1:
                            gtype = 'LineString'
                    except Exception:
                        pass
                    filt = _filter_equal(field, val) if field else None
                    rules.append((label, filt, _symbol_to_symbolizer(sym, gtype)))
            except Exception:
                pass

        # Graduated
        elif isinstance(renderer, QgsGraduatedSymbolRenderer):
            field = ''
            try:
                field = renderer.classAttribute()
            except Exception:
                try:
                    field = renderer.attribute()
                except Exception:
                    field = ''
            try:
                ranges = renderer.ranges()
                for r in ranges:
                    lab = r.label() or f"{r.lowerValue()} - {r.upperValue()}"
                    sym = r.symbol()
                    gtype = 'Polygon'
                    try:
                        if layer.geometryType() == 0:
                            gtype = 'Point'
                        elif layer.geometryType() == 1:
                            gtype = 'LineString'
                    except Exception:
                        pass
                    filt = None
                    if field:
                        # upper may be None
                        lower = r.lowerValue()
                        upper = r.upperValue()
                        filt = _filter_range(field, lower, upper)
                    rules.append((lab, filt, _symbol_to_symbolizer(sym, gtype)))
            except Exception:
                pass

        # Rule based
        elif isinstance(renderer, QgsRuleBasedRenderer):
            try:
                root = renderer.rootRule()
                def walk(rule):
                    res = []
                    # rule may have a symbol
                    try:
                        sym = rule.symbol()
                    except Exception:
                        sym = None
                    try:
                        label = rule.label() or ''
                    except Exception:
                        label = ''
                    try:
                        expr = rule.filterExpression() or ''
                    except Exception:
                        expr = ''
                    # convert expression into a naive ogc filter if simple 'field = value'
                    filt = None
                    if expr:
                        # naive parsing: look for = operator
                        m = expr.split('=')
                        if len(m) == 2:
                            field = m[0].strip().strip('"')
                            val = m[1].strip().strip('\'"')
                            filt = _filter_equal(field, val)
                    # guess geom type
                    gtype = 'Polygon'
                    try:
                        if layer.geometryType() == 0:
                            gtype = 'Point'
                        elif layer.geometryType() == 1:
                            gtype = 'LineString'
                    except Exception:
                        pass
                    if sym is not None:
                        res.append((label, filt, _symbol_to_symbolizer(sym, gtype)))
                    # children
                    try:
                        for child in rule.children():
                            res.extend(walk(child))
                    except Exception:
                        pass
                    return res

                for child in root.children():
                    rules.extend(walk(child))
            except Exception:
                pass

        # Fallback: try symbolForFeature via renderer if nothing produced
        if not rules:
            try:
                from qgis.core import QgsRenderContext, QgsExpressionContext, QgsExpressionContextUtils, QgsFeature
                ctx = QgsRenderContext()
                ctx.setExpressionContext(QgsExpressionContext())
                ctx.expressionContext().appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                dummy = QgsFeature()
                ctx.expressionContext().setFeature(dummy)
                sym = renderer.symbolForFeature(dummy, ctx)
                gtype = 'Polygon'
                try:
                    if layer.geometryType() == 0:
                        gtype = 'Point'
                    elif layer.geometryType() == 1:
                        gtype = 'LineString'
                except Exception:
                    pass
                rules.append(('default', None, _symbol_to_symbolizer(sym, gtype)))
            except Exception:
                pass

    except Exception:
        # any error -> return empty default
        return _sld_header(ln) + _rule_xml('default', None, _symbol_to_symbolizer(None, 'Polygon')) + _sld_footer()

    # assemble SLD
    body = _sld_header(ln)
    for name, filt, symxml in rules:
        body += _rule_xml(name, filt, symxml)
    body += _sld_footer()
    return body
